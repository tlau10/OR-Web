/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.common.result;

import javax.xml.bind.annotation.XmlElement;

public class VariableResult {

	private String name;
	private double value;
	private double reducedCosts;
	
	/**
	 * 
	 */
	public VariableResult() {
		// TODO Auto-generated constructor stub
	}
	
	public VariableResult(String name, double value, double redCosts) {
		this.name = name;
		this.reducedCosts = redCosts;
		this.value = value;
	}

	
	@XmlElement
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@XmlElement
	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}

	@XmlElement
	public double getReducedCosts() {
		return reducedCosts;
	}

	public void setReducedCosts(double reducedCosts) {
		this.reducedCosts = reducedCosts;
	}


}
