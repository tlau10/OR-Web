/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.common.shared;

public class Model {
	
	private String mpsModel;
	/**
	 * 
	 */
	public Model() {
		// TODO Auto-generated constructor stub
	}
	
	public Model(String mpsModel){
		this.mpsModel = mpsModel;
	}
	


	public String getMpsModel() {
		return mpsModel;
	}

	public void setMpsModel(String mpsModel) {
		this.mpsModel = mpsModel;
	}

}
