/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.common.task;

import javax.xml.bind.annotation.XmlElement;

public class Meta {
	
	private String solver;

	private boolean convert;
	
	private boolean solveFromModel;
	
	private boolean transform;
	
	private boolean forcePositive;
	
	@XmlElement
	public String getSolver() {
		return solver;
	}

	public void setSolver(String solver) {
		this.solver = solver;
	}

	@Override
	public String toString() {
	    return "Meta [solver=" + solver + "]";
	}

	@XmlElement
	public boolean getConvert() {
		return convert;
	}

	public void setConvert(boolean convert) {
		this.convert = convert;
	}

	@XmlElement
	public boolean getSolveFromModel() {
		return solveFromModel;
	}

	public void setSolveFromModel(boolean solveFromModel) {
		this.solveFromModel = solveFromModel;
	}

	@XmlElement
	public boolean getTransform() {
		return transform;
	}

	public void setTransform(boolean transform) {
		this.transform = transform;
	}

	@XmlElement
	public boolean getForcePositive() {
		return forcePositive;
	}

	public void setForcePositive(boolean forcePositive) {
		this.forcePositive = forcePositive;
	}
	
}
