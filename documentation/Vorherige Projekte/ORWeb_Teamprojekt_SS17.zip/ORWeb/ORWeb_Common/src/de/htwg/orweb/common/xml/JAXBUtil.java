/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.common.xml;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import de.htwg.orweb.common.result.Result;
import de.htwg.orweb.common.task.Task;

public class JAXBUtil {

	public static final Task toObject(File infile) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance(Task.class);
		Unmarshaller unmarshaller = jc.createUnmarshaller();
		return (Task) unmarshaller.unmarshal(infile);
	}

	public static final void toFile(Task task, String separator, String path,
			String format) throws JAXBException, FileNotFoundException {
		String formatedDate = new SimpleDateFormat("yyyyMMddhhmmss")
				.format(new Date());
		String fileName = String.format(format, formatedDate);
		File outfile = new File(path + separator + fileName);
		OutputStream out = new FileOutputStream(outfile);
		JAXBContext jc = JAXBContext.newInstance(Task.class);
		Marshaller marshaller = jc.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.marshal(task, out);
	}

	public static final void toConsole(Task task) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance(Task.class);
		Marshaller marshaller = jc.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.marshal(task, System.out);
	}

	public static final String toString(Task task) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance(Task.class);
		Marshaller marshaller = jc.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		StringWriter writer = new StringWriter();
		marshaller.marshal(task, writer);
		return writer.toString();
	}

	public static final void toConsole(Result result) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance(Result.class);
		Marshaller marshaller = jc.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.marshal(result, System.out);
	}

	public static final String toString(Result result) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance(Result.class);
		Marshaller marshaller = jc.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		StringWriter writer = new StringWriter();
		marshaller.marshal(result, writer);
		return writer.toString();
	}

	public static final void toFile(Result result, String separator,
			String path, String format) throws JAXBException,
			FileNotFoundException {
		String formatedDate = new SimpleDateFormat("yyyyMMddhhmmss")
				.format(new Date());
		String fileName = String.format(format, formatedDate);
		File outfile = new File(path + separator + fileName);
		OutputStream out = new FileOutputStream(outfile);
		JAXBContext jc = JAXBContext.newInstance(Result.class);
		Marshaller marshaller = jc.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.marshal(result, out);
	}

}
