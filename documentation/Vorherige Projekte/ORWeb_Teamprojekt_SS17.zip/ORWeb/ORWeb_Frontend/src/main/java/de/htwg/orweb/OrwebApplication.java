package de.htwg.orweb;

import de.htwg.orweb.storage.StorageProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import java.util.Locale;

@SpringBootApplication
@EnableConfigurationProperties(StorageProperties.class)
public class OrwebApplication {

    public static String SOLVER_CFG_PATH;

    public static void main(String[] args) {
        SpringApplication.run(OrwebApplication.class, args);
        if (args[0] == null || args[0].equals("")) {
            System.out.println(
                    "Invalid parameters provided.\nPlease provide the absolut path to your ORWeb_LPS configuration file (.properties)");
        }
        SOLVER_CFG_PATH = args[0];
    }

    /*
    @Bean
    CommandLineRunner init(StorageService storageService) {
        return (args) -> {
            storageService.deleteAll();
            storageService.init();
        };
    }
    */
}