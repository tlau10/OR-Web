/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.controller;

import de.htwg.orweb.form.UploadForm;
import de.htwg.orweb.form.UserForm;
import de.htwg.orweb.model.Download;
import de.htwg.orweb.model.Method;
import de.htwg.orweb.model.Solver;
import de.htwg.orweb.model.User;
import de.htwg.orweb.service.IDownloadService;
import de.htwg.orweb.service.IMethodService;
import de.htwg.orweb.service.ISolverService;
import de.htwg.orweb.storage.StorageFileNotFoundException;
import de.htwg.orweb.storage.StorageService;
import de.htwg.orweb.validator.UploadValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

@Controller
public class FileUploadController {

    @Autowired
    private IMethodService methodService;
    @Autowired
    private IDownloadService downloadService;
    @Autowired
    private ISolverService solverService;
    @Autowired
    private UploadValidator uploadValidator;
    @Autowired
    private MessageSource messageSource;

    private final StorageService storageService;

    @Autowired
    public FileUploadController(StorageService storageService) {
        this.storageService = storageService;
    }

    @GetMapping("/admin/upload")
    public ModelAndView listUploadedFiles(Model model, UploadForm uploadForm) throws IOException {

        ModelAndView modelAndView = new ModelAndView();

        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true, "method");
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true, "solver");

        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);


        model.addAttribute("files", storageService
                .loadAll()
                .map(path ->
                        MvcUriComponentsBuilder
                                .fromMethodName(FileUploadController.class, "serveFile", path.getFileName().toString())
                                .build().toString())
                .collect(Collectors.toList()));

        modelAndView.setViewName("admin/upload");

        return modelAndView;
    }

    @GetMapping("/files/{filename:.+}")
    @ResponseBody
    public ResponseEntity<Resource> serveFile(@PathVariable String filename) {

        Resource file = storageService.loadAsResource(filename);

        return ResponseEntity
                .ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
                .body(file);
    }

    @PostMapping("/admin/upload")
    public ModelAndView handleFileUpload(RedirectAttributes redirectAttributes, @Valid UploadForm uploadForm, BindingResult bindingResult, Locale locale) {

        ModelAndView modelAndView = new ModelAndView();

        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true, "method");
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true, "solver");

        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);

        uploadValidator.validate(uploadForm, bindingResult);

        if (bindingResult.hasErrors()) {
            modelAndView.addObject("name", uploadForm.getName());
            modelAndView.addObject("desc", uploadForm.getDesc());
            modelAndView.addObject("active", uploadForm.isActive());
            modelAndView.addObject("type", uploadForm.getType());

            modelAndView.setViewName("admin/upload");
        } else {

            storageService.store(uploadForm.getPath());
            storageService.store(uploadForm.getPathImage());

            Boolean active = false;
            if (uploadForm.isActive()) {
                active = true;
            }

            Download download = new Download();
            download.setActive(active);
            download.setType(uploadForm.getType());
            download.setDesc(uploadForm.getDesc());
            download.setEmail(uploadForm.getEmail());
            download.setName(uploadForm.getName());
            download.setPath(uploadForm.getPath().getOriginalFilename());
            download.setPathImage(uploadForm.getPathImage().getOriginalFilename());
            download.setType(uploadForm.getType());

            downloadService.saveDownload(download);

            redirectAttributes.addFlashAttribute("message", messageSource.getMessage("download.add.success.message",new String[] {}, locale));

            modelAndView.setViewName("redirect:/admin/downloads");
        }

        return modelAndView;
    }


    @GetMapping("/admin/upload/edit/{id}")
    public ModelAndView editUploadedFiles(@PathVariable("id") int id, Model model, UploadForm uploadForm) throws IOException {

        ModelAndView modelAndView = new ModelAndView();

        Download download = downloadService.findDownloadById(id);

        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true, "method");
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true, "solver");

        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);

        modelAndView.addObject("downloadId", id);
        modelAndView.addObject("name", download.getName());
        modelAndView.addObject("desc", download.getDesc());
        modelAndView.addObject("active", download.isActive());
        modelAndView.addObject("type", download.getType());
        modelAndView.addObject("file", download.getPath());
        modelAndView.addObject("image", download.getPathImage());


        model.addAttribute("files", storageService
                .loadAll()
                .map(path ->
                        MvcUriComponentsBuilder
                                .fromMethodName(FileUploadController.class, "serveFile", path.getFileName().toString())
                                .build().toString())
                .collect(Collectors.toList()));

        modelAndView.setViewName("admin/editUpload");

        return modelAndView;
    }

    @PostMapping("/admin/upload/edit")
    public ModelAndView postEditUpload(@Valid UploadForm uploadForm, BindingResult bindingResult, RedirectAttributes redirectAttributes, Locale locale) {

        ModelAndView modelAndView = new ModelAndView();

        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true,"method");
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true,"solver");

        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);

        uploadValidator.validateEdit(uploadForm, bindingResult);
        Download download = downloadService.findDownloadById(uploadForm.getId());

        if (bindingResult.hasErrors()) {

            modelAndView.addObject("name", uploadForm.getName());
            modelAndView.addObject("desc", uploadForm.getDesc());
            modelAndView.addObject("active", uploadForm.isActive());
            modelAndView.addObject("type", uploadForm.getType());
            modelAndView.addObject("file", uploadForm.getPath().getOriginalFilename());
            modelAndView.addObject("image", uploadForm.getPathImage().getOriginalFilename());

            modelAndView.setViewName("admin/editUpload");
        } else {

            download.setName(uploadForm.getName());
            download.setDesc(uploadForm.getDesc());
            download.setEmail(uploadForm.getEmail());
            download.setActive(uploadForm.isActive());
            download.setType(uploadForm.getType());

            if (!uploadForm.getPath().isEmpty()) {
                storageService.deleteFile(download.getPath());
                storageService.store(uploadForm.getPath());
                download.setPath(uploadForm.getPath().getOriginalFilename());
            }
            if (!uploadForm.getPathImage().isEmpty()) {
                storageService.deleteFile(download.getPathImage());
                storageService.store(uploadForm.getPathImage());
                download.setPathImage(uploadForm.getPathImage().getOriginalFilename());
            }

            downloadService.saveDownload(download);

            redirectAttributes.addFlashAttribute("message", messageSource.getMessage("download.edit.success.message",new String[] {}, locale));
            modelAndView.setViewName("redirect:/admin/downloads");
        }
        return modelAndView;
    }

    @GetMapping("/admin/upload/delete/{id}")
    public ModelAndView deleteUpload(@PathVariable("id") int id, RedirectAttributes redirectAttributes, Locale locale) {

        ModelAndView modelAndView = new ModelAndView();
;
        Download upload = downloadService.findDownloadById(id);

        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true,"method");
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true,"solver");
        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);

        storageService.deleteFile(upload.getPath());
        storageService.deleteFile(upload.getPathImage());
        downloadService.deleteDownload(upload);

        redirectAttributes.addFlashAttribute("message", messageSource.getMessage("download.delete.success.message",new String[] {}, locale));
        modelAndView.setViewName("redirect:/admin/downloads");
        return modelAndView;
    }

    @ExceptionHandler(StorageFileNotFoundException.class)
    public ResponseEntity handleStorageFileNotFound(StorageFileNotFoundException exc) {
        return ResponseEntity.notFound().build();
    }

}
