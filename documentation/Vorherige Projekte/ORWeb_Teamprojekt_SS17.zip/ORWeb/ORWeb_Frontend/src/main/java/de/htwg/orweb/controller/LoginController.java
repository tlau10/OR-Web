/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.controller;

import java.util.List;

import de.htwg.orweb.model.Download;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import de.htwg.orweb.model.Method;
import de.htwg.orweb.model.Solver;
import de.htwg.orweb.model.User;
import de.htwg.orweb.service.IDownloadService;
import de.htwg.orweb.service.IMethodService;
import de.htwg.orweb.service.ISolverService;
import de.htwg.orweb.service.IUserService;

@Controller
public class LoginController {

    @Autowired
    private IMethodService methodService;
    @Autowired
    private IDownloadService downloadService;
    @Autowired
    private ISolverService solverService;
    @Autowired
    private IUserService userService;

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public ModelAndView login() {
        ModelAndView modelAndView = new ModelAndView();

        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true,"method");
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true,"solver");

        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);

        modelAndView.setViewName("login");
        return modelAndView;
    }

    @RequestMapping(value = "/admin", method = RequestMethod.GET)
    public ModelAndView home() {
        ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        User user = userService.findUserByEmail(auth.getName());

        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true,"method");
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true,"solver");

        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);

        if (user != null) {
            modelAndView.addObject("userName", "Willkommen " + user.getFirstName() + " " + user.getLastName() + " " + " (" + user.getEmail() + ")");
        } else {
            modelAndView.addObject("adminMessage", "Content Available Only for Users with Admin Role");
        }

        modelAndView.setViewName("admin");
        return modelAndView;
    }

}
