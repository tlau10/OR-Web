/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.repository;

import java.util.List;

import de.htwg.orweb.model.Method;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import de.htwg.orweb.model.Solver;

@Repository("solverRepository")
public interface SolverRepository extends JpaRepository<Solver, Long> {
    List<Solver> findAll();
    List<Solver> findByActive(boolean bool);
    Solver findById(int id);
    Solver findByName(String name);
    Solver findByPath(String path);
}