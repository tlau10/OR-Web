/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.service;

import de.htwg.orweb.model.ChartVisited;

public interface IChartVisitedService {

	public ChartVisited findChartVisitedById(int id);
	public void saveChartVisited(ChartVisited chartVisited);
}
