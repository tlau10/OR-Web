/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.service;

import java.util.List;

import de.htwg.orweb.model.Download;

public interface IDownloadService {

	public List<Download> findAllDownloads();
	public List<Download>  findAllDownloadByType(String type);
	public List<Download>  findAllDownloadByActiveAndType(boolean bool, String type);
	public List<Download>  findAllDownloadByActive(boolean bool);
	public Download findDownloadById(int id);
	public Download  findDownloadByName(String name);
	public Download  findDownloadByPathImage(String pathImage);
	public Download  findDownloadByPath(String path);
	public void deleteDownload(Download download);
	public Download saveDownload(Download methodDownload);
}
