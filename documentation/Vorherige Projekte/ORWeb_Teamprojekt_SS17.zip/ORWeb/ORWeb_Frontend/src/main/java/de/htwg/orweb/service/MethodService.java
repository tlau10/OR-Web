/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import de.htwg.orweb.model.Method;
import de.htwg.orweb.repository.MethodRepository;

@Service("methodService")
public class MethodService implements IMethodService {

    @Autowired
    private MethodRepository methodRepository;


	@Override
	public List<Method> findAllMethods() {
		return methodRepository.findAll();
		
	}

	@Override
	public Method findMethodByName(String name) {
		return methodRepository.findByName(name);
	}

	@Override
	public Method findMethodById(int id) {
		return methodRepository.findById(id);
	}

	@Override
	public Method findMethodByPath(String path) {
		return methodRepository.findByPath(path);
	}

	@Override
	public List<Method> findMethodByActive(boolean bool) {
		return methodRepository.findByActive(bool);
	}

	@Override
	public void saveMethod(Method method) {
		methodRepository.save(method);
	}

}
