/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import de.htwg.orweb.model.Solver;
import de.htwg.orweb.repository.SolverRepository;

@Service("solverService")
public class SolverService implements ISolverService {

    @Autowired
    private SolverRepository solverRepository;


	@Override
	public List<Solver> findAllSolvers() {
		return solverRepository.findAll();
	}

	@Override
	public Solver findSolverByName(String name) {
		return solverRepository.findByName(name);
	}

	@Override
	public List<Solver> findSolverByActive(boolean bool) {
		return solverRepository.findByActive(bool);
	}

	@Override
	public Solver findMethodById(int id) {
		return solverRepository.findById(id);
	}

	@Override
	public Solver findSolverByPath(String path) {
		return solverRepository.findByPath(path);
	}

	@Override
	public void saveSolver(Solver solver) {
		solverRepository.save(solver);
	}

}