/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */
/* ###############################################################################
 *
 * toastr is used for the messages on the right border if ajax failed
 * and for the solver info & error messages
 *
 */

// init toastr messages, needed in the solver and for the ajax error message
toastr.options.timeOut = 3000; // How long the toast will display without user interaction
toastr.options.extendedTimeOut = 1000; // How long the toast will display after a user hovers over it
toastr.options.positionClass = "toast-bottom-right";
toastr.options.newestOnTop = true;

(function () {
// https://stackoverflow.com/a/27363569
    var origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function () {

        $('#spinner-modal').modal({keyboard: false});
        $('#spinner-modal').modal('show');

        // The load event is fired when a resource has finished loading.
        this.addEventListener('load', function () {
            $('#spinner-modal').modal('hide');
        });

        this.addEventListener('error', function () {
            $('#spinner-modal').modal('hide');
            toastr.info("Server Error");
        });

        this.addEventListener('abort', function () {
            $('#spinner-modal').modal('hide');
            // todo: übersetzen
            toastr.info("Anfrage wurde abgebrochen");
        });

        origOpen.apply(this, arguments);
    };
})();
