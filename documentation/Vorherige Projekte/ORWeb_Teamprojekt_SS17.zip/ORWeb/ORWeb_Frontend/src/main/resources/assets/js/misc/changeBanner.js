/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

/**
 * @author mirko bay, 2017-06-21
 *
 * set the top banner of the site in english, if the browser of the page visitor
 * got another language than german.
 *
 * javascript can just detect the browser language, system language is not accessible
 *
 */

window.onload = function () {

    var langRaw = navigator.languages[0];
    var lang = langRaw.substr(0, 2);
    var bannerFileName = "/img/banner-new_en.svg";

    var mq = window.matchMedia("(max-width: 565px)");
    if (mq.matches) {
        bannerFileName = "/img/banner-new_en-mobile.svg";
    }


    if (lang !== "de") {
        if (Cookies.get('theme') !== undefined) {
            // set old international banner
            if (mq.matches) {
                bannerFileName = "/img/banner-old_en-mobile.svg";
            } else {
                bannerFileName = "/img/banner-old_en.svg";
            }
        }
        var bannerElement = document.getElementById("header-banner");
        bannerElement.style.backgroundImage = "url('" + bannerFileName + "')";
    }
};