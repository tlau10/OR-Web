/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

/**
 * @author mirko bay, 2017-06-21
 *
 * this script shortened the text in the solver descriptions;
 * it make use of thymeleaf translate variables, defined in the layout.html
 *
 */


// http://viralpatel.net/blogs/2010/12/dynamically-shortened-text-show-more-link-jquery.html
$(document).ready(function () {

    var mq = window.matchMedia("(max-width: 991px)");
    var showChar = 200;
    if (mq.matches) {
        showChar = 70;
    }


    var ellipsestext = " ...";

    $('#solverDescription').each(function () {

        var content = $(this).html();
        if (content.length > showChar) {

            var c = content.substr(0, showChar);
            var h = content.substr(showChar, content.length - showChar);

            var html = c + '<span class="moreellipses">' + ellipsestext + '&nbsp;</span>' +
                '<span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">' + moretext + '</a></span>';

            $(this).html(html);
        }

    });

    $(".morelink").click(function () {
        if ($(this).hasClass("less")) {
            $(this).removeClass("less");
            $(this).html(moretext);
        } else {
            $(this).addClass("less");
            $(this).html(lesstext);
        }
        $(this).parent().prev().toggle();
        $(this).prev().toggle();
        return false;
    });
});

