/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

function chartVisisted() {

    var pieData = [ {
        value :de,
        color :'#000000',
        highlight :'#3a3a3a',
        label :deName
    }, {
        value :en,
        color :'#706c6c',
        highlight :'#bdbdc0',
        label :enName
    }, {
        value :it,
        color :'#0f6d1a',
        highlight :'#13d84b',
        label :itName
    }, {
        value :es,
        color :'#ede510',
        highlight :'#e8e471',
        label :esName
    }, {
        value :fr,
        color :'#0911f4',
        highlight :'#1a65f4',
        label :frName
    }, {
        value :tr,
        color :'#bf0d0d',
        highlight :'#f40909',
        label :trName
    }, {
        value :ru,
        color :'#a01497',
        highlight :'#ed15de',
        label :ruName
    }, {
        value :other,
        color :'#d35608',
        highlight :'#ff6100',
        label :otherName
    }
    ];
    window.onload = function() {
        var ctx = document.getElementById("chart-area")
            .getContext("2d");
        window.myPie = new Chart(ctx).Pie(pieData);
        document.getElementById('js-legend').innerHTML = window.myPie.generateLegend();
    };
}