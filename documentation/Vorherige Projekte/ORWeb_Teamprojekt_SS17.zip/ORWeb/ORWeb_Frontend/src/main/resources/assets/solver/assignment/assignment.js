/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

// HTMLTableElement: holds the reference to the html table
var matrixTable;
// number: the current amount of Variables (= columns)
var numbOfVariables;
// number: the current amount of constraints (=rows)
var numbOfConstraints;

function init() {
    matrixTable = document.getElementById("matrix");
    numbOfVariables = document.getElementById("numbOfVariables").value;
    numbOfConstraints = document.getElementById("numbOfConstraints").value;

    EventHandler.initEventHandler();

    // create the header element, depending on the amount of variables
    TableManipulator.createMatrixHeader();

    // create rows for the constraints
    for (var i = 0; i < numbOfConstraints; i++) {
        TableManipulator.addConstraint(i + 1);
    }

}

/**
 * load a example task
 */
function loadExample() {
    // reset the size of the table
    TableManipulator.reset();


    // job 0 = [1, 1]
    // job 1 = [2, 1]
    var rows = matrixTable.rows;
    // row[0] is the header
    rows[1].childNodes[1].firstElementChild.value = 1;
    rows[1].childNodes[2].firstElementChild.value = 2;

    rows[2].childNodes[1].firstElementChild.value = 3;
    rows[2].childNodes[2].firstElementChild.value = 4;
}


/**
 * checks the validity of the matrix (with the native html5 form validation
 *
 * @return {boolean}
 */
function checkIfTableIsValid() {

    // check the tableau table
    var tableauForm = document.getElementById("matrixForm");
    if (!tableauForm.checkValidity()) {
        // triggers the native html5 form validation
        var submitButtonTableau = document.getElementById("submitButton");
        submitButtonTableau.click();
        return false;
    } else {
        return true;
    }

}

/**
 * checks the user input live against the pattern
 *
 * @returns
 */
function checkUserNumberInput(event) {

    var input = event.target.value;
    var regex = new RegExp("^[0-9]$", "g");
    // if invalid input
    if (input.length === 0) {
        return;
    }

    // triggers the native html5 form validation
    var submitButton;
    document.getElementById("submitButton").click();
}
