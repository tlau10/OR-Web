/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

var ExportUtil = (function () {

    var resultObject;

    function exportTable() {

        // create the task object
        var task = createTaskObject();
        // and send it to the server
        sendTaskToServer(task, showDownloadDialog);
    }

    function showDownloadDialog() {
    	   var now = new Date();
           download(resultObject.model.mpsModel, "iterator_"
               + now.getFullYear()
               + (now.getMonth() + 1)
               + now.getUTCDate()
               + now.getHours()
               + now.getMinutes()
               + ".mps", "application/x-mps");
    }

    function createTaskObject() {

        // copy values from the html table to the matrix
        getValuesFromTableToMatrix();

        // create a task object for the solver
        var task = {};
        // add the meta attributes
        task.meta = {};
        // value is not necessary
        task.meta.solver = "cbc";

        // add the objective
        task.objective = {};
        task.objective.type = "max";
        task.objective.variables = [];

        // collect all data from the objective
        var objectiveRow = matrix[matrix.length - 1];
        // iterate over the objective row
        for (var i = 0; i < objectiveRow.length-1; i++) {
            var tmp = {};
            tmp.name = "x" + (i);
            tmp.coefficient = objectiveRow[i].round(5).toString();
            task.objective.variables.push(tmp);
        }

        // collect all data from the constraints
        task.constraints = [];

        for (var i = 0; i < matrix.length - 1; i++) {
            var row = matrix[i];

            // create a constraint object
            var tmpConstraint = {};
            tmpConstraint.name = "R" + (i + 1);
            tmpConstraint.variables = [];
            // iterate over the cells of the row
            for (var j = 0; j < row.length - 1; j++) {
                var tmpVariable = {};
                tmpVariable.name = "x" + (j);
                tmpVariable.coefficient = row[j].round(5).toString();
                tmpConstraint.variables.push(tmpVariable);
            }

            tmpConstraint.type = "L";
            tmpConstraint.rhs = row[row.length - 1].round(5).toString();

            task.constraints.push(tmpConstraint);
        }

        // create a empty bounds array
        task.bounds = [];

        return task;
    }

    /**
     *
     * @param task: the task as a javascript object, specified in the example at top
     * @param showResponse: show the response to the user or not
     * @returns
     */
    function sendTaskToServer(task, callback) {

        // make ajax call to solve the task
        var xhr = window.XMLHttpRequest ? new XMLHttpRequest()
            : new ActiveXObject('Microsoft.XMLHTTP');
        xhr.open("POST", "solve");

        xhr.onreadystatechange = function () {

            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    // 'This is the returned text.'
                    resultObject = JSON.parse(xhr.responseText);
                    callback();
                } else {
                    // now called in the /js/spinner/ajaxSpinner.js
                    //toastr.info("Error " + xhr.status);
                }
            }


        };

        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(JSON.stringify(task));
    }


    return {
        exportTable: exportTable
    };


})();