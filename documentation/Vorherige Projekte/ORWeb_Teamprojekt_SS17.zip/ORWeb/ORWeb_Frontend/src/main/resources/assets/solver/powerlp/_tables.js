/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */
var TableManipulator = (function () {

    /**
     *
     * creates initial the thead element for the tableau table
     *
     * @returns void
     */
    function createTableauHeader() {
        // createTHead() returns the existing <thead> element
        var header = tableau.createTHead();
        var headerRow = header.insertRow();
        headerRow.id = "tableauHeader";
        headerRow.insertCell(0); // the first cell is empty

        for (var i = 0; i < numbOfVariables; i++) {
            var cell = headerRow.insertCell();
            cell.innerHTML = "x<sub>" + (i + 1) + "</sub>";
        }
        headerRow.insertCell();
        headerRow.insertCell().innerHTML = "b";
    }


    /**
     * creates initial the thead element for the bounds table
     *rightHand
     * @returns
     */
    function createBoundsHeader() {
        var header = bounds.createTHead();
        var headerRow = header.insertRow();

        headerRow.insertCell().innerHTML = headerBoundsVariable;
        headerRow.insertCell().innerHTML = headerBoundsLower;
        headerRow.insertCell().innerHTML = headerBoundsUpper;
        headerRow.insertCell().innerHTML = headerBoundsInteger;

    }

    /**
     *
     * creates initial the row for the target function for the tableau table
     *
     * @returns void
     */
    function createObjectiveFunction() {

        var targetFunction = tableau.getElementsByTagName('tbody')[0].insertRow();
        targetFunction.id = "targetFunction";
        var lineHeading = targetFunction.insertCell();
        lineHeading.innerHTML = headerTableauTargetFunction;

        for (var i = 0; i < numbOfVariables; i++) {
            var tempCell = targetFunction.insertCell();
            tempCell.appendChild(createInputElement(0, "tableau"));
        }

        targetFunction.insertCell().innerHTML = "→";
        var rightHand = targetFunction.insertCell();
        rightHand.appendChild(createMinMaxSelector());
    }

    /**
     * reset the two tables and set the default size of 2 variables & constraints
     *
     * @returns
     */
    function reset() {

        numbOfVariables = 2;
        numbOfConstraints = 2;

        document.getElementById("numbOfVariables").value = numbOfVariables;
        document.getElementById("numbOfConstraints").value = numbOfConstraints;

        // remove the content of the thead
        while (tableau.firstElementChild.hasChildNodes()) {
            tableau.firstElementChild
                .removeChild(tableau.firstElementChild.lastChild);
        }
        // and the tbody of the tableau
        while (tableau.lastElementChild.hasChildNodes()) {
            tableau.lastElementChild
                .removeChild(tableau.lastElementChild.lastChild);
        }
        // remove the whole content of the bounds table
        while (bounds.hasChildNodes()) {
            bounds.removeChild(bounds.lastChild);
        }

        // make the same things like in the init() function

        // create the header element, depending on the amount of variables
        TableManipulator.createTableauHeader();
        TableManipulator.createBoundsHeader();

        // same for the target function
        TableManipulator.createObjectiveFunction();

        // create rows for the constraints
        for (var i = 0; i < numbOfConstraints; i++) {
            TableManipulator.addConstraint(i + 1);
        }

        // create rows for the bounds
        for (var j = 0; j < numbOfVariables; j++) {
            bounds.appendChild(createNewBoundsRow(j + 1));
        }
    }

    /**
     *
     * @param numb :
        *            used for the id of the row
     * @returns
     */
    function addConstraint(numb) {
        var tableauRow = tableau.insertRow();
        tableauRow.id = "constraint_" + numb;
        tableauRow.setAttribute("class", "constraint");

        var lineHeading = tableauRow.insertCell();
        lineHeading.innerHTML = headerTableauConstraintRow + " " + numb;

        for (var i = 0; i < numbOfVariables; i++) {
            var tempCell = tableauRow.insertCell();
            tempCell.appendChild(createInputElement(0, "tableau"));
        }
        var operator = tableauRow.insertCell();
        operator.appendChild(createOperatorSelectorElement());
        var rightHand = tableauRow.insertCell();
        rightHand.appendChild(createInputElement(0, "tableau"));
    }

    /**
     *
     * @returns
     */
    function removeConstraint() {
        // tableau
        var tableauBody = document.getElementById("tableauBody");
        var constraintRows = document.getElementsByClassName("constraint");
        constraintRows[0].parentNode.removeChild(constraintRows
            .item(constraintRows.length - 1));
    }

    /**
     *
     * adds a new variable to the tableau and the bounds table
     *
     * @returns
     */
    function addVariable() {

        // tableau header
        var headerRow = document.getElementById("tableauHeader");
        headerRow.deleteCell(-1);
        headerRow.deleteCell(-1);

        var tmpCell = headerRow.insertCell();
        tmpCell.innerHTML = "x<sub>" + numbOfVariables + "</sub>";

        headerRow.insertCell();
        headerRow.insertCell().innerHTML = "b";

        // objective function
        var targetFunctionRow = document.getElementById("targetFunction");
        var objectiveRowCells = targetFunctionRow.cells;
        var operatorObjectiveSelector = objectiveRowCells.item(objectiveRowCells.length-1).lastChild;
        var operatorObjective = operatorObjectiveSelector.options[operatorObjectiveSelector.selectedIndex].value;

        targetFunctionRow.deleteCell(-1);
        targetFunctionRow.deleteCell(-1);

        var cell = targetFunctionRow.insertCell();
        cell.appendChild(createInputElement(0, "tableau"));

        targetFunctionRow.insertCell().innerHTML = "→";
        var rhs = targetFunctionRow.insertCell();
        rhs.appendChild(createMinMaxSelector(operatorObjective));

        // extend constraints row
        var constraintRows = document.getElementsByClassName("constraint");
        for (var i = 0; i < constraintRows.length; i++) {

            // remove the right hand side
            var valueOfRightHandSide = constraintRows[i].lastChild.lastChild.value;
            constraintRows[i].deleteCell(-1);

            // remove the operator select
            var operatorSelector = constraintRows[i].lastChild.lastChild;
            var operator = operatorSelector.options[operatorSelector.selectedIndex].value;
            constraintRows[i].deleteCell(-1);

            // add the cell for the new variable
            var newCell = constraintRows[i].insertCell();
            newCell.appendChild(createInputElement(0, "tableau"));

            // add the operator
            var operatorCell = constraintRows[i].insertCell();
            operatorCell.appendChild(createOperatorSelectorElement(operator));
            // add the right hand side value
            var rightHand = constraintRows[i].insertCell();
            rightHand.appendChild(createInputElement(valueOfRightHandSide, "tableau"));
        }

        // extend bounds table
        bounds.appendChild(createNewBoundsRow(numbOfVariables));

    }

    /**
     *
     * remove a single variable (with saving the value of the righthandside)
     *
     * @returns
     */
    function removeVariable() {

        // tablaeu header
        var headerRow = document.getElementById("tableauHeader");

        headerRow.deleteCell(-1);
        headerRow.deleteCell(-1); // two times for the "right hand side"
        headerRow.deleteCell(-1); // one time for the deleted variable

        headerRow.insertCell();
        headerRow.insertCell().innerHTML = "b";

        // target function
        var targetFunctionRow = document.getElementById("targetFunction");
        var objectiveRowCells = targetFunctionRow.cells;
        var operatorObjectiveSelector = objectiveRowCells.item(objectiveRowCells.length-1).lastChild;
        var operatorObjective = operatorObjectiveSelector.options[operatorObjectiveSelector.selectedIndex].value;

        targetFunctionRow.deleteCell(-1);
        targetFunctionRow.deleteCell(-1);
        targetFunctionRow.deleteCell(-1);

        targetFunctionRow.insertCell().innerHTML = "→";
        var rhs = targetFunctionRow.insertCell();
        rhs.appendChild(createMinMaxSelector(operatorObjective));

        // constraints
        var constraintRows = document.getElementsByClassName("constraint");
        for (var i = 0; i < constraintRows.length; i++) {

            // remove the right hand side
            var valueOfRightHandSide = constraintRows[i].lastChild.lastChild.value;
            constraintRows[i].deleteCell(-1);
            // remove the operator select
            var operatorSelector = constraintRows[i].lastChild.lastChild;
            var operator = operatorSelector.options[operatorSelector.selectedIndex].value;
            constraintRows[i].deleteCell(-1);
            // remove the removed variable ;)
            constraintRows[i].deleteCell(-1);

            // add the operator
            var operatorCell = constraintRows[i].insertCell();
            operatorCell.appendChild(createOperatorSelectorElement(operator));
            // add the right hand side value
            var rightHand = constraintRows[i].insertCell();
            rightHand.appendChild(createInputElement(valueOfRightHandSide, "tableau"));
        }

        // bounds
        bounds.removeChild(bounds.lastElementChild);
    }

    return {
        addVariable: addVariable,
        addConstraint: addConstraint,
        removeVariable: removeVariable,
        removeConstraint: removeConstraint,
        reset: reset,
        createTableauHeader: createTableauHeader,
        createBoundsHeader: createBoundsHeader,
        createObjectiveFunction: createObjectiveFunction
    };

})();