/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

var whichSolver;
var tableau;
var bounds;
var numbOfVariables;
var numbOfConstraints;
var resultObject;

/**
 * initializes the tables and add the eventhandler
 *
 * @returns
 */
function init() {
    tableau = document.getElementById("tableau");
    whichSolver = document.getElementById("solverSelection");
    bounds = document.getElementById("bounds");

    numbOfVariables = document.getElementById("numbOfVariables").value;
    numbOfConstraints = document.getElementById("numbOfConstraints").value;

    EventHandler.initEventHandler();

    // create the header element, depending on the amount of variables
    TableManipulator.createTableauHeader();
    TableManipulator.createBoundsHeader();

    // same for the target function
    TableManipulator.createObjectiveFunction();

    // create rows for the constraints
    for (var i = 0; i < numbOfConstraints; i++) {
        TableManipulator.addConstraint(i + 1);
    }

    // create rows for the bounds
    for (var j = 0; j < numbOfVariables; j++) {
        bounds.appendChild(createNewBoundsRow(j + 1));
    }
}

/**
 * checks the validity of the matrix (with the native html5 form validation
 *
 * @return {boolean}
 */
function checkIfTableIsValid() {

    // check the tableau table
    var tableauForm = document.getElementById("tableauForm");
    if (!tableauForm.checkValidity()) {
        //alert("Ungültige Werte in Matrix!");
        // triggers the native html5 form validation
        var submitButtonTableau = document.getElementById("submitButtonTableau");
        submitButtonTableau.click();
        return false;
    } else {
        // check the bounds table
        if (!tableauForm.checkValidity()) {
            //alert("Ungültige Werte in Matrix!");
            // triggers the native html5 form validation
            var submitButtonBounds = document.getElementById("submitButtonBounds");
            submitButtonBounds.click();
            return false;
        }
        else {
            return true;
        }
    }

}

/**
 * checks the user input live against the pattern for a rational number so the
 * user can just type following number types: > integer, e.g. "1" > float, e.g.
 * "3/4" > mixed float, e.g. "3,2/4" or "3/4,2" > input with both comma and dot
 *
 * @returns
 */
function checkUserNumberInput(event, form) {

    var input = event.target.value;
    var regex = new RegExp("^[\\-]{0,1}[0-9]{1,}((,|\.)[0-9]{1,}){0,1}((/0(,|\.)([1-9]{1,}[0-9]{0,}|[0-9]{1,}[1-9]))|(/[1-9]{1,}((,|\.)[0-9]{1,}){0,1})){0,1}$", "g");
    // if invalid input
    if (input.length === 0) {
        return;
    }

    // TODO : 	bisher wird pauschal immer der Click durchgeführt für die Validation-Message
    //			besser wäre, wenn das nur passiert wenn die Regex nicht erfüllt wird

    // triggers the native html5 form validation
    var submitButton;
    if (form === "tableau") {
        submitButton = document.getElementById("submitButtonTableau");
    } else {
        submitButton = document.getElementById("submitButtonBounds");
    }

    submitButton.click();
}

/**
 *
 * set the default example of the grütz or lecture
 * to the html table and set the values also to the matrix array
 *
 * @returns : void
 */
// todo: set the min max selector for the constraints
function setDefaultExampleToTable() {

    TableManipulator.reset();

    var rows = tableau.rows;
    // row[0] is the header
    rows[1].childNodes[1].firstElementChild.value = 1;
    rows[1].childNodes[2].firstElementChild.value = 2;
    rows[1].childNodes[4].firstElementChild.value = "max";


    rows[2].childNodes[1].firstElementChild.value = 3;
    rows[2].childNodes[2].firstElementChild.value = 2;
    rows[2].childNodes[4].firstElementChild.value = 12;

    rows[3].childNodes[1].firstElementChild.value = 1;
    rows[3].childNodes[2].firstElementChild.value = 3;
    rows[3].childNodes[4].firstElementChild.value = 9;

}

/*
 * ###########################################################
 * 
 * HELPER METHODS
 * 
 * for creating input and select elements for additional table rows / cells
 * 
 * ###########################################################
 */

/**
 *
 * @param value{number}
 * @param form
 * @return {Element}
 */
function createInputElement(value, form) {

    var element = document.createElement("input");
    //element.type = "number";
    element.value = value;
    element.pattern = "^[-]?[0-9]+((,|\.)[0-9]+)?((\/0(,|\.)([1-9]+[0-9]*|[0-9]+[1-9]))|(\/[1-9]+((,|\.)[0-9]+)?))?$";
    element.title = validationMessage;
    element.required = true;


    element.addEventListener("click", function () {
        this.select();
    });

    element.addEventListener("keyup", function (event) {
        checkUserNumberInput(event,form);
    });

    if (form === "bounds") {
        // min value is here 0, so no negative numbers allowed
        element.pattern = "^[0-9]+((,|\.)[0-9]+)?((\/0(,|\.)([1-9]+[0-9]*|[0-9]+[1-9]))|(\/[1-9]+((,|\.)[0-9]+)?))?$";
        element.required = false;
    }

    return element;
}

/**
 *
 * creates and return the selector element for the operator
 *
 * @param operatorSelected:
 *            optional: the initial value of the created selector element
 * @returns
 */
function createOperatorSelectorElement(operatorSelected) {

    var element = document.createElement("select");

    var optionLowerThan = document.createElement("option");
    optionLowerThan.value = "L";
    optionLowerThan.text = "<=";

    var optionGreaterThan = document.createElement("option");
    optionGreaterThan.value = "G";
    optionGreaterThan.text = ">=";

    var optionEquals = document.createElement("option");
    optionEquals.value = "E";
    optionEquals.text = "==";

    element.appendChild(optionLowerThan);
    element.appendChild(optionGreaterThan);
    element.appendChild(optionEquals);

    if (typeof operatorSelected !== 'undefined') {
        element.value = operatorSelected;
    }

    return element;
}

/**
 * creates and return the min max selector for the target function
 *
 * @returns
 */
function createMinMaxSelector(selectedOpt) {
    var element = document.createElement("select");
    element.id = "minMaxSelector";

    var optionMin = document.createElement("option");
    optionMin.value = "min";
    optionMin.text = "min";

    var optionMax = document.createElement("option");
    optionMax.value = "max";
    optionMax.text = "max";

    element.appendChild(optionMin);
    element.appendChild(optionMax);

    if (typeof selectedOpt !== 'undefined') {
        element.value = selectedOpt;
    }

    return element;
}

/**
 *
 * create and return a new row for the bounds table
 *
 * @param variableNumb
 * @returns
 */
function createNewBoundsRow(variableNumb) {
    // row
    var element = document.createElement("tr");
    element.id = "bound_" + variableNumb;
    element.setAttribute("class","bound");


    // line heading
    var variableName = document.createElement("td");
    variableName.innerHTML = "x<sub>" + variableNumb + "</sub>";

    // input lower bound
    var lowerInput = document.createElement("td");
    var inputElementLower = createInputElement("", "bounds");
    inputElementLower.type = "text";
    lowerInput.appendChild(inputElementLower);

    // input upper bound
    var upperInput = document.createElement("td");
    var inputElementUpper = createInputElement("", "bounds");
    inputElementUpper.type = "text";
    upperInput.appendChild(inputElementUpper);

    // is integer
    var integer = document.createElement("td");
    var checkBox = document.createElement("input");
    checkBox.type = "checkbox";
    integer.appendChild(checkBox);

    element.appendChild(variableName);
    element.appendChild(lowerInput);
    element.appendChild(upperInput);
    element.appendChild(integer);

    return element;
}