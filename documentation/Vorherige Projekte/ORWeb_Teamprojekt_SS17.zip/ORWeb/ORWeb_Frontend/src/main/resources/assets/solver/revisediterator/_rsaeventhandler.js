/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */
var EventHandler = (function () {

    /**
     * validates the user input for creating new variables (no value smaller than 1
     * allowed, reset to the last positive number) and triggers the creation of the
     * new variable columns
     *
     * @param event : Event, delivered from the event handler
     * @returns     : void
     */
    function processUserInputVariables(event) {
        var timeoutVariablesInput = null;
        clearTimeout(timeoutVariablesInput);
        timeoutVariablesInput = setTimeout(function () {
            // get diff from old value / new value
            var newValue = document.getElementById("numbOfVariables").value;
            var form = document.getElementById("numbOfVariables");

            if (newValue === "") {
                // nothing to do, waiting for user input
                // return;
            } else if (newValue > 1 && newValue <= 100) {

                var diffVariables = newValue - numbOfVariables;

                if (diffVariables > 0) {
                    for (var i = 0; i < diffVariables; i++) {
                        numbOfVariables++;
                        TableManipulator.addVariable();
                    }
                } else if (diffVariables < 0) {
                    for (var j = diffVariables; j < 0; j++) {
                        if (numbOfVariables < minNumbVariables) {
                            break;
                        }
                        numbOfVariables--;
                        TableManipulator.removeVariable();
                    }
                }
            } else {
                document.getElementById("numbOfVariables").value = numbOfVariables;
                toastr.info(inputSolverError);
            }

        }, 500);

    }

    /**
     *
     * validates the user input for the constrain input field. Minimum number of
     * constraints is 1. Triggers the creation of the constraint rows
     *
     * @param event
     * @returns
     */
    function processUserInputConstraints(event) {
        var timeoutConstraintInput = null;
        clearTimeout(timeoutConstraintInput);
        timeoutConstraintInput = setTimeout(
            function () {

                var newValue = document.getElementById("numbOfConstraints").value;

                if (newValue === "") {
                    // nothing to do, waiting for user input
                } else if (newValue > 1 && newValue <= 100) {
                    var diffVariables = newValue - numbOfConstraints;

                    if (diffVariables > 0) {
                        for (var i = 0; i < diffVariables; i++) {
                            numbOfConstraints++;
                            TableManipulator.addConstraint(numbOfConstraints);
                        }
                    } else if (diffVariables < 0) {
                        for (var j = diffVariables; j !== 0; j++) {
                            if (numbOfConstraints < minNumbConstraints) {
                                break;
                            }
                            numbOfConstraints--;
                            TableManipulator.removeConstraint();
                        }
                    }
                } else {
                    document.getElementById("numbOfConstraints").value = numbOfConstraints;
                    toastr.info(inputSolverError);
                }
            }, 500);
    }

    /**
     * checks the user input live against the pattern for a rational number so the
     * user can just type following number types: > integer, e.g. "1" > float, e.g.
     * "3/4" > mixed float, e.g. "3,2/4" or "3/4,2" > input with both comma and dot
     *
     * @returns
     */
    function checkUserNumberInput(event) {


        var input = event.target.value;

        // while typing, delete all letters

        // and all symbols except the slash, dot, comma and the minus

        var regex = new RegExp(
            "^([0-9]{1,}((\\.|,)[0-9]{1,}){0,1})(/[0-9]{1,}((\\.|,)[0-9]{1,}){0,1}){0,1}$",
            "g");

        // if invalid input
        if (input.length === 0) {
            return;
        }

        // triggers the native html5 form validation
        var submitButton = document.getElementById("submitButton");
        submitButton.click();
    }

    /**
     *
     * @returns
     */
    function initEventHandler() {

        // disable the scrolling on the number inputs
        document.getElementById("numbOfVariables").addEventListener("mousewheel",
            function (event) {
                event.preventDefault();
            });

        document.getElementById("numbOfConstraints").addEventListener("mousewheel",
            function (event) {
                event.preventDefault();
            });

        document
            .getElementById("incrementNumberOfVariables")
            .addEventListener(
                "click",
                function () {
                    numbOfVariables++;
                    document.getElementById("numbOfVariables").value = numbOfVariables;
                    TableManipulator.addVariable();
                });
        document
            .getElementById("decrementNumberOfVariables")
            .addEventListener(
                "click",
                function () {
                    if (numbOfVariables > 2) {
                        numbOfVariables--;
                        document.getElementById("numbOfVariables").value = numbOfVariables;
                        TableManipulator.removeVariable();
                    }
                });

        document
            .getElementById("incrementNumberOfConstraints")
            .addEventListener(
                "click",
                function () {
                    numbOfConstraints++;
                    document.getElementById("numbOfConstraints").value = numbOfConstraints;
                    TableManipulator.addConstraint(numbOfConstraints);
                    TableManipulator.addToUnitMatrix(numbOfConstraints);
                });
        document
            .getElementById("decrementNumberOfConstraints")
            .addEventListener(
                "click",
                function () {
                    if (numbOfConstraints > 1) {
                        numbOfConstraints--;
                        document.getElementById("numbOfConstraints").value = numbOfConstraints;
                        TableManipulator.removeConstraint();
                        TableManipulator.removeFromUnitMatrix;
                    }
                });

        document.getElementById("numbOfVariables").addEventListener("keyup", processUserInputVariables);

        document.getElementById("numbOfConstraints").addEventListener("keyup", processUserInputConstraints);

        // add the event listener for the reset button
        document.getElementById("reset").addEventListener("click", TableManipulator.reset);

        // add the event listener for the loadDefaultExample button
        document.getElementById("loadExample").addEventListener("click", setDefaultExampleToTable);
        document.getElementById("loadExampleTwo").addEventListener("click", setDefaultExample2ToTable);

        // add the event listener for the iterate button
        document.getElementById("iterate").addEventListener("click", Iterator.iterate);

        // add the event listener for the optimize button
        document.getElementById("optimize").addEventListener("click", Iterator.optimize);

        document.getElementById("pivotize").addEventListener("click", defineAndHighlightPivotElement);

    }

    return {
        initEventHandler: initEventHandler,
        checkUserNumberInput: checkUserNumberInput
    };

})();
