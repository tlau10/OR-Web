/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

// ###############################################################
// #
// #	REVISED SIMPLEX WEB ITERATOR (PURE JAVASCRIPT)
// #
// #	Michael Bernhardt, 24.06.2017
// #
// #
// ###############################################################


var Iterator = (function () {

  /**
   * iterate over the matrix while it is not optimum
   * @returns
   */
  function optimize() {
      var timer = performance.now();
    while(!iterate()) {
        iterate();
        if((performance.now()-timer) > 2000) {
            return;
        }
    }
  }

    /**
     * one iteration with the revised simplex algorithm
     * @returns true if there is a optimal or no solution
     * @returns false if the iteration is done and no solution found
     * */

  function iterate() {
      checkIfMatrixIsValid();
      if(!checkForEnoughVariablesConstraints()) {
          return true;
      }
      //get all Values from the both matrices into the arrays
      getValuesFromTableToMatrix();
      getValuesFromUnitTableToUnitMatrix();
      //get the b Column and the Objective Function
      getBColumn();
      getObjectiveFunction();
      //take the unitMatrix and make the inverse of it
      inverseMatrix = math.inv(unitMatrix);

      //get objective Function of inverseMatrix
      var tmpObjFun = getObjectiveFunctionOfInverseMatrix();
      //multiply the objective function of the inverse Matrix
      var tmpArray = math.multiply(math.fraction(tmpObjFun),math.fraction(matrix));
      var pivotColumnIndex = 0;
      var afterMult = 1000;
      for(var i = 0; i < tmpArray.length; i++) {
          if(afterMult > tmpArray[i]) {
              afterMult = tmpArray[i];
              pivotColumnIndex = i;
          }
      }
      if(tmpArray[pivotColumnIndex] >= 0) {
          showAlertMessage(msgOptimalSolutionFound);
          var sol = math.multiply(inverseMatrix, math.fraction(bColumn));
          TableManipulator.createSolutionMatrix();
          writeToSolutionTable(sol);
          return true;
      }
      //get the new matrix with pivotcolumn and b column
      var pivotColumn = getColumnValueFromMatrix(matrixTable, pivotColumnIndex + 1);
      var ab = [];
      for(var i = 0; i < numbOfConstraints+1; i++) {
          var tmpRow = [];
          tmpRow.push(pivotColumn[i]);
          tmpRow.push(bColumn[i]);
          ab.push(tmpRow);
      }
      //multiply this ab matrix with the inverse matrix
      ab = math.multiply(inverseMatrix, math.fraction(ab));
      //get smallest value of the multiplication
      var noOptimalSolution = true;
      var pivotRowIndex = 0;
      var min = [];
      for(var i = 0; i < ab.length; i++) {
          if(ab[i][0] > 0) {
              var tmp = math.divide(math.fraction(ab[i][1]), math.fraction(ab[i][0]));
              min.push(tmp);
              pivotRowIndex = i;
              noOptimalSolution = false;
          }
      }

      if(noOptimalSolution) {
          showAlertMessage(msgNoOptimalSolution);
          return true;
      }
      var afterDiv = 1000;
      var lowestIndex = 0;
      for(var i = 0; i < min.length; i++) {
          if(min[i] < afterDiv) {
              afterDiv = min[i];
              lowestIndex = i;
          }
      }
      var tmpA = getColumnValueFromMatrix(matrixTable,pivotColumnIndex + 1);
      var tmpB = getColumnValueFromMatrix(unitMatrixTable, lowestIndex);
      replaceColumn(matrix, tmpB, pivotColumnIndex);
      replaceColumn(unitMatrix, tmpA, lowestIndex);
      writeToTable(matrix, matrixTable);
      writeToUnitTable(unitMatrix, unitMatrixTable);
      matrixTable.rows[pivotRowIndex + 1].childNodes[pivotColumnIndex + 1].firstElementChild.style.backgroundColor = "";
      matrixTable.rows[pivotRowIndex + 1].childNodes[pivotColumnIndex + 1].firstElementChild.style.color = "";
      return false;
  }

  /**
   * get the column with index from any Matrix
   * @param anyMatrix : array , holds the matrix that contains the wanted column
   * @param index : number , is the index of the given matrix column
   * @returns an Array with the specified column
   * */
  function getColumnValueFromMatrix(anyMatrix, index) {
      var rows = anyMatrix.rows;
      var tmpArray = [];
      for(var i = 1; i < rows.length; i++) {
          var item = rows[i];
          var bCells = item.cells;
          var valueOfCell = bCells.item(index).firstElementChild.value;
          tmpArray.push(valueOfCell);
      }
    return tmpArray;
  }

  /**
   * replaces one given column at specified index in matrix
   * @param any
   * @param anyMatrix : array , holds the matrix we want to change
   * @param column : array , holds the new column
   * @param index : number , is the index where we want to change the column
   * @returns the given matrix with the new column
   * */
  function replaceColumn(anyMatrix, column, index) {
      var tmpMatrix = anyMatrix;
      for(var i = 0; i < anyMatrix.length; i++) {
          tmpMatrix[i][index] = column[i];
      }
      return tmpMatrix;
  }
  /**
   * writing the solution into its column
   * @param solution : array , holds the solution as an Array
   * @returns
   * */
    function writeToSolutionTable(solution) {
        var rows = solutionMatrixTable.rows;
        for(var i = 1; i < rows.length; i++) {
            rows[i].childNodes[0].firstElementChild.value = math.format(solution[i-1]);
        }
    }

  return {
    optimize: optimize,
    iterate: iterate,
    getColumnValueFromMatrix : getColumnValueFromMatrix
    };
})();
