/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */
// ##########################################################
// #                                                        #
// #	REVISED SIMPLEX ITERATOR                            #
// #                                                        #
// #	Based on Mirko Bay, 2017-04-26                      #
// #    By Michael Bernhardt, 2017-06-20                    #
// ##########################################################

// Array<Array> : holds the array with the fraction objects
var matrix;
// Array<Array> : holds the array with the unit matrix
var unitMatrix;
// Array<Array> : holds the array of the Inverse matrix
var inverseMatrix;
// Array<Array> : holds the array of the b-column
var bColumn;
// boolean: indicates if the pivot element is set
var pivotElementIsSet;


// HTMLTableElement: holds the reference to the html table
var matrixTable;
// HTMLTableElement: holds the reference to the html unit table
var unitMatrixTable;
// HTMLTableElement: holds the reference to the html solution table
var solutionMatrixTable;
// number: the current amount of Variables (= columns)
var numbOfVariables;
// number: the current amount of constraints (=rows)
var numbOfConstraints;


//
var savedMatrix = [];

/**
 * initializes the tables and add the event handler
 *
 * @returns
 */
function init() {
    matrixTable = document.getElementById("matrix");
    unitMatrixTable = document.getElementById("unitMatrix");
    solutionMatrixTable = document.getElementById("solutionMatrix");

    numbOfVariables = document.getElementById("numbOfVariables").value;
    numbOfConstraints = document.getElementById("numbOfConstraints").value;

    EventHandler.initEventHandler();

    // create the header element, depending on the amount of variables
    TableManipulator.createMatrixHeader();
    TableManipulator.createUnitMatrixHeader();

    // same for the objective function
    TableManipulator.createObjectiveFunction();

    // create rows for the constraints
    for (var i = 0; i < numbOfConstraints; i++) {
        TableManipulator.addConstraint(i + 1);
    }
    for (var i = 0; i < parseInt(numbOfConstraints) + 1; i++) {
        TableManipulator.addToUnitMatrix(i + 1);
    }
    toastr.options.timeOut = 3000; // How long the toast will display without user interaction
    toastr.options.extendedTimeOut = 1000; // How long the toast will display after a user hovers over it
    toastr.options.positionClass = "toast-bottom-right";
    toastr.options.newestOnTop = true;
}

/**
 *
 * is the same like in the powerlp > ajax.js > collectConstraintsData()
 * must be called before every operation to get the values from the html
 * table to the matrix array
 *
 * @returns
 */
function getValuesFromTableToMatrix() {

    var rows = matrixTable.rows;
    var tmpArray = [];

    // start with 1, so we ignore the row in the thead element
    for (var i = 1; i < rows.length; i++) {
        var item = rows[i];
        var constraintCells = item.cells;
        var tmpConstraint = [];

        // iterate over the cells of the row
        for (var j = 1; j < parseInt(constraintCells.length); j++) {
            var valueOfCell = new Fraction(convertValueFromInputToFraction(constraintCells.item(j).firstElementChild.value));
            tmpConstraint.push(valueOfCell);
        }
        tmpArray.push(tmpConstraint);
    }
    matrix = tmpArray;
}

/**
 *
 * is the same like in the powerlp > ajax.js > collectConstraintsData()
 * must be called before every operation to get the values from the html
 * table to the UnitMatrix array
 *
 * @returns
 */
function getValuesFromUnitTableToUnitMatrix() {
    var rows = unitMatrixTable.rows;
    var tmpArray = [];

    for (var i = 1; i < rows.length; i++) {
        var item = rows[i];
        var unitCells = item.cells;
        var tmpUnit = [];

        for (var j = 0; j < parseInt(unitCells.length); j++) {
            var valueOfCell = math.fraction(unitCells.item(j).firstElementChild.value);
            tmpUnit.push(valueOfCell);
        }
        tmpArray.push(tmpUnit);
    }
    unitMatrix = tmpArray;
}

/**
 * writes the current bColumn into the specified array
 * @returns
 */
function getBColumn() {
    var rows = matrixTable.rows;
    var tmpArray = [];

    // start with 1, so we ignore the row in the thead element
    for (var i = 1; i < rows.length; i++) {
        var item = rows[i];
        var tmpB = item.cells;
        // iterate over the cells of the row
        var valueOfCell = math.fraction(tmpB.item(tmpB.length - 1).firstElementChild.value);
        tmpArray.push(valueOfCell);
    }
    bColumn = tmpArray;
}

/**
 * writes the objective function into specified array
 * @returns
 */
function getObjectiveFunction() {
    var rows = matrixTable.rows;
    var tmpArray = [];

    // start with 1, so we ignore the row in the thead element
    for (var i = rows.length - 1; i < rows.length; i++) {
        var item = rows[i];
        var constraintCells = item.cells;
        var tmpConstraint = [];

        // iterate over the cells of the row
        for (var j = 1; j < (constraintCells.length - 3); j++) {
            var valueOfCell = new Fraction(constraintCells.item(j).firstElementChild.value);
            tmpConstraint.push(valueOfCell);
        }

        tmpArray.push(tmpConstraint);
    }
    objFunc = tmpArray;
}

/**
 * writes the objective function of the unit matrix into specified array
 * @returns
 */
function getObjectiveFunctionOfInverseMatrix() {
    var tmpArray = [];
    // iterate over the cells of the row
    for (var j = 0; j < (inverseMatrix.length); j++) {
        var valueOfCell = math.fraction(inverseMatrix[inverseMatrix.length - 1][j]);
        tmpArray.push(valueOfCell);
    }
    // tmpArray.push(tmpConstraint);
    return tmpArray;
}

function convertValueFromInputToFraction(value) {
    var res = value.replace(",", ".");
    return new Fraction(res);
}

/**
 * writes a matrix into a table
 * @param anyMatrix : array , holds the matrix to write it into a html-table
 * @param anyTable : HTML-Table , where the matrix will be written into
 * @returns
 */
function writeToTable(anyMatrix, anyTable) {
    var rows = anyTable.rows;
    for (var i = 1; i < rows.length; i++) {
        for (var j = 1; j < rows[i].childNodes.length; j++) {
            rows[i].childNodes[j].firstElementChild.value = math.fraction(anyMatrix[i - 1][j - 1]);
        }
    }

    var rows = matrixTable.rows;
}

/**
 * writes a matrix into the unitTable
 * @param anyMatrix : array , holds the matrix to write it into a html-table
 * @param anyTable : HTML-Table , where the matrix will be written into
 * @returns
 */
function writeToUnitTable(anyMatrix, anyTable) {
    var rows = anyTable.rows;
    for (var i = 1; i < rows.length; i++) {
        for (var j = 1; j < rows[i].childNodes.length + 1; j++) {
            rows[i].childNodes[j - 1].firstElementChild.value = math.fraction(anyMatrix[i - 1][j - 1]);
        }
    }
}

/**
 *
 * after every iteration (or whole optimization) we must set the values of the
 * js matrix array to the html table
 *
 */
function copyMatrixToTable() {

    // the matrixTable got 1 row and 1 column additionally because of the
    // headers
    var rows = matrixTable.rows;

    for (var i = 1; i < rows.length; i++) {
        for (var j = 1; j < rows[i].childNodes.length; j++) {
            rows[i].childNodes[j].firstElementChild.value = (matrix[i - 1][j - 1].toFraction(false));
        }
    }
}

/**
 * Shows a message to the user
 * with the param text as message
 *
 * @param text
 */
function showAlertMessage(text) {
    // https://github.com/CodeSeven/toastr
    toastr.info(text);
}

/**
 *
 * set the default example of the grütz or lecture
 * to the html table and set the values also to the matrix array
 *
 * @returns : void
 */
function setDefaultExampleToTable() {

    TableManipulator.reset();
    TableManipulator.removeVariable();
    TableManipulator.removeVariable();
    numbOfVariables = 2;
    numbOfConstraints = 2;

    var rows = matrixTable.rows;

    rows[1].childNodes[1].firstElementChild.value = 3;
    rows[1].childNodes[2].firstElementChild.value = 2;
    rows[1].childNodes[3].firstElementChild.value = 12;

    rows[2].childNodes[1].firstElementChild.value = 1;
    rows[2].childNodes[2].firstElementChild.value = 3;
    rows[2].childNodes[3].firstElementChild.value = 9;

    rows[3].childNodes[1].firstElementChild.value = -1;
    rows[3].childNodes[2].firstElementChild.value = -2;
    rows[3].childNodes[3].firstElementChild.value = 0;

    getValuesFromTableToMatrix();
}

/**
 *
 * set the default example of the ingenieurskurs
 * https://www.ingenieurkurse.de/unternehmensforschung/lineare-programmierung/revidierter-simplex-algorithmus.html
 * to the html table and set the values also to the matrix array
 *
 * @returns : void
 */
function setDefaultExample2ToTable() {

    TableManipulator.reset();
    TableManipulator.removeVariable();
    numbOfVariables = 3;
    numbOfConstraints = 2;

    var rows = matrixTable.rows;

    rows[1].childNodes[1].firstElementChild.value = 2;
    rows[1].childNodes[2].firstElementChild.value = 2;
    rows[1].childNodes[3].firstElementChild.value = 1;
    rows[1].childNodes[4].firstElementChild.value = 3;

    rows[2].childNodes[1].firstElementChild.value = 1;
    rows[2].childNodes[2].firstElementChild.value = 2;
    rows[2].childNodes[3].firstElementChild.value = 4;
    rows[2].childNodes[4].firstElementChild.value = 5;

    rows[3].childNodes[1].firstElementChild.value = -3;
    rows[3].childNodes[2].firstElementChild.value = -5;
    rows[3].childNodes[3].firstElementChild.value = -4;
    rows[3].childNodes[4].firstElementChild.value = 0;

    getValuesFromTableToMatrix();
}
/**
 * checks the validity of the matrix (with the native html5 form validation
 *
 * @return {boolean}
 */
function checkIfMatrixIsValid() {

    var form = document.getElementById("matrixForm");
    if (!form.checkValidity()) {
        showAlertMessage(msgMatrixNotValid);
        // triggers the native html5 form validation
        var submitButton = document.getElementById("submitButton");
        submitButton.click();
        return false;
    } else {
        // the form is valid
        return true;
    }
}

function checkForEnoughVariablesConstraints() {
    if (parseInt(numbOfConstraints) > numbOfVariables) {
        showAlertMessage(msgConstraintsBiggerVariables);
        var submitButton = document.getElementById("submitButton");
        submitButton.click();
        return false;
    }
    return true;
}

function defineAndHighlightPivotElement() {

    checkIfMatrixIsValid();
    if(!checkForEnoughVariablesConstraints()) {
        return true;
    }
    //get all Values from the both matrices into the arrays
    getValuesFromTableToMatrix();
    getValuesFromUnitTableToUnitMatrix();
    //get the b Column and the Objective Function
    getBColumn();
    getObjectiveFunction();
    //take the unitMatrix and make the inverse of it
    inverseMatrix = math.inv(unitMatrix);

    //get objective Function of inverseMatrix
    var tmpObjFun = getObjectiveFunctionOfInverseMatrix();
    //multiply the objective function of the inverse Matrix
    var tmpArray = math.multiply(math.fraction(tmpObjFun),math.fraction(matrix));
    var pivotColumnIndex = 0;
    var afterMult = 1000;
    for(var i = 0; i < tmpArray.length; i++) {
        if(afterMult > tmpArray[i]) {
            afterMult = tmpArray[i];
            pivotColumnIndex = i;
        }
    }
    if(tmpArray[pivotColumnIndex] >= 0) {
        showAlertMessage(msgNoPivotColumn);
        return true;
    }
    //get the new matrix with pivotcolumn and b column
    var pivotColumn = Iterator.getColumnValueFromMatrix(matrixTable, pivotColumnIndex + 1);
    var ab = [];
    for(var i = 0; i < numbOfConstraints+1; i++) {
        var tmpRow = [];
        tmpRow.push(pivotColumn[i]);
        tmpRow.push(bColumn[i]);
        ab.push(tmpRow);
    }
    //multiply this ab matrix with the inverse matrix
    ab = math.multiply(inverseMatrix, math.fraction(ab));
    //get smallest value of the multiplication
    var noOptimalSolution = true;
    var pivotRowIndex = 0;
    var min = [];
    for(var i = 0; i < ab.length; i++) {
        if(ab[i][0] > 0) {
            var tmp = math.divide(math.fraction(ab[i][1]), math.fraction(ab[i][0]));
            min.push(tmp);
            pivotRowIndex = i;
            noOptimalSolution = false;
        }
    }

    if(noOptimalSolution) {
        showAlertMessage(msgNoPivotRow);
        return true;
    }
    var afterDiv = 1000;
    var lowestIndex = 0;
    for(var i = 0; i < min.length; i++) {
        if(min[i] < afterDiv) {
            afterDiv = min[i];
            lowestIndex = i;
        }
    }
    matrixTable.rows[pivotRowIndex + 1].childNodes[pivotColumnIndex + 1].firstElementChild.style.opacity = 0;

    setTimeout(function () {
        matrixTable.rows[pivotRowIndex + 1].childNodes[pivotColumnIndex + 1].firstElementChild.style.opacity = 1;
        matrixTable.rows[pivotRowIndex + 1].childNodes[pivotColumnIndex + 1].firstElementChild.style.backgroundColor = "#334152";
        matrixTable.rows[pivotRowIndex + 1].childNodes[pivotColumnIndex + 1].firstElementChild.style.color = "#ffffff";
    }, 400);
}



