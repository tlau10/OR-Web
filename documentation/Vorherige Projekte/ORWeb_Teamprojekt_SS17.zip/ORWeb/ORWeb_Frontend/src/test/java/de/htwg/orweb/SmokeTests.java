package de.htwg.orweb;

import static org.assertj.core.api.Assertions.assertThat;

import de.htwg.orweb.controller.HomeController;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import de.htwg.orweb.controller.LoginController;

/**
 * example of a smoke test for the whole platform
 * mb, 2017-05-10
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class SmokeTests {

    @Autowired
    private HomeController homeController;
    
    @Autowired
    private LoginController loginController;

    @Test
    public void contextLoads() throws Exception {
        assertThat(homeController).isNotNull();
    }

    @Test
    public void contextLoadsLogin() throws Exception {
        assertThat(loginController).isNotNull();
    }
}
