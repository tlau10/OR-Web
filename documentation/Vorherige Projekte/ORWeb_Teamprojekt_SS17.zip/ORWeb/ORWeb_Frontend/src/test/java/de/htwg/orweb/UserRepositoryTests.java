package de.htwg.orweb;

import static org.assertj.core.api.Assertions.*;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import de.htwg.orweb.model.User;
import de.htwg.orweb.repository.UserRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
public class UserRepositoryTests {

    @Autowired
    private TestEntityManager entityManager;

    @Qualifier("userRepository")
    @Autowired
    private UserRepository repository;
    
    @Test
    public void testExample() throws Exception {
        // for simplicity we do not encode the password
	this.entityManager.persist(new User("stephen", "beck", "stephen@beck.de", "hallihallo"));
        User user = this.repository.findByEmail("stephen@beck.de");
        
        assertThat(user.getFirstName()).isEqualTo("stephen");
        assertThat(user.getLastName()).isEqualTo("beck");
        assertThat(user.getEmail()).isEqualTo("stephen@beck.de");
        assertThat(user.getPassword()).isEqualTo("hallihallo");
    }
    
}