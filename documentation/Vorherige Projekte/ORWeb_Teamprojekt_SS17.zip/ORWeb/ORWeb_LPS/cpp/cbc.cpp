// WebOR_CBC.cpp : Definiert die exportierten Funktionen f�r die DLL-Anwendung.
//

#include "stdafx.h"
#include "de_htwg_orweb_lps_solver_CBCSolverImpl.h"
#include "coin/CbcModel.hpp"
#include "coin/CoinPragma.hpp"
#include "coin/OsiClpSolverInterface.hpp"
#include "coin/OsiCbcSolverInterface.hpp"
#include "coin/CbcBranchDynamic.hpp"

#define FAILED 1
#define OK 0

class Solver
{
public:
	Solver() {
		this->m_solution = NULL;
	}
	int solve(std::string mps, double sense) {
		OsiClpSolverInterface initial_solver;
		int num_errors = initial_solver.readMps(mps.c_str());
		if (num_errors != 0) {
			return FAILED;
		}
		initial_solver.setObjSense(sense);
		CbcModel linear_model(initial_solver);

		const char * solver_args[] = { "run","-solve","-quit" };
		CbcMain(2, solver_args, linear_model);

		int num_columns = linear_model.solver()->getNumCols();
		int num_rows = linear_model.solver()->getNumRows();
		const double* solution = linear_model.bestSolution();
		const double* column_solution = linear_model.solver()->getColSolution();
		const double* red_costs = linear_model.solver()->getReducedCost();
		const double obj = linear_model.solver()->getObjValue();
		this->m_solution = new std::vector<std::string>((num_columns)+2);
		char obj_value[200];
		sprintf(obj_value, "obj;%f;-", obj);
		char feasible_value[10];
		sprintf(feasible_value, "feas;%d;-", linear_model.isProvenInfeasible());
		(*this->m_solution)[0] = std::string(obj_value);
		(*this->m_solution)[1] = std::string(feasible_value);
		for (int i = 0; i < num_columns; i++) {
			char values[200];
			sprintf(values, "%s_var;%f;%f", initial_solver.getColName(i).c_str(), column_solution[i], red_costs[i]);
			(*this->m_solution)[i+2] = (std::string(values));
		}
		if (m_solution->size() == 0) {
			return FAILED;
		}
		return OK;
	}

	std::vector<std::string >* solution() {
		return this->m_solution;
	}

	~Solver() {
		if (m_solution){
			delete m_solution;
		}
	}
private:
	std::vector<std::string >* m_solution;
};

JNIEXPORT jobjectArray JNICALL Java_de_htwg_orweb_lps_solver_CBCSolverImpl_call(JNIEnv * env, jobject obj, jstring src, jdouble sense) {
	const char *native_input = env->GetStringUTFChars(src, JNI_FALSE);
	OsiClpSolverInterface initial_solver;
	Solver solver;
	int ret = solver.solve(std::string(native_input), sense);
	if (ret==OK){
		std::vector<std::string>* native_result = solver.solution();
		jobjectArray java_result = (jobjectArray)env->NewObjectArray(native_result->size(), env->FindClass("java/lang/String"), env->NewStringUTF(""));
		int i = 0;
		for (std::vector<std::string>::iterator it = native_result->begin(); it != native_result->end(); ++it) {
			std::string current = *it;
			env->SetObjectArrayElement(java_result, i, env->NewStringUTF(current.c_str()));
			i++;
		}
		env->ReleaseStringUTFChars(src, native_input);
		return java_result;
	}
	std::cout << "Errors occured while processing problem instance. Check provided file." << std::endl;
	env->ReleaseStringUTFChars(src, native_input);
	return NULL;
}



