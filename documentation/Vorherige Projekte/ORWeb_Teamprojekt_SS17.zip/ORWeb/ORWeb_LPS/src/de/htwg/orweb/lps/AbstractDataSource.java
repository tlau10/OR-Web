/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps;

public abstract class AbstractDataSource implements Runnable{
	
	/**
	 * 
	 */
	protected ITaskProcessor processor;
	/**
	 * 
	 */
	protected Thread retrivalThread;
	/**
	 * 
	 */
	public AbstractDataSource(ITaskProcessor processor) {
		this.processor = processor;
	}

	/**
	 * 
	 */
	public void startRetrival() {
		if (retrivalThread == null) {
			this.retrivalThread = new Thread(this);
			this.retrivalThread.start();
		}
	}

	/**
	 * 
	 */
	public void stopRetrival() {
		if (retrivalThread.isAlive()) {
			try {
				retrivalThread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
