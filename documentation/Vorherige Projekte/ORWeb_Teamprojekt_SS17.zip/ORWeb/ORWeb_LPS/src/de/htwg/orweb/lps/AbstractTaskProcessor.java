/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.xml.bind.JAXBException;


import de.htwg.orweb.common.result.Result;
import de.htwg.orweb.common.shared.Model;
import de.htwg.orweb.common.task.Task;
import de.htwg.orweb.common.xml.JAXBUtil;
import de.htwg.orweb.lps.common.Configurator;
import de.htwg.orweb.lps.file.MpsFormatGenerator;
import de.htwg.orweb.lps.solver.ISolver;
import de.htwg.orweb.lps.solver.SolverWrapper;

public abstract class AbstractTaskProcessor extends ITaskProcessor{
	
	
	/**
	 * @author schobast
	 *
	 */
	protected class TaskProcessor extends Thread{
		private Task task;
		/**
		 * 
		 */
		public TaskProcessor(Task task) {
			this.task = task;
		}
		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		@Override
		public void run() {
			File temp = new File(conf.getTempDir());
			if (!temp.exists()) {
				temp.mkdir();
			}
			MpsFormatGenerator writer = new MpsFormatGenerator(task);
			String content = writer.getContent();
			String targetFile = conf.getTargetModelFile();
			try {
				writer.write(targetFile);
			} catch (IOException e) {
				e.printStackTrace();
			}
			ISolver solver = new SolverWrapper(conf, task);
			Result res = solver.solve(targetFile, task.getObjective().getType());
			res.setModel(new Model(content));
			System.out.println(this.getClass() + "> DEBUG:: Result print:\n");
			try {
				JAXBUtil.toConsole(res);
			} catch (JAXBException e) {
				e.printStackTrace();
			}
			try {
				JAXBUtil.toFile(res, conf.getOsSeparator(), conf.getDebugOutDir(), "%s_result.xml");
			} catch (FileNotFoundException | JAXBException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * 
	 */
	protected Configurator conf;

	/**
	 * @param conf
	 */
	public AbstractTaskProcessor(Configurator conf) {
		this.conf = conf;
	}
}
