/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */
package de.htwg.orweb.lps;

import de.htwg.orweb.lps.common.Configurator;
import de.htwg.orweb.lps.debug.DebugProcessor;
import de.htwg.orweb.lps.debug.FileSystemDataSource;
import de.htwg.orweb.lps.prod.LPSProduction;

public class LPSApplication {

	private static class ExecutionSettings {
		private boolean isDebugEnabled;
		private String cfgPath;

		/**
		 * 
		 */
		public ExecutionSettings() {
			isDebugEnabled = false;
		}

		public boolean isDebugEnabled() {
			return isDebugEnabled;
		}

		public void setDebugEnabled(boolean isDebugEnabled) {
			this.isDebugEnabled = isDebugEnabled;
		}

		public String getCfgPath() {
			return cfgPath;
		}

		public void setCfgPath(String cfgPath) {
			this.cfgPath = cfgPath;
		}

		public boolean isSet() {
			if (isDebugEnabled) {
				return true;
			}
			return (getCfgPath() != null);
		}

	}

	private static final String DEBUG_ARG = "-d";
	private static final String HELP_ARG = "-h";
	private static final String CFG_ARG = "-cfg";

	private static ExecutionSettings getSettings(String[] args) {
		ExecutionSettings settings = new ExecutionSettings();
		for (int i = 0; i < args.length; i++) {
			if (args[i].equals(HELP_ARG)) {
				return null;
			} else if (args[i].equals(CFG_ARG)) {
				if (i + 1 <= args.length - 1 && args[i + 1] != null) {
					settings.setCfgPath(args[i + 1]);
				}
			} else if (args[i].equals(DEBUG_ARG)) {
				settings.setDebugEnabled(true);
			}
		}
		return settings;
	}

	public static void main(String[] args) {
		ExecutionSettings settings = getSettings(args);
		if (settings == null) {
			System.out.println("ORWeb_LPS v1.0\n");
			System.out.println("USEAGE:   -cfg <CFG_PATH> (-d)\n");
			System.out.println("-cfg <CFG_PATH>      :      path to configuration");
			System.out.println("-d                   :      start in debug mode");
			System.exit(0);
		} else if (!settings.isSet()) {
			System.out.println("Invalid parameters provided. Use \"-h\" to get some info.");
			System.exit(-1);
		}
		AbstractDataSource dataSource = null;
		Configurator conf = new Configurator(settings.getCfgPath());
		if (settings.isDebugEnabled()) {
			dataSource = new FileSystemDataSource(conf.getDebugInDir(),new LPSProduction(conf));
		} else {
			//TODO: Implement proper production feature
			dataSource = new FileSystemDataSource(conf.getDebugInDir(),new DebugProcessor(conf));
		}
		dataSource.startRetrival();
	}
}
