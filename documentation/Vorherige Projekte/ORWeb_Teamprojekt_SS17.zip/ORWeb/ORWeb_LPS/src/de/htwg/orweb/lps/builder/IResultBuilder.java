/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps.builder;

import de.htwg.orweb.common.result.Result;

public interface IResultBuilder {
	
	public abstract Result build(long processigTime);

}
