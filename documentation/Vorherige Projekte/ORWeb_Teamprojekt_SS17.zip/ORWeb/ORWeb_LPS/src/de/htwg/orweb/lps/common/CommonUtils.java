/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class CommonUtils {

	/**
	 * @param resPath
	 * @return
	 */
	public static InputStream loadResourceAsStream(String resPath) {
		ClassLoader classLoader = CommonUtils.class.getClassLoader();
		return classLoader.getResourceAsStream(resPath);
	}

	public static InputStream loadResourcesAsStream(File resFile)
			throws FileNotFoundException {
		return new FileInputStream(resFile);
	}

	public static boolean isFilePresent(String path) {
		if (new File(path).exists()) {
			return true;
		}
		return false;
	}

	public static void exportResource(String resName, String os, String trg, String separator)
			throws Exception {
		String res = os + "/" + resName;
		InputStream stream = null;
		OutputStream resStreamOut = null;
		try {
			stream = loadResourceAsStream(res);
			if (stream == null) {
				throw new Exception("Cannot get resource \"" + res
						+ "\" from Jar file.");
			}
			int readBytes;
			byte[] buffer = new byte[4096];
			resStreamOut = new FileOutputStream(new File(trg + separator + resName));
			while ((readBytes = stream.read(buffer)) > 0) {
				resStreamOut.write(buffer, 0, readBytes);
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			if (stream != null) {
				stream.close();
			}
			if (resStreamOut != null) {
				resStreamOut.close();
			}
		}
	}

}
