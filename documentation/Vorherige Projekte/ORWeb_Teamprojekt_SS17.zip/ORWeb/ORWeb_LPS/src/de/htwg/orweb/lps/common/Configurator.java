/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps.common;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.TimeZone;

public class Configurator {

	private String osSeparator;
	/**
	 * 
	 */
	private static final String RES_LINUX_MIPCL_EXEC = "mipcl";
	/**
	 * 
	 */
	private static final String RES_WIN_MIPCL_EXEC = "mipcl.exe";
	/**
	 * 
	 */
	private static final String RES_LINUX_GLPK_EXEC = "glpk";
	/**
	 * 
	 */
	private static final String RES_WIN_GLPK_EXEC = "glpk.exe";
	
	/**
	 * 
	 */
	private static final String RES_LINUX_SCIP_EXEC = "scip";
	/**
	 * 
	 */
	private static final String RES_WIN_SCIP_EXEC = "scip.exe";
	/**
	 * 
	 */
	private static final String RES_LINUX_LPSOLVE_EXEC = "lp_solve";
	/**
	 * 
	 */
	private static final String RES_WIN_LPSOLVE_EXEC = "lp_solve.exe";
	/**
	 * 
	 */
	private static final String RES_LINUX_CBC_EXEC = "cbc";
	/**
	 * 
	 */
	private static final String RES_LINUX_CBC_LIB = "libCbc.so";
	/**
	 * 
	 */
	private static final String RES_WIN_CBC_EXEC = "cbc.exe";
	/**
	 * 
	 */
	private static final String RES_WIN_CBC_LIB = "cbc.dll";
	/**
	 * 
	 */
	private static final String WIN_CFG_FILE_NAME = "orweb_lps_win.properties";
	/**
	 * 
	 */
	private static final String LINUX_CFG_FILE_NAME = "orweb_lps_linux.properties";

	/**
	 * 
	 */
	private static final String DEBUG_IN_DIR = "orweb.lps.debug.input_dir";
	/**
	 * 
	 */
	private static final String DEBUG_OUT_DIR = "orweb.lps.debug.output_dir";
	/**
	 * 
	 */
	private static final String SOLUTION_FILE_NAME = "orweb.lps.solver.solution_file_name";
	/**
	 * 
	 */
	private static final String SOLVER_DYNAMIC_ENABLED = "orweb.lps.solver.dynamic_enabled";
	/**
	 * 
	 */
	private static final String WD_DYNAMIC_ENABLED = "orweb.lps.dynamic_wd_enabled";
	/**
	 * 
	 */
	private static final String WD_STATIC_DIR = "orweb.lps.static_wd_dir";
	/**
	 * 
	 */
	private static final String SOLVER_MODEL_FILE = "orweb.lps.solver.model_file";
	/**
	 * 
	 */
	private static final String SOLVER_RESULT_FILE = "orweb.lps.solver.result_file";

	/**
	 * 
	 */
	private static final String SOLVER_TEMP_DIR = "orweb.lps.temp_dir";
	/**
	 * 
	 */
	private static final String SOLVER_LIB_DIR = "orweb.lps.lib_dir";

	/**
	 * 
	 */
	private static final String VALID_KEY = "orweb.lps.validity_key";
	
	private static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss z";

	private static final int KEY_BASE = 36;

	private SupportedArch architecture;
	/**
	 * Execution directory
	 */
	private String execDir;
	/**
	 * 
	 */
	private String solverDir;
	/**
	 * 
	 */
	private Properties properties;

	private SupportedEnv targetEnv;

	public Configurator(String cfgPath) {
		String osDependentCfg;
		String os = System.getProperty("os.name");
		System.out.println(this.getClass() + "> DEBUG:: Detected operating system: " + os);
		if (os.startsWith("Windows")) {
			targetEnv = SupportedEnv.WIN_ENV;
			osSeparator = "\\";
			osDependentCfg = WIN_CFG_FILE_NAME;
			System.out.println(this.getClass() + "> DEBUG:: Windows environment set");
		} else {
			targetEnv = SupportedEnv.LINUX_ENV;
			osSeparator = "/";
			osDependentCfg = LINUX_CFG_FILE_NAME;
			System.out.println(this.getClass() + "> DEBUG:: Linux environment set");
		}
		String arch = System.getProperty("sun.arch.data.model");
		if (arch.equals("32")) {
			architecture = SupportedArch.X86_ARCH;
		} else {
			architecture = SupportedArch.X64_ARCH;
		}
		System.out.println(this.getClass() + "> DEBUG:: Detected JVM architecture: " + architecture);
		properties = new Properties();
		if (cfgPath == null) {
			System.out.println(this.getClass() + "> DEBUG:: Loading internal configuration from " + osDependentCfg);
			try {
				properties.load(CommonUtils.loadResourceAsStream(osDependentCfg));
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			System.out.println(this.getClass() + "> DEBUG:: Loading external configuration from " + cfgPath);
			try {
				properties.load(CommonUtils.loadResourcesAsStream(new File(cfgPath)));
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (!isDynamicWdEnabled()) {
			System.out.println(this.getClass() + "> DEBUG:: Using static working directory " + getStaticWdDir());
			File wd = new File(getStaticWdDir());
			if (!wd.exists()) {
				wd.mkdir();
			}
			execDir = getStaticWdDir();
		} else {
			execDir = System.getProperty("user.dir");
		}
		try {
			System.out.println(this.getClass() + "> DEBUG:: " + getLicenseInformation());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private String getLicenseInformation() throws Exception {
		if (!isValid()) {
			return new String("License expired! Please contact the service provider to receive a new one.");
		}
		String s = Validator.decrypt(properties.getProperty(VALID_KEY), KEY_BASE);
		long exp = Long.parseLong(s);
		Date date = new Date(exp * 1000L);
		// format of the date
		SimpleDateFormat jdf = new SimpleDateFormat(DATE_FORMAT);
		jdf.setTimeZone(TimeZone.getTimeZone("GMT-4"));
		String readable = jdf.format(date);
		return new String("License is valid until: " + readable);
		
	}

	public String getOsSeparator() {
		return osSeparator;
	}

	public boolean isDynamicWdEnabled() {
		return Boolean.parseBoolean(properties.getProperty(WD_DYNAMIC_ENABLED));
	}

	public String getTempDir() {
		return execDir + osSeparator + properties.getProperty(SOLVER_TEMP_DIR);
	}

	public boolean isValid() throws NumberFormatException, Exception {
		return Validator.isValidKey(properties.getProperty(VALID_KEY), KEY_BASE);
	}

	/**
	 * @return
	 */
	public String getStaticWdDir() {
		return properties.getProperty(WD_STATIC_DIR);
	}

	public String getTargetModelFile() {
		String format = "%s" + osSeparator + "%d_%s";
		return String.format(format, getTempDir(), (long) System.currentTimeMillis(), getModelFile());
	}

	public String getModelFile() {
		return properties.getProperty(SOLVER_MODEL_FILE);
	}

	public String getResultFile() {
		return properties.getProperty(SOLVER_RESULT_FILE);
	}

	/**
	 * @return
	 */
	public String getExecutionDirectory() {
		return execDir;
	}

	/**
	 * @return
	 */
	public String getSolverDirectory() {
		return solverDir;
	}

	/**
	 * @return the execDir
	 */
	public String getExecDir() {
		return execDir;
	}

	/**
	 * @return the solverDir
	 */
	public String getSolverDir() {
		return solverDir;
	}

	public SupportedEnv getTargetEnv() {
		return this.targetEnv;
	}

	public String getNativeExtension() {
		return this.targetEnv.getNativeExtension();
	}

	public String getDebugInDir() {
		return execDir + osSeparator + this.properties.getProperty(DEBUG_IN_DIR);
	}

	public String getDebugOutDir() {
		return execDir + osSeparator + this.properties.getProperty(DEBUG_OUT_DIR);
	}

	public String getSolutionFileName() {
		return this.properties.getProperty(SOLUTION_FILE_NAME);
	}

	public String getLibDir() {
		return execDir + osSeparator + properties.getProperty(SOLVER_LIB_DIR);
	}

	public String getTargetSolutionFile() {
		String format = "%s" + osSeparator + "%d_%s";
		return String.format(format, getTempDir(), (long) System.currentTimeMillis(), getSolutionFileName());
	}

	public boolean isDynamicSolverEnabled() {
		return Boolean.parseBoolean(this.properties.getProperty(SOLVER_DYNAMIC_ENABLED));
	}

	public String getLinuxExecResource() {
		return RES_LINUX_CBC_EXEC;
	}

	public String getLinuxCbcExecResource() {
		return RES_LINUX_CBC_EXEC;
	}

	public String getLinuxCbcLibResource() {
		return RES_LINUX_CBC_LIB;
	}
	public String getLinuxLpSolveExecResource() {
		return RES_LINUX_LPSOLVE_EXEC;
	}
	
	public String getWinLpSolveExecResource() {
		return RES_WIN_LPSOLVE_EXEC;
	}
	
	public String getLinuxSCIPExecResource() {
		return RES_LINUX_SCIP_EXEC;
	}
	
	public String getWinSCIPExecResource() {
		return RES_WIN_SCIP_EXEC;
	}
	
	public String getLinuxMipclExecResource() {
		return RES_LINUX_MIPCL_EXEC;
	}
	
	public String getWinMipclExecResource() {
		return RES_WIN_MIPCL_EXEC;
	}
	
	public String getLinuxGlpkExecResource() {
		return RES_LINUX_GLPK_EXEC;
	}
	
	public String getWinGlpkExecResource() {
		return RES_WIN_GLPK_EXEC;
	}

	public String getWinCbcExecResource() {
		return RES_WIN_CBC_EXEC;
	}

	public String getWinCbcLibResource() {
		return RES_WIN_CBC_LIB;
	}

	public SupportedArch getArchitecture() {
		return architecture;
	}
}
