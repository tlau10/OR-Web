/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps.common;

public enum SupportedArch {
	
	X86_ARCH("32"), X64_ARCH("64");
	
	private String arch;
	
	/**
	 * 
	 */
	private SupportedArch(String arch) {
		this.arch = arch;
	}

	public String getArch() {
		return arch;
	}

}
