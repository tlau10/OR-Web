/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */
package de.htwg.orweb.lps.common;

import java.util.ArrayList;
import java.util.List;

import de.htwg.orweb.common.shared.Model;
import de.htwg.orweb.common.task.Bound;
import de.htwg.orweb.common.task.Constraint;
import de.htwg.orweb.common.task.Meta;
import de.htwg.orweb.common.task.Objective;
import de.htwg.orweb.common.task.Task;
import de.htwg.orweb.common.task.Variable;

public class TaskFactory {
	
	private static final String CBC_SOLVER = "cbc";
	
	public enum ObjectiveSense{
		MIN,MAX;
	}
	
	/**
	 * 
	 */
	private TaskFactory() {
	
	}
	
	public static Bound createIntegerBound(int index){
		Bound bound = new Bound();
		bound.setVariableName("x" + index);
		bound.setInteger(true);
		return bound;
	}
	
	public static Constraint createLEConstraint(double[] variables, double rhs){
		Constraint constraint = new Constraint();
		constraint.setType("L");
		List<Variable> vars = new ArrayList<>();
		for (int i = 0; i < variables.length; i++) {
			Variable var = new Variable();
			var.setCoefficient(variables[i]);
			var.setName("x" + i);
			vars.add(var);
		}
		constraint.setVariables(vars);
		constraint.setRhs(rhs);
		return constraint;
	}
	
	public static Constraint createGEConstraint(double[] variables, double rhs){
		Constraint constraint = new Constraint();
		constraint.setType("G");
		List<Variable> vars = new ArrayList<>();
		for (int i = 0; i < variables.length; i++) {
			Variable var = new Variable();
			var.setCoefficient(variables[i]);
			var.setName("x" + i);
			vars.add(var);
		}
		constraint.setVariables(vars);
		constraint.setRhs(rhs);
		return constraint;
	}
	
	
	public static Constraint createEConstraint(double[] variables, double rhs){
		Constraint constraint = new Constraint();
		constraint.setType("E");
		List<Variable> vars = new ArrayList<>();
		for (int i = 0; i < variables.length; i++) {
			Variable var = new Variable();
			var.setCoefficient(variables[i]);
			var.setName("x" + i);
			vars.add(var);
		}
		constraint.setVariables(vars);
		constraint.setRhs(rhs);
		return constraint;
	}
	
	public static Task createBasicCbcTask(){
		Task task = new Task();
		Meta meta = new Meta();
		meta.setForcePositive(true);
		meta.setConvert(false);
		meta.setSolveFromModel(false);
		meta.setSolver(CBC_SOLVER);
		task.setMeta(meta);
		return task;
	}
	
	public static Objective generateObjectiveFunction(double[] variables, ObjectiveSense sense){
		List<Variable> vars = new ArrayList<>();
		for (int i = 0; i < variables.length; i++) {
			Variable var = new Variable();
			var.setCoefficient(variables[i]);
			var.setName("x" + i);
			vars.add(var);
		}
		Objective obj = new Objective();
		obj.setType(sense.toString().toLowerCase());
		obj.setVariables(vars);
		return obj;
	}
	
	public static Objective createMaxObjectiveFunction(double[] variables){
		return generateObjectiveFunction(variables, ObjectiveSense.MAX);
	}
	
	public static Objective createMinObjectiveFunction(double[] variables){
		return generateObjectiveFunction(variables, ObjectiveSense.MIN);
	}
	
	public static Task createBasicCbcTask(Objective obj){
		Task task = new Task();
		Meta meta = new Meta();
		meta.setForcePositive(true);
		meta.setConvert(false);
		meta.setSolveFromModel(false);
		meta.setSolver(CBC_SOLVER);
		task.setMeta(meta);
		task.setObjective(obj);
		return task;
	}
	
	public static Task createConvertTask(String model){
		Task task = new Task();
		Meta meta = new Meta();
		meta.setConvert(true);
		meta.setSolveFromModel(false);
		meta.setSolver(CBC_SOLVER);
		task.setMeta(meta);
		Objective obj = new Objective();
		obj.setType(ObjectiveSense.MIN.toString().toLowerCase());
		task.setObjective(obj);
		Model m = new Model();
		m.setMpsModel(model);
		task.setModel(m);
		return task;
	}
	
	public static Task createSolveFromModelTask(String model, ObjectiveSense objSense){
		
		Task task = new Task();
		Meta meta = new Meta();
		meta.setConvert(false);
		meta.setSolveFromModel(true);
		meta.setSolver(CBC_SOLVER);
		task.setMeta(meta);
		Objective obj = new Objective();
		obj.setType(objSense.toString().toLowerCase());
		task.setObjective(obj);
		Model m = new Model();
		m.setMpsModel(model);
		task.setModel(m);
		return task;
	}
	
	public static Task createTransform(String model, ObjectiveSense objSense){
		Task task = new Task();
		Meta meta = new Meta();
		meta.setConvert(false);
		meta.setSolveFromModel(false);
		meta.setTransform(true);
		meta.setSolver(CBC_SOLVER);
		task.setMeta(meta);
		Objective obj = new Objective();
		obj.setType(objSense.toString().toLowerCase());
		task.setObjective(obj);
		Model m = new Model();
		m.setMpsModel(model);
		task.setModel(m);
		return task;
	}

}
