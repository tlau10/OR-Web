/*************************************************************************
 * 
 * CONFIDENTIAL
 * __________________
 * 
 *  [2016] Bastian Schoettle & Tim Schoettle
 *  All Rights Reserved.
 * 
 * NOTICE:  All information contained herein is, and remains
 * the property of Bastian Schoettle & Tim Schoettle and his suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Bastian Schoettle & Tim Schoettle
 * and its suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Bastian Schoettle & Tim Schoettle.
 *
 */
package de.htwg.orweb.lps.file;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import de.htwg.orweb.common.task.Constraint;
import de.htwg.orweb.common.task.Task;
import de.htwg.orweb.common.task.Variable;
import de.htwg.orweb.lps.common.TaskFactory.ObjectiveSense;

/**
 * @author schobast
 *
 */
public class CplexFormatGenerator implements IFormatGenerator{
	
	private StringBuffer model;
	private Task task;
	/**
	 * 
	 */
	public CplexFormatGenerator(Task task) {
		this.task = task;
	}
	
	private void build(){
		model = new StringBuffer();
		if (task.getObjective().getType().equalsIgnoreCase(ObjectiveSense.MAX.toString())) {
			model.append("Maximize\n");
		} else {
			model.append("Minimize\n");
		}
		model.append(" obj: ");
		List<Variable> obj = task.getObjective().getVariables();
		int cnt = 0;
		for (Variable variable : obj) {
			if (cnt == 0) {
				model.append( variable.getCoefficient() + " " + variable.getName());
				++cnt;
			} else {
				model.append(" + " + variable.getCoefficient() + " " + variable.getName());	
			}
		}
		model.append("\nSubject To\n");
		List<Constraint> constraints = task.getConstraints();
		int rowCnt = 0;
		for (Constraint constraint : constraints) {
			int varCnt = 0;
			for (Variable var : constraint.getVariables()) {
				if (varCnt  == 0) {
					model.append(" c" + rowCnt++ + ": " + var.getCoefficient() + " " + var.getName());
					++varCnt;
				} else {
					model.append(" + " + var.getCoefficient() + " " + var.getName());
				}
			}
			if (constraint.getType().equalsIgnoreCase("e")) {
				model.append(" = " + constraint.getRhs()+"\n");
			} else if (constraint.getType().equalsIgnoreCase("l")) {
				model.append(" <= " + constraint.getRhs()+"\n");
			} else if (constraint.getType().equalsIgnoreCase("g")) {
				model.append(" >= " + constraint.getRhs()+"\n");
			}
		}
	}
	
	/* (non-Javadoc)
	 * @see de.htwg.orweb.lps.file.IFormatGenerator#write(java.lang.String)
	 */
	@Override
	public void write(String trg) throws IOException {
		if (model == null) {
			build();
		}
		File trgFile = new File(trg);
		if (!trgFile.exists()) {
			trgFile.createNewFile();
		}
		BufferedWriter bw = new BufferedWriter(new FileWriter(new File(trg)));
		bw.write(model.toString());
		bw.flush();
		bw.close();
		
	}

	/* (non-Javadoc)
	 * @see de.htwg.orweb.lps.file.IFormatGenerator#getContent()
	 */
	@Override
	public String getContent() {
		if (model == null) {
			build();
		}
		return model.toString();
	}

}
