/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps.file;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import de.htwg.orweb.common.task.Bound;
import de.htwg.orweb.common.task.Constraint;
import de.htwg.orweb.common.task.Objective;
import de.htwg.orweb.common.task.Task;
import de.htwg.orweb.common.task.Variable;

public class MpsFormatGenerator implements IFormatGenerator{

	private static final String INST_NAME_DEC = "NAME";
	private static final String INST_NAME_VAL = "WEBOR_PROBLEM_INSTANCE";
	private static final String INST_ROW_DEC = "ROWS";
	private static final String INST_COLUMN_DEC = "COLUMNS";
	private static final String INST_RHS_DEC = "RHS";
	private static final String INST_BOUNDS_DEC = "BOUNDS";
	private static final String INST_END_DEC = "ENDATA";

	private static final String INST_BLANK = " ";
	private static final String INST_ROW_BLANK = " ";
	private static final String INST_DELIMITER = "	";
	private static final String INST_RETURN = "\r\n";

	private static final String INST_OBJ_IDENT = "OBJ";

	private static final String INST_OBJ_N = "N";

	/**
	 * @author schobast
	 * 
	 */
	private class RowCoefficient {

		private String rowName;
		private double coefficient;

		/**
		 * 
		 */
		public RowCoefficient(String rowName, double coefficient) {
			this.rowName = rowName;
			this.coefficient = coefficient;
		}

		public String getRowName() {
			return rowName;
		}

		public double getCoefficient() {
			return coefficient;
		}

	}

	private Task task;
	private Map<String, List<RowCoefficient>> integerColumnMap;
	private Map<String, List<RowCoefficient>> columnMap;
	private Map<String, String> rowMap;
	private Map<String, Double> rhsMap;
	private StringBuilder builder;

	/**
	 * 
	 */
	public MpsFormatGenerator(Task task) {
		this.task = task;
		this.columnMap = new HashMap<>();
		this.integerColumnMap = new HashMap<>();
		this.rowMap = new HashMap<>();
		this.rhsMap = new HashMap<>();
		preprocess();
		build();
	}

	private boolean isInteger(Variable var) {
		if (task.getBounds() != null) {
			for (Bound bound : task.getBounds()) {
				if (var.getName().equals(bound.getVariableName())) {
					if (bound.isInteger()) {
						return true;
					}
				}
			}
		}
		return false;
	}
	
	private void modifyConstraintNames(List<Constraint> constraints){
		boolean update = false;
		for (Constraint constraint : constraints) {
			if (constraint.getName() == null) {
				update = true;
				break;
			}
		}
		if (update) {
			int cnt = 0;
			for (Constraint constraint : constraints) {
				constraint.setName("C" + cnt++);
			}
		}
	}

	/**
	 * 
	 */
	private void preprocess() {
		modifyConstraintNames(task.getConstraints());
		Objective obj = task.getObjective();
		rowMap.put(INST_OBJ_IDENT, INST_OBJ_N);
		for (Variable var : obj.getVariables()) {
			if (isInteger(var)) {
				if (integerColumnMap.get(var.getName()) == null) {
					integerColumnMap.put(var.getName(),
							new ArrayList<RowCoefficient>());
				}
				List<RowCoefficient> list = integerColumnMap.get(var.getName());
				if (!isAlreadyStored(list, INST_OBJ_IDENT)) {
					integerColumnMap.get(var.getName()).add(
							new RowCoefficient(INST_OBJ_IDENT, var
									.getCoefficient()));
				}
			} else {
				if (columnMap.get(var.getName()) == null) {
					columnMap.put(var.getName(),
							new ArrayList<RowCoefficient>());
				}
				List<RowCoefficient> list = columnMap.get(var.getName());
				if (!isAlreadyStored(list, INST_OBJ_IDENT)) {
					columnMap.get(var.getName()).add(
							new RowCoefficient(INST_OBJ_IDENT, var
									.getCoefficient()));
				}
			}

		}
		for (Constraint con : task.getConstraints()) {
			rhsMap.put(con.getName(), con.getRhs());
			rowMap.put(con.getName(), con.getType());
			for (Variable var : con.getVariables()) {
				if (isInteger(var)) {
					if (integerColumnMap.get(var.getName()) == null) {
						integerColumnMap.put(var.getName(),
								new ArrayList<RowCoefficient>());
					}
					List<RowCoefficient> list = integerColumnMap.get(var.getName());
					if (!isAlreadyStored(list, con.getName())) {
						RowCoefficient cof = new RowCoefficient(con.getName(),
								var.getCoefficient());
						integerColumnMap.get(var.getName()).add(cof);
					}
				} else {
					if (columnMap.get(var.getName()) == null) {
						columnMap.put(var.getName(),
								new ArrayList<RowCoefficient>());
					}
					List<RowCoefficient> list = columnMap.get(var.getName());
					if (!isAlreadyStored(list, con.getName())) {
						RowCoefficient cof = new RowCoefficient(con.getName(),
								var.getCoefficient());
						columnMap.get(var.getName()).add(cof);
					}
				}
			}
		}
	}

	private static String fillMissingBlanks(String s, int size) {
		int gap = size - s.length();
		String add = "";
		for (int i = 0; i <= gap; i++) {
			add += INST_BLANK;
		}
		return s + add;
	}

	private boolean isAlreadyStored(List<RowCoefficient> list,
			String constraintName) {
		for (RowCoefficient cof : list) {
			if (cof.getRowName().equals(constraintName)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 
	 */
	private void build() {
		preprocess();
		builder = new StringBuilder(INST_NAME_DEC);
		String s = INST_DELIMITER + INST_NAME_VAL + INST_RETURN + INST_ROW_DEC
				+ INST_RETURN;
		builder.append(s);
		for (Entry<String, String> row : rowMap.entrySet()) {
			builder.append(INST_BLANK + row.getValue() + INST_ROW_BLANK
					+ INST_BLANK + row.getKey() + INST_RETURN);
		}
		builder.append(INST_COLUMN_DEC + INST_RETURN);

		if (!integerColumnMap.isEmpty()) {
			builder.append("    " + "MARK0000" + 
					"  " +"'MARKER'" + "                 " + "'INTORG'" + INST_RETURN);
			for (Entry<String, List<RowCoefficient>> column : integerColumnMap
					.entrySet()) {
				for (RowCoefficient rowCoefficient : column.getValue()) {
					builder.append("    "
							+ fillMissingBlanks(column.getKey(), 8)
							+ INST_BLANK
							+ fillMissingBlanks(rowCoefficient.getRowName(), 8)
							+ INST_BLANK
							+ fillMissingBlanks(String.valueOf(rowCoefficient
									.getCoefficient()), 8) + INST_RETURN);
				}
			}
			builder.append("    " + "MARK0001" + 
					"  " +"'MARKER'" + "                 " + "'INTEND'" + INST_RETURN);		}
		for (Entry<String, List<RowCoefficient>> column : columnMap.entrySet()) {
			for (RowCoefficient rowCoefficient : column.getValue()) {
				builder.append("    "
						+ fillMissingBlanks(column.getKey(), 8)
						+ INST_BLANK
						+ fillMissingBlanks(rowCoefficient.getRowName(), 8)
						+ INST_BLANK
						+ fillMissingBlanks(
								String.valueOf(rowCoefficient.getCoefficient()),
								8) + INST_RETURN);
			}
		}
		builder.append(INST_RHS_DEC + INST_RETURN);
		for (Entry<String, Double> rhs : rhsMap.entrySet()) {
			builder.append("    " + fillMissingBlanks("RH1", 8) + INST_BLANK
					+ fillMissingBlanks(rhs.getKey(), 8) + INST_BLANK
					+ fillMissingBlanks(String.valueOf(rhs.getValue()), 8)
					+ INST_RETURN);
		}
		boolean isBoundSet = false;
		if (task.getBounds() != null) {
			for (Bound bound : task.getBounds()) {
				if (!bound.getVariableName().isEmpty()) {
					if (!isBoundSet) {
						builder.append(INST_BOUNDS_DEC + INST_RETURN);
						isBoundSet = true;

					}
					if (bound.getLowerBound() != 0) {
						builder.append(INST_BLANK
								+ "LO"
								+ INST_BLANK
								+ fillMissingBlanks("BND1", 8)
								+ "  "
								+ fillMissingBlanks(bound.getVariableName(), 8)
								+"  " +fillMissingBlanks(
										String.valueOf(bound.getLowerBound()), 8)
								+ INST_RETURN);
					}
					if (bound.getUpperBound() == 0) {
						builder.append(INST_BLANK
								+ "PL"
								+ INST_BLANK
								+ fillMissingBlanks("BND1", 8)
								+ "  "
								+ fillMissingBlanks(bound.getVariableName(), 8)
								+ "  "+fillMissingBlanks(
										String.valueOf(bound.getUpperBound()), 8)
								+ INST_RETURN);
					} else {
						builder.append(INST_BLANK
								+ "UP"
								+ INST_BLANK
								+ fillMissingBlanks("BND1", 8)
								+ "  "
								+ fillMissingBlanks(bound.getVariableName(), 8)
								+ "  " + fillMissingBlanks(
										String.valueOf(bound.getUpperBound()), 8)
								+ INST_RETURN);
					}
				}
			}

		}
		builder.append(INST_END_DEC);
	}

	/**
	 * @param trg
	 * @throws IOException
	 */
	public void write(String trg) throws IOException {
		File trgFile = new File(trg);
		if (!trgFile.exists()) {
			trgFile.createNewFile();
		}
		BufferedWriter bw = new BufferedWriter(new FileWriter(new File(trg)));
		bw.write(builder.toString());
		bw.flush();
		bw.close();
	}

	/**
	 * @return
	 */
	public String getContent() {
		return builder.toString();
	}
}
