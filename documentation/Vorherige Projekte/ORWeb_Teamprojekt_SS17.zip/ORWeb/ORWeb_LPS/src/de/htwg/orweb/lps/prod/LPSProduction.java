/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps.prod;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.bind.JAXBException;

import de.htwg.orweb.common.result.Result;
import de.htwg.orweb.common.result.VariableResult;
import de.htwg.orweb.common.shared.Model;
import de.htwg.orweb.common.task.Constraint;
import de.htwg.orweb.common.task.Task;
import de.htwg.orweb.common.xml.JAXBUtil;
import de.htwg.orweb.lps.ITaskProcessor;
import de.htwg.orweb.lps.builder.ConvertMpsResultBuilder;
import de.htwg.orweb.lps.common.Configurator;
import de.htwg.orweb.lps.file.MpsFormatGenerator;
import de.htwg.orweb.lps.solver.ISolver;
import de.htwg.orweb.lps.solver.SolverWrapper;

public class LPSProduction extends ITaskProcessor implements ILPSolver {
	
	private static final Pattern NUM_PATTERN = Pattern.compile("[a-zA-Z]+(\\d+)");

	/**
	 * 
	 */
	private Configurator config;

	/**
	 * 
	 */
	public LPSProduction(final Configurator config) {
		this.config = config;
	}

	/**
	 * 
	 */
	public LPSProduction() {
		this.config = new Configurator(null);
	}

	/**
	 * @param cfgPath
	 */
	public LPSProduction(String cfgPath) {
		this.config = new Configurator(cfgPath);
	}

	/**
	 * 
	 */
	private void forcePositivValues() {
		if (result.getObjective().getValue() < 0) {
			result.getObjective().setValue((-1) * result.getObjective().getValue());
		}
	}
	

	/**
	 * @param task
	 */
	private void processSolveFromModel(Task task) {
		System.out.println(this.getClass().toString() + "> DEBUG: Processing task, type=solveFromModel");
		String trg = config.getTargetModelFile();
		System.out.println(this.getClass().toString() + "> DEBUG: Writing file to " + trg);
		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new FileWriter(trg));
			bw.write(task.getModel().getMpsModel());
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			bw.flush();
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		ISolver solver = new SolverWrapper(config, task);
		this.result = solver.solve(trg, task.getObjective().getType());
		if (task.getMeta().getForcePositive()) {
			forcePositivValues();
		}
	}

	/**
	 * @param task
	 */
	private void processTransform(Task task) {
		System.out.println(this.getClass().toString() + "> DEBUG: Processing task, type=transform");
		result = new ConvertMpsResultBuilder(task).createResultTask();
	}

	/**
	 * @param task
	 */
	private void processConvert(Task task) {
		System.out.println(this.getClass().toString() + "> DEBUG: Processing task, type=convert");
		Result res = new Result();
		MpsFormatGenerator writer = new MpsFormatGenerator(task);
		res.setModel(new Model(writer.getContent()));
		this.result = res;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * de.htwg.orweb.lps.ITaskProcessor#processTask(de.htwg.orweb.common.task.
	 * Task)
	 */
	@Override
	public void processTask(Task task) {
		try {
			try {
				JAXBUtil.toFile(task, config.getOsSeparator(), config.getDebugOutDir(), "%s_task.xml");
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		} catch (JAXBException e1) {
			e1.printStackTrace();
		}
		File temp = new File(config.getTempDir());
		if (!temp.exists()) {
			temp.mkdir();
		} else if (task.getMeta().getSolveFromModel()) {
			processSolveFromModel(task);
		} else if (task.getMeta().getTransform()) {
			processTransform(task);
			try {
				JAXBUtil.toFile( result,config.getOsSeparator(), config.getDebugOutDir(), "%s_result.xml");
			} catch (JAXBException e) {
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		} else if (task.getMeta().getConvert()) {
			processConvert(task);
		} else {
			System.out.println(this.getClass().toString() + "> DEBUG: Processing task, type=solve");
			String trg = config.getTargetModelFile();
			MpsFormatGenerator writer = new MpsFormatGenerator(task);
			try {
				writer.write(trg);
			} catch (IOException e) {
				e.printStackTrace();
			}
			ISolver solver = new SolverWrapper(config, task);
			this.result = solver.solve(trg, task.getObjective().getType());
			Model model = new Model(writer.getContent());
			result.setModel(model);
			if (result.isFeasible() && task.getMeta().getForcePositive()) {
				forcePositivValues();
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * de.htwg.orweb.lps.prod.ILPSolver#solve(de.htwg.orweb.common.task.Task)
	 */
	@Override
	public Result solve(Task task) {
		try {
			JAXBUtil.toConsole(task);
		} catch (JAXBException e) {
			e.printStackTrace();
		}
		File tempDir = new File(config.getTempDir());
		if (!tempDir.exists()) {
			tempDir.mkdir();
		}
		processTask(task);
		
		//Perform ascending sorts
		sortVariableResults();
		sortConstraints();
		try {
			JAXBUtil.toConsole(result);
		} catch (JAXBException e) {
			e.printStackTrace();
		}
		try {
			if (!config.isValid()) {
				result = null;
			}
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	private void sortVariableResults(){
		if (result.getVariables() != null) {
			List<VariableResult> varList = result.getVariables();
			Collections.sort(varList, new Comparator<VariableResult>() {
				
				public int compare(VariableResult a, VariableResult b) {
					Matcher ma = NUM_PATTERN.matcher(a.getName());
					Matcher mb = NUM_PATTERN.matcher(b.getName());
					int aName = 0, bName = 0;
					if (ma.matches()) {
						aName = Integer.parseInt(ma.group(1));
					}
					if (mb.matches()) {
						bName = Integer.parseInt(mb.group(1));
					}
					// ascending order
					return Integer.compare(aName, bName);
				}
			});
		}
	}
	
	private void sortConstraints(){
		if (result.getTask() != null) {
			List<Constraint> varList = result.getTask().getConstraints();
			Collections.sort(varList, new Comparator<Constraint>() {
				
				public int compare(Constraint a, Constraint b) {
					Matcher ma = NUM_PATTERN.matcher(a.getName());
					Matcher mb = NUM_PATTERN.matcher(b.getName());
					int aName = 0, bName = 0;
					if (ma.matches()) {
						aName = Integer.parseInt(ma.group(1));
					}
					if (mb.matches()) {
						bName = Integer.parseInt(mb.group(1));
					}
					// ascending order
					return Integer.compare(aName, bName);
				}
			});
		}
	}
}
