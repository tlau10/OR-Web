/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps.solver;


import java.io.File;

import de.htwg.orweb.common.result.Result;
import de.htwg.orweb.lps.builder.DynamicResultBuilder;
import de.htwg.orweb.lps.builder.IResultBuilder;
import de.htwg.orweb.lps.common.CommonUtils;
import de.htwg.orweb.lps.common.Configurator;
import de.htwg.orweb.lps.common.SupportedEnv;

public class CBCSolverImpl implements ISolver {
	
	/**
	 * 
	 */
	public CBCSolverImpl(Configurator conf) {
		String os = SupportedEnv.LINUX_ENV.getEnv();
		String lib = conf.getLinuxCbcLibResource();
		if (conf.getTargetEnv() == SupportedEnv.WIN_ENV) {
			os = SupportedEnv.WIN_ENV.getEnv();
			lib = conf.getWinCbcLibResource();
		}
		File libTarget = new File(conf.getLibDir());
		if (!libTarget.exists()) {
			libTarget.mkdir();
		}
		String library = conf.getLibDir() + conf.getOsSeparator() + lib;
		if (!new File(library).exists()) {
			try {
				System.out.println(os + "/" + lib);
				CommonUtils.exportResource(lib,os,
						libTarget.getAbsolutePath(), conf.getOsSeparator());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		try {
			System.load(library);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.htwg.orweb.lps.solver.ISolver#solve(java.lang.String)
	 */
	@Override
	public Result solve(String mps, String type) {
		double sense = 1;
		if (type.toUpperCase().equals(ObjectiveType.MAX.toString())) {
			sense = -1;
		}
		long init = System.currentTimeMillis();
		String[] ret = call(mps, sense);
		IResultBuilder builder = new DynamicResultBuilder(ret);
		return builder.build(System.currentTimeMillis() - init);
	}

	/**
	 * @param mps
	 * @param sense
	 * @return
	 */
	private native String[] call(String mps, double sense);

}
