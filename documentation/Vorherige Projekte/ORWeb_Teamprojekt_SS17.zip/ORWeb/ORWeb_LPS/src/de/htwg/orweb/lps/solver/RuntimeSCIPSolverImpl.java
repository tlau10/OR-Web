/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps.solver;

import de.htwg.orweb.common.result.Result;
import de.htwg.orweb.lps.builder.IResultBuilder;
import de.htwg.orweb.lps.builder.RuntimeSCIPResultBuilder;
import de.htwg.orweb.lps.common.CommonUtils;
import de.htwg.orweb.lps.common.Configurator;
import de.htwg.orweb.lps.common.SupportedEnv;

import java.io.*;
import java.util.Arrays;

public class RuntimeSCIPSolverImpl implements ISolver {
    /**
     *
     */
    private Configurator conf;

    /**
     *
     */
    private String solverBinary;

    /**
     *
     */
    private void setEnv() {
        String os = SupportedEnv.LINUX_ENV.getEnv();
        String bin = conf.getLinuxSCIPExecResource();
        if (conf.getTargetEnv() == SupportedEnv.WIN_ENV) {
            os = SupportedEnv.WIN_ENV.getEnv();
            bin = conf.getWinSCIPExecResource();
        }
        File libTarget = new File(conf.getLibDir());
        if (!libTarget.exists()) {
            libTarget.mkdir();
        }
        solverBinary = conf.getLibDir() + conf.getOsSeparator() + bin;
        if (!new File(solverBinary).exists()) {
            try {
                CommonUtils.exportResource(bin, os, libTarget.getAbsolutePath(), conf.getOsSeparator());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public RuntimeSCIPSolverImpl(Configurator config) {
        this.conf = config;
        setEnv();
    }

    /*
     * (non-Javadoc)
     *
     * @see de.htwg.orweb.lps.solver.ISolver#solve(java.lang.String,
     * java.lang.String)
     */
    @Override
    public Result solve(String mps, String sense) {
        String solution = conf.getTargetSolutionFile();
        Process p = null;
        long init = System.currentTimeMillis();
        try {
            System.out.println(this.getClass() + "> DEBUG:: Printing runtime solver arguments: \n"
                    + Arrays.toString(new String[]{solverBinary, "-c",
                    "'read " + mps + " change objsense " + sense + " optimize display solution quit'"}));

            ProcessBuilder builder = null;

            if (conf.getTargetEnv() == SupportedEnv.LINUX_ENV) {
                builder = new ProcessBuilder(
                        solverBinary, "-c", "read " + mps + " change objsense " + sense + " optimize display solution quit");
            } else {
                builder = new ProcessBuilder(
                        solverBinary, "-c", "\"read " + mps + " change objsense " + sense + " optimize display solution quit\"");
            }

            p = builder.start();

            //p = Runtime.getRuntime().exec(new String[] { solverBinary, "-c",
            //		"\"read " + mps + " change objsense " + sense + " optimize display solution quit\"" });

        } catch (IOException e) {
            e.printStackTrace();
        }


        BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line, output = "";
        try {
            while ((line = reader.readLine()) != null) {
                output += line + "\n";
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (p != null) {
            p.destroy();
        }

        System.out.println(this.getClass() + "> DEBUG:: Printing solver output: \n" + output);
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(solution, true));
            bw.write(output);
            bw.flush();
            bw.close();
        } catch (
                IOException e) {
            e.printStackTrace();
        }

        IResultBuilder builder = new RuntimeSCIPResultBuilder(readSolution(solution));
        return builder.build(System.currentTimeMillis() - init);
    }

    private String readSolution(String solutionFile) {
        File f = new File(solutionFile);
        String solution = "";
        try {
            BufferedReader br = new BufferedReader(new FileReader(f));
            String line = "";
            while ((line = br.readLine()) != null) {
                solution += line + "\r\n";
            }
            br.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return solution;
    }

}
