package com.tagesplanung.client;

import com.extjs.gxt.ui.client.event.EventType;

// TODO: Auto-generated Javadoc
/**
 * The Class AppEvents.
 */
public class AppEvents {
	 
 	/** The Constant Init. */
 	public static final EventType Init = new EventType();
}
