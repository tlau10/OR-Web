package com.tagesplanung.client;

import java.util.List;
import java.util.Map;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.tagesplanung.shared.Bedarf;
import com.tagesplanung.shared.Result;
import com.tagesplanung.shared.ResultBaseModel;
import com.tagesplanung.shared.ShiftBaseModel;

/**
 * The Interface PersPlanService defines which methods are available and can be
 * called on the server.
 */
@RemoteServiceRelativePath("PersPlanService")
public interface PersPlanService extends RemoteService {

	/**
	 * The solve method contains all the logic to solve the LP problem which was
	 * specified in the GUI and compute a result which can be displayed in the
	 * GUI again.
	 * 
	 * @param bList
	 *            the demand list
	 * @param sList
	 *            the shift list
	 * @return the result list
	 */
	public List<Result> solve(List<Bedarf> bList, List<ShiftBaseModel> sList);

	/**
	 * The saveDemandData method create the wrapper class SaveLoadDemand and set
	 * the bedarf list as value. Then marshall the SaveLoadDemand object in a
	 * xml document.
	 * 
	 * @param bList
	 *            the demand list
	 * @return the filepath of the file
	 */
	public String saveDemandData(List<Bedarf> bList);

	/**
	 * The saveShiftData method create the wrapper class SaveLoadShift and set
	 * the ShiftBaseModel list as value. Then marshall the SaveLoadShift object
	 * in a xml document.
	 * 
	 * @param sList
	 *            the shift list
	 * @return the filepath of the file
	 */
	public String saveShiftData(List<ShiftBaseModel> sList);

	/**
	 * The loadDemandData method unmarshall the LoadFile.xml in a SaveLoadDemand
	 * object and delete afterwards the file.
	 * 
	 * @return the demand list from the SaveLoadDemand object
	 */
	public List<Bedarf> loadDemandData();

	/**
	 * The loadShiftData method unmarshall the LoadFile.xml in a SaveLoadShift
	 * object and delete afterwards the file.
	 * 
	 * @return the shift list from the SaveLoadShift object
	 */
	public List<ShiftBaseModel> loadShiftData();

	/**
	 * The method deleteFile delete a file if it exists.
	 * 
	 * @param file
	 *            the file
	 * @return the the filepath
	 */
	public String deleteFile(String file);

	/**
	 * Gets the result base model.
	 * 
	 * @param result
	 *            the result
	 * @return the result base model
	 */
	public List<ResultBaseModel> getResultBaseModel(List<Result> result);

	/**
	 * Gets the graphic visualization of the result.
	 * 
	 * @param result
	 *            the result
	 * @param bList
	 *            the b list
	 * @return the graphic visualization of the result
	 */
	public int[][] getGraficVisualOfResult(List<Result> result, List<Bedarf> bList);

	/**
	 * Gets the URL of the HTML file with the LP model.
	 * 
	 * @return the URL of LP model file
	 */
	public String getLPURL();

	// Begin of Change by fafilipp
	/**
	 * Gets the Properties for the Start and End allowness for Night Breaks
	 * 
	 * @return the Properties as Map (0 is start, 1 is end)
	 */
	public Map<Integer, String> getNightBreakAllowness();
	// End of Change
}
