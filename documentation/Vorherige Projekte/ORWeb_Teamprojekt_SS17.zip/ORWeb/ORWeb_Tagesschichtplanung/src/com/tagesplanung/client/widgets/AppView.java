package com.tagesplanung.client.widgets;

import com.extjs.gxt.ui.client.Style.LayoutRegion;
import com.extjs.gxt.ui.client.Style.Scroll;
import com.extjs.gxt.ui.client.event.Listener;
import com.extjs.gxt.ui.client.event.MenuEvent;
import com.extjs.gxt.ui.client.event.MessageBoxEvent;
import com.extjs.gxt.ui.client.event.SelectionListener;
import com.extjs.gxt.ui.client.mvc.AppEvent;
import com.extjs.gxt.ui.client.mvc.Controller;
import com.extjs.gxt.ui.client.mvc.View;
import com.extjs.gxt.ui.client.util.Margins;
import com.extjs.gxt.ui.client.widget.MessageBox;
import com.extjs.gxt.ui.client.widget.TabItem;
import com.extjs.gxt.ui.client.widget.TabPanel;
import com.extjs.gxt.ui.client.widget.Viewport;
import com.extjs.gxt.ui.client.widget.layout.BorderLayout;
import com.extjs.gxt.ui.client.widget.layout.BorderLayoutData;
import com.extjs.gxt.ui.client.widget.menu.Menu;
import com.extjs.gxt.ui.client.widget.menu.MenuBar;
import com.extjs.gxt.ui.client.widget.menu.MenuBarItem;
import com.extjs.gxt.ui.client.widget.menu.MenuItem;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.RootPanel;
import com.tagesplanung.shared.resources.Resources;

// TODO: Auto-generated Javadoc
/**
 * The Class AppView.
 */
public class AppView extends View {
	
	/** The viewport. */
	private Viewport viewport;

	// internationalization with .properties file
	/** The constants. */
	private PersPlanConstants constants = (PersPlanConstants) GWT.create(PersPlanConstants.class);

	/**
	 * Instantiates a new app view.
	 *
	 * @param controller the controller
	 */
	public AppView(Controller controller) {
		super(controller);
	}
	
	/* (non-Javadoc)
	 * @see com.extjs.gxt.ui.client.mvc.View#handleEvent(com.extjs.gxt.ui.client.mvc.AppEvent)
	 */
	@Override
	protected void handleEvent(AppEvent event) {
		// doing nothing
	}
	
	/* (non-Javadoc)
	 * @see com.extjs.gxt.ui.client.mvc.View#initialize()
	 */
	protected void initialize() {
		final BedarfsplanView bdview = new BedarfsplanView();
		final ShiftlistView shiftview = new ShiftlistView();
		ResultView resultView = new ResultView();
		viewport = new Viewport();
		viewport.setLayout(new BorderLayout());
		BorderLayoutData centerLayoutData = new BorderLayoutData(LayoutRegion.CENTER);
		centerLayoutData.setMargins(new Margins(10));
		BorderLayoutData northLayoutData = new BorderLayoutData(LayoutRegion.NORTH);
		northLayoutData.setSize(25);
		TabPanel tabPanel = new TabPanel();
		TabItem tpItem1 = new TabItem(constants.demandPlaning());
		TabItem tpItem2 = new TabItem(constants.shiftPlaning());
		TabItem tpItem3 = new TabItem(constants.result());
		tpItem1.setIcon(Resources.ICONS.clock());
		tpItem2.setIcon(Resources.ICONS.shift());
		tpItem3.setIcon(Resources.ICONS.result());
		tpItem1.setScrollMode(Scroll.AUTO);
		tpItem2.setScrollMode(Scroll.AUTO);
		tpItem3.setScrollMode(Scroll.AUTO);

		// adding menu bar
		Menu fileMenu = new Menu();
		MenuItem newFile = new MenuItem(constants.newItem());
		newFile.setIcon(Resources.ICONS.newFile());
		MenuItem load = new MenuItem(constants.openFile());
		load.setIcon(Resources.ICONS.open());
		MenuItem save = new MenuItem(constants.saveFile());
		save.setIcon(Resources.ICONS.save());
		fileMenu.add(newFile);
		fileMenu.add(load);
		fileMenu.add(save);
		Menu subLoad2 = new Menu();
		Menu subSave2 = new Menu();
		load.setSubMenu(subLoad2);
		save.setSubMenu(subSave2);
		MenuItem loadDemand2 = new MenuItem(constants.openDemandList());
		loadDemand2.setIcon(Resources.ICONS.open_demand());
		MenuItem loadShifts2 = new MenuItem(constants.openShiftList());
		loadShifts2.setIcon(Resources.ICONS.open_shifts());
		MenuItem saveDemand2 = new MenuItem(constants.saveDemandList());
		saveDemand2.setIcon(Resources.ICONS.save_demand());
		MenuItem saveShifts2 = new MenuItem(constants.saveShiftList());
		saveShifts2.setIcon(Resources.ICONS.save_shifts());
		subLoad2.add(loadDemand2);
		subLoad2.add(loadShifts2);
		subSave2.add(saveDemand2);
		subSave2.add(saveShifts2);
		
		Menu helpMenu = new Menu();
		MenuItem help = new MenuItem(constants.helpTopics());
		help.setIcon(Resources.ICONS.help());
		MenuItem about = new MenuItem(constants.about());
		about.setIcon(Resources.ICONS.info());
		helpMenu.add(help);
		helpMenu.add(about);
		
		MenuItemHandler menuItemHandler = new MenuItemHandler(bdview, shiftview);	
		newFile.addSelectionListener(menuItemHandler);
		loadDemand2.addSelectionListener(menuItemHandler);
		loadShifts2.addSelectionListener(menuItemHandler);
		saveDemand2.addSelectionListener(menuItemHandler);
		saveShifts2.addSelectionListener(menuItemHandler);
		help.addSelectionListener(menuItemHandler);
		about.addSelectionListener(menuItemHandler);				
		// Change language option
		Menu languageMenu = new Menu();
		MenuItem german = new MenuItem(constants.german());
		german.setIcon(Resources.ICONS.ger());
		languageMenu.add(german);
		german.addSelectionListener(new SelectionListener<MenuEvent>(){
			public void componentSelected(MenuEvent ce) {
				Window.Location.replace(Window.Location.getPath() + "?locale=de");
			}
		});		
		MenuItem english = new MenuItem(constants.english());
		english.setIcon(Resources.ICONS.gb());
		languageMenu.add(english);
		english.addSelectionListener(new SelectionListener<MenuEvent>(){
			public void componentSelected(MenuEvent ce) {
				Window.Location.replace(Window.Location.getPath() + "?locale=en");
			}
		}); 
		MenuBar mb = new MenuBar();
		mb.add(new MenuBarItem(constants.file(),fileMenu));
		mb.add(new MenuBarItem(constants.languages(),languageMenu));
		mb.add(new MenuBarItem(constants.help(),helpMenu));
		tpItem1.add(bdview.getView());
		tpItem2.add(shiftview.getView());
		tpItem3.add(resultView.getView());
		tabPanel.add(tpItem1);
		tabPanel.add(tpItem2);
		tabPanel.add(tpItem3);
		viewport.add(tabPanel, centerLayoutData);
		viewport.add(mb, northLayoutData);
		RootPanel.get().add(viewport);
	}

	/**
	 * The Class MenuItemHandler.
	 */
	private class MenuItemHandler extends SelectionListener<MenuEvent> {
		
		/** The bdview. */
		BedarfsplanView bdview;
		
		/** The shiftview. */
		ShiftlistView shiftview;
		
		/**
		 * Instantiates a new menu item handler.
		 *
		 * @param bdview the bdview
		 * @param shiftview the shiftview
		 */
		public MenuItemHandler(BedarfsplanView bdview, ShiftlistView shiftview) {
			this.bdview = bdview;
			this.shiftview = shiftview;
		}

		/* (non-Javadoc)
		 * @see com.extjs.gxt.ui.client.event.SelectionListener#componentSelected(com.extjs.gxt.ui.client.event.ComponentEvent)
		 */
		public void componentSelected(MenuEvent me) {
			MenuItem menuItem = (MenuItem) me.getItem();
			if (menuItem.getText().compareTo(constants.openDemandList()) == 0) {
				new FileUploadView(constants.demandPlaning(), shiftview).show();
			}
			if (menuItem.getText().compareTo(constants.openShiftList()) == 0) {
				new FileUploadView(constants.shiftPlaning(), shiftview).show();
			}
			if (menuItem.getText().compareTo(constants.saveDemandList()) == 0) {
				new FileDownloadView(constants.demandPlaning()).show();
			}
			if (menuItem.getText().compareTo(constants.saveShiftList()) == 0) {
				new FileDownloadView(constants.shiftPlaning()).show();
			}
			if (menuItem.getText().compareTo(constants.helpTopics()) == 0) {
				Window.open("./resources/files/help/help.pdf", constants.helpTopics(), "");
			}
			if (menuItem.getText().compareTo(constants.about()) == 0) {
				new InfoView().show();
			}
			if (menuItem.getText().compareTo(constants.newItem()) == 0) {
				MessageBox box = new MessageBox();
				box.setButtons(MessageBox.YESNOCANCEL);
				box.setIcon(MessageBox.QUESTION);
				box.setTitle(constants.saveChanges());
				box.setMessage(constants.saveWarning());
				box.addCallback(new Listener<MessageBoxEvent>() {
					public void handleEvent(MessageBoxEvent be) {
						if (be.getButtonClicked().getText() == "Yes") {
							new FileDownloadView(constants.demandPlaning()).show();
							new FileDownloadView(constants.shiftPlaning()).show();
						}
						if (be.getButtonClicked().getText() == "No") {
							shiftview.getSLC().resetStore();
							bdview.reset();
						}
					}
				});
				box.show();
			}
		}
	}
}