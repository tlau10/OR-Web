package com.tagesplanung.client.widgets;

import java.util.ArrayList;
import java.util.List;

import com.extjs.gxt.charts.client.Chart;
import com.extjs.gxt.charts.client.event.ChartEvent;
import com.extjs.gxt.charts.client.event.ChartListener;
import com.extjs.gxt.charts.client.model.BarDataProvider;
import com.extjs.gxt.charts.client.model.ChartModel;
import com.extjs.gxt.charts.client.model.Legend;
import com.extjs.gxt.charts.client.model.Legend.Position;
import com.extjs.gxt.charts.client.model.ScaleProvider;
import com.extjs.gxt.charts.client.model.axis.Label;
import com.extjs.gxt.charts.client.model.axis.XAxis;
import com.extjs.gxt.charts.client.model.charts.BarChart;
import com.extjs.gxt.charts.client.model.charts.BarChart.BarStyle;
import com.extjs.gxt.ui.client.Style.ButtonScale;
import com.extjs.gxt.ui.client.Style.HorizontalAlignment;
import com.extjs.gxt.ui.client.Style.IconAlign;
import com.extjs.gxt.ui.client.Style.LayoutRegion;
import com.extjs.gxt.ui.client.Style.Orientation;
import com.extjs.gxt.ui.client.Style.SelectionMode;
import com.extjs.gxt.ui.client.binding.FormBinding;
import com.extjs.gxt.ui.client.event.ButtonEvent;
import com.extjs.gxt.ui.client.event.Events;
import com.extjs.gxt.ui.client.event.FieldEvent;
import com.extjs.gxt.ui.client.event.GridEvent;
import com.extjs.gxt.ui.client.event.Listener;
import com.extjs.gxt.ui.client.event.MessageBoxEvent;
import com.extjs.gxt.ui.client.event.SelectionChangedEvent;
import com.extjs.gxt.ui.client.event.SelectionListener;
import com.extjs.gxt.ui.client.store.ListStore;
import com.extjs.gxt.ui.client.util.Margins;
import com.extjs.gxt.ui.client.widget.ContentPanel;
import com.extjs.gxt.ui.client.widget.LayoutContainer;
import com.extjs.gxt.ui.client.widget.MessageBox;
import com.extjs.gxt.ui.client.widget.button.Button;
import com.extjs.gxt.ui.client.widget.form.FormPanel;
import com.extjs.gxt.ui.client.widget.form.PropertyEditor;
import com.extjs.gxt.ui.client.widget.form.Radio;
import com.extjs.gxt.ui.client.widget.form.RadioGroup;
import com.extjs.gxt.ui.client.widget.form.TextField;
import com.extjs.gxt.ui.client.widget.grid.CellEditor;
import com.extjs.gxt.ui.client.widget.grid.ColumnConfig;
import com.extjs.gxt.ui.client.widget.grid.ColumnModel;
import com.extjs.gxt.ui.client.widget.grid.EditorGrid;
import com.extjs.gxt.ui.client.widget.grid.GridSelectionModel;
import com.extjs.gxt.ui.client.widget.grid.HeaderGroupConfig;
import com.extjs.gxt.ui.client.widget.layout.BorderLayout;
import com.extjs.gxt.ui.client.widget.layout.BorderLayoutData;
import com.extjs.gxt.ui.client.widget.layout.FitLayout;
import com.extjs.gxt.ui.client.widget.layout.FormData;
import com.extjs.gxt.ui.client.widget.layout.RowData;
import com.extjs.gxt.ui.client.widget.layout.RowLayout;
import com.extjs.gxt.ui.client.widget.toolbar.ToolBar;
import com.google.gwt.core.client.GWT;
import com.tagesplanung.shared.Bedarf;
import com.tagesplanung.shared.TimeIntervall;
import com.tagesplanung.shared.resources.Resources;

// TODO: Auto-generated Javadoc
/**
 * The Class BedarfsplanView.
 */
public class BedarfsplanView {

	// internationalization with .properties file
	/** The constants. */
	private PersPlanConstants constants = (PersPlanConstants) GWT.create(PersPlanConstants.class);

	/** The form bindings. */
	private FormBinding formBindings;

	/** The Constant store. */
	private final static ListStore<Bedarf> store = new ListStore<Bedarf>();

	/** The radio full hour. */
	private static Radio radioFullHour;

	/** The radio half hour. */
	private static Radio radioHalfHour;

	/** The halfhour. */
	public static boolean halfhour = false;

	/** The model. */
	private ChartModel model = new ChartModel(constants.graphicRepresentationOfDemand(),
			"font-weight: bold; font-size: 14px; font-family: Verdana; text-align: center;");

	/**
	 * Gets the view.
	 * 
	 * @return the view
	 */
	public LayoutContainer getView() {
		LayoutContainer outerContainer = new LayoutContainer(new RowLayout());
		outerContainer.setSize(1000, 700);
		outerContainer.setStyleAttribute("background-color", "#FFFFFF");
		LayoutContainer innerContainer = new LayoutContainer(new BorderLayout());
		innerContainer.setStyleAttribute("background-color", "#FFFFFF");
		LayoutContainer innerContainerWest = new LayoutContainer(new RowLayout());
		LayoutContainer innerContainerEast = new LayoutContainer(new RowLayout());

		BorderLayoutData centerLayoutData = new BorderLayoutData(LayoutRegion.CENTER);
		centerLayoutData.setMargins(new Margins(0, 0, 0, 0));
		BorderLayoutData eastLayoutData = new BorderLayoutData(LayoutRegion.EAST);
		eastLayoutData.setMargins(new Margins(0, 0, 0, 0));

		outerContainer.add(innerContainer, new RowData(1, 1, new Margins(0, 0, 0, 0)));
		innerContainer.add(innerContainerWest, centerLayoutData);
		innerContainer.add(innerContainerEast, eastLayoutData);

		// Begin of Change by fafilipp
		PropertyEditor<Integer> intPropEditor = new PropertyEditor<Integer>() {
			@Override
			public String getStringValue(Integer value) {
				return value.toString();
			}

			@Override
			public Integer convertStringValue(String value) {
				try {
					Integer i = new Integer(value);
					if (i < 0) {
						throw new NumberFormatException("Just positive values allowed.");
					}
					return i;
				} catch (NumberFormatException e) {
					return 0;
				}
			}
		};
		// End of Change

		List<ColumnConfig> configs = new ArrayList<ColumnConfig>();
		ColumnModel cm = new ColumnModel(configs);
		cm.addHeaderGroup(0, 0, new HeaderGroupConfig(constants.interval(), 1, 2));

		ColumnConfig rangeStart = new ColumnConfig();
		rangeStart.setId("startIntervall");
		rangeStart.setHeader(constants.from());
		rangeStart.setWidth(200);
		rangeStart.setMenuDisabled(true);

		rangeStart.setSortable(false);
		configs.add(rangeStart);

		ColumnConfig rangeEnd = new ColumnConfig();
		rangeEnd.setId("endIntervall");
		rangeEnd.setHeader(constants.to());
		rangeEnd.setWidth(200);
		rangeEnd.setMenuDisabled(true);
		rangeEnd.setSortable(false);
		configs.add(rangeEnd);

		ColumnConfig demand = new ColumnConfig();
		demand.setId("bedarf");
		demand.setHeader(constants.demand());
		demand.setWidth(200);
		demand.setMenuDisabled(true);
		// Begin Change (mibauer)
		demand.setSortable(false);
		// End Change
		configs.add(demand);

		// Begin of Change by fafilipp
		// Setzt ein Editor auf Demand, in welches nur Zahlen erlaubt sind.
		TextField<Integer> nf = new TextField<Integer>();
		nf.setAllowBlank(false);
		nf.setPropertyEditor(intPropEditor);
		demand.setEditor(new CellEditor(nf));
		// End of Change

		List<Bedarf> bedarfsListe = initializeBedarfslist();
		store.setMonitorChanges(true);
		store.add(bedarfsListe);

		final EditorGrid<Bedarf> grid = new EditorGrid<Bedarf>(store, cm);
		grid.setSelectionModel(new GridSelectionModel<Bedarf>());
		grid.setStyleAttribute("borderTop", "none");
		grid.setAutoExpandColumn("intervall");
		grid.setBorders(true);
		grid.setStripeRows(true);
		grid.getView().setForceFit(true);
		grid.getView().setShowDirtyCells(false);

		grid.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		grid.getSelectionModel().addListener(Events.SelectionChange, new Listener<SelectionChangedEvent<Bedarf>>() {
			@Override
			public void handleEvent(SelectionChangedEvent<Bedarf> be) {
				if (be.getSelection().size() > 0) {
					formBindings.bind(be.getSelection().get(0));
				} else {
					formBindings.unbind();
				}
			}
		});
		grid.addListener(Events.AfterEdit, new Listener<GridEvent<Bedarf>>() {
			@Override
			public void handleEvent(GridEvent<Bedarf> be) {
				store.commitChanges();
			}
		});

		FormPanel intervallFormPanel = new FormPanel();
		intervallFormPanel.setHeading(constants.timeInterval());
		intervallFormPanel.setIcon(Resources.ICONS.clock());
		intervallFormPanel.setCollapsible(true);
		intervallFormPanel.setAutoHeight(true);
		intervallFormPanel.setAutoWidth(true);
		intervallFormPanel.setFrame(true);

		radioFullHour = new Radio();
		radioFullHour.setBoxLabel(constants.hour());
		radioFullHour.setValue(true);

		radioHalfHour = new Radio();
		radioHalfHour.setBoxLabel(constants.halfanhour());

		RadioGroup radioGroup = new RadioGroup();
		radioGroup.setHideLabel(true);
		radioGroup.setOrientation(Orientation.VERTICAL);
		radioGroup.add(radioFullHour);
		radioGroup.add(radioHalfHour);
		radioGroup.setHeight(60);
		radioHalfHour.addListener(Events.Change, new Listener<FieldEvent>() {
			@Override
			public void handleEvent(FieldEvent be) {
				changeBedarfslistToIntervall();
			}
		});
		intervallFormPanel.add(radioGroup);

		FormPanel formPanel2 = new FormPanel();
		formPanel2.setHeading(constants.planningAssistant());
		formPanel2.setIcon(Resources.ICONS.demandAssistant());
		formPanel2.setCollapsible(true);
		formPanel2.setAutoHeight(true);
		formPanel2.setAutoWidth(true);
		formPanel2.setFrame(true);
		formPanel2.setButtonAlign(HorizontalAlignment.CENTER);

		TextField<String> symbol = new TextField<String>();
		symbol.setName("intervall");
		symbol.setFieldLabel(constants.interval());
		symbol.setReadOnly(true);
		formPanel2.add(symbol, new FormData("-20"));

		// Begin of Change by fafilipp
		TextField<Integer> bedarfField = new TextField<Integer>();
		bedarfField.setEmptyText("0");
		bedarfField.setPropertyEditor(intPropEditor);
		bedarfField.setName("bedarf");
		bedarfField.setFieldLabel(constants.demand());
		// End of Change
		formPanel2.add(bedarfField, new FormData("-20"));

		Button back = new Button(constants.back(), Resources.ICONS.back());
		back.setScale(ButtonScale.SMALL);
		back.addSelectionListener(new SelectionListener<ButtonEvent>() {
			@Override
			public void componentSelected(ButtonEvent ce) {
				grid.getSelectionModel().selectPrevious(true);
			}
		});

		Button forward = new Button(constants.forth(), Resources.ICONS.forward());
		forward.setIconAlign(IconAlign.RIGHT);
		forward.setScale(ButtonScale.SMALL);
		forward.addSelectionListener(new SelectionListener<ButtonEvent>() {
			@Override
			public void componentSelected(ButtonEvent ce) {
				grid.getSelectionModel().selectNext(true);
			}
		});
		formPanel2.addButton(back);
		formPanel2.addButton(forward);
		formBindings = new FormBinding(formPanel2, true);
		formBindings.setStore(grid.getStore());

		String url = "resources/chart/open-flash-chart.swf";
		final Chart chart = new Chart(url);

		ChartListener listener = new ChartListener() {
			@Override
			public void chartClick(ChartEvent ce) {
				int row = ce.getChartConfig().getValues().indexOf(ce.getDataType());
				int col = ce.getChartModel().getChartConfigs().indexOf(ce.getChartConfig()) + 1;
				GridSelectionModel<Bedarf> b = grid.getSelectionModel();
				grid.startEditing(row, col);
				b.select(row, true);
			}
		};

		model.setBackgroundColour("#fefefe");
		model.setLegend(new Legend(Position.TOP, true));
		model.setScaleProvider(ScaleProvider.ROUNDED_NEAREST_SCALE_PROVIDER);
		XAxis xa = new XAxis();
		for (TimeIntervall t : TimeIntervall.getFullIntervalls()) {
			Label l = new Label(t.getStartIntervall());
			l.setColour("#000000");
			xa.addLabels(l);
		}
		model.setXAxis(xa);

		BarChart bar = new BarChart(BarStyle.GLASS);
		bar.setColour("#00aa00");
		bar.addChartListener(listener);
		BarDataProvider barProvider = new BarDataProvider("bedarf");
		barProvider.bind(store);
		bar.setDataProvider(barProvider);
		model.addChartConfig(bar);

		chart.setChartModel(model);
		RowData data;
		data = new RowData(1, 300, new Margins(10));
		ContentPanel cp = new ContentPanel(new FitLayout());
		cp.setHeading(constants.demandList());
		cp.setIcon(Resources.ICONS.table());
		cp.setFrame(true);
		cp.add(grid);
		ToolBar toolBar = new ToolBar();
		toolBar.setAlignment(HorizontalAlignment.RIGHT);
		Button reset = new Button(constants.resetTable(), Resources.ICONS.reset());
		reset.addSelectionListener(new SelectionListener<ButtonEvent>() {
			@Override
			public void componentSelected(ButtonEvent ce) {
				MessageBox box = new MessageBox();
				box.setButtons(MessageBox.OKCANCEL);
				box.setIcon(MessageBox.QUESTION);
				box.setTitle(constants.saveChanges());
				box.setMessage(constants.resetTableWarning());
				box.addCallback(new Listener<MessageBoxEvent>() {
					@Override
					public void handleEvent(MessageBoxEvent be) {
						if (be.getButtonClicked().getText() == "Ok") {
							reset();
						}
					}
				});
				box.show();
			}
		});
		toolBar.add(reset);
		cp.setBottomComponent(toolBar);
		cp.setHeight(300);
		innerContainerWest.add(cp, data);
		data = new RowData(1, 400, new Margins(10));
		cp = new ContentPanel(new FitLayout());
		cp.setFrame(true);
		cp.setHeading(constants.visualizationOfDemand());
		cp.setIcon(Resources.ICONS.chart());
		cp.setCollapsible(true);
		cp.add(chart);
		outerContainer.add(cp, data);

		eastLayoutData.setMargins(new Margins(5, 5, 5, 5));
		eastLayoutData.setSize(0.25f);

		innerContainerEast.add(intervallFormPanel, new RowData(1, 1, new Margins(5, 5, 10, 0)));
		innerContainerEast.add(formPanel2, new RowData(1, 1, new Margins(15, 5, 5, 0)));
		return outerContainer;
	}

	/**
	 * Reset.
	 */
	protected void reset() {
		List<Bedarf> bedarfsList = store.getModels();
		store.removeAll();
		for (Bedarf b : bedarfsList) {
			b.setBedarf(0);
		}
		store.add(bedarfsList);
	}

	/**
	 * Initialize bedarfslist.
	 * 
	 * @return the list
	 */
	private List<Bedarf> initializeBedarfslist() {
		List<Bedarf> bedarfsListe = new ArrayList<Bedarf>();
		for (TimeIntervall t : TimeIntervall.getFullIntervalls()) {
			Bedarf b = new Bedarf(t.getStartIntervall(), t.getEndIntervall(), t.getIntervall(), t.getIntIntervall(), 0);
			bedarfsListe.add(b);
		}
		return bedarfsListe;
	}

	/**
	 * Change bedarfslist to intervall.
	 */
	private void changeBedarfslistToIntervall() {
		List<Bedarf> bedarfsListe = store.getModels();
		store.removeAll();
		XAxis xa = new XAxis();
		if (radioHalfHour.getValue()) {
			halfhour = true;
			int i = 0;
			int z = 0;
			for (TimeIntervall t : TimeIntervall.getHalfIntervalls()) {
				store.add(new Bedarf(t.getStartIntervall(), t.getEndIntervall(), t.getIntervall(), t.getIntIntervall(), bedarfsListe.get(i)
						.getBedarf()));
				Label l;
				if (((++z) % 2) != 0) {
					l = new Label(t.getStartIntervall());
				} else {
					l = new Label("");
				}
				l.setColour("#000000");
				xa.addLabels(l);
				model.setXAxis(xa);
				if ((t.getIntIntervall() % 2) == 0) {
					i++;
				}
			}
		} else {
			int i = 0;
			halfhour = false;
			for (TimeIntervall t : TimeIntervall.getFullIntervalls()) {
				double averageDemand = (bedarfsListe.get(i).getBedarf() + bedarfsListe.get(i + 1).getBedarf()) / 2;
				int avgDemand = (int) Math.round(averageDemand);
				store.add(new Bedarf(t.getStartIntervall(), t.getEndIntervall(), t.getIntervall(), t.getIntIntervall(), avgDemand));
				Label l = new Label(t.getStartIntervall());
				l.setColour("#000000");
				xa.addLabels(l);
				model.setXAxis(xa);
				i = i + 2;
			}
		}
	}

	/**
	 * Return bedarf.
	 * 
	 * @return the list
	 */
	public static List<Bedarf> returnBedarf() {
		return store.getModels();
	}

	/**
	 * Sets the bedarf list.
	 * 
	 * @param blist
	 *            the new bedarf list
	 */
	public static void setBedarfList(List<Bedarf> blist) {
		if (blist.size() > 24) {
			radioHalfHour.setValue(true);
			radioFullHour.setValue(false);
		}
		store.removeAll();
		store.add(blist);
		store.commitChanges();
	}
}