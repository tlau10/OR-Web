package com.tagesplanung.client.widgets;

import com.extjs.gxt.ui.client.Style.HorizontalAlignment;
import com.extjs.gxt.ui.client.event.ButtonEvent;
import com.extjs.gxt.ui.client.event.SelectionListener;
import com.extjs.gxt.ui.client.widget.Window;
import com.extjs.gxt.ui.client.widget.button.Button;
import com.extjs.gxt.ui.client.widget.form.FormPanel;
import com.extjs.gxt.ui.client.widget.form.TextField;
import com.extjs.gxt.ui.client.widget.layout.FitData;
import com.extjs.gxt.ui.client.widget.layout.FitLayout;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.tagesplanung.client.PersPlanService;
import com.tagesplanung.client.PersPlanServiceAsync;
import com.tagesplanung.shared.resources.Resources;

// TODO: Auto-generated Javadoc
/**
 * The Class FileDownloadView is a window which pops up as soon the user hits
 * the Save Demand, Save Shift or new Dialog.
 */
public class FileDownloadView extends Window {
	// internationalization with .properties file
	/**
	 * The constants. With this variable we can reach all constant strings in
	 * different languages.
	 */
	private PersPlanConstants constants;

	/**
	 * The panel contains all Control Elements. If the user don't use Firefox
	 * the panel call the FileDownloadServlet
	 */
	private final FormPanel panel;

	/** The data name. In this TextField the User can enter a data name. */
	private TextField<String> dataName;

	/** The save. Call the Button Handler */
	private Button save;

	/** The close. Call the Button Handler */
	private Button close;

	/** The file path contains the String of the directory and the filename */
	private String filePath;

	private String result;

	/**
	 * The file extension is set by the type parameter of the constructor. If
	 * type is demandPlaning --> .dep If type is shiftPlaning --> .shp
	 */
	private String fileExtension;

	public FileDownloadView(String type, String result) {
		this(type);
		this.result = result;
	}

	/**
	 * Instantiates a new file download view.
	 * 
	 * @param type
	 *            is used for the heading of the window and panel also it
	 *            affects the file extension.
	 */
	public FileDownloadView(String type) {
		constants = (PersPlanConstants) GWT.create(PersPlanConstants.class);
		this.setSize(350, 180);
		this.setPlain(true);
		this.setModal(true);
		this.setBlinkModal(true);
		this.setHeading(type);
		this.setLayout(new FitLayout());
		this.setIcon(Resources.ICONS.info());

		panel = new FormPanel();
		panel.setHeading(type + " " + constants.save());
		panel.setFrame(true);
		panel.setEncoding(FormPanel.Encoding.MULTIPART);
		panel.setMethod(FormPanel.Method.POST);
		panel.setButtonAlign(HorizontalAlignment.CENTER);

		dataName = new TextField<String>();
		dataName.setName("DateiName");
		dataName.setFieldLabel(constants.dataName());
		save = new Button(constants.saveUpperCase());
		close = new Button(constants.close());

		ButtonHandler buttonHandler = new ButtonHandler();
		save.addSelectionListener(buttonHandler);
		close.addSelectionListener(buttonHandler);

		panel.add(dataName);
		panel.addButton(save);
		panel.addButton(close);
		this.add(panel, new FitData(4));

		if (type.compareTo(constants.demandPlaning()) == 0) {
			saveDemandData("SaveDemand");
			fileExtension = ".dep";
		}
		if (type.compareTo(constants.shiftPlaning()) == 0) {
			saveShiftData("SaveShifts");
			fileExtension = ".shp";
		}

		/* change-begin by fafilipp */
		if (type.equals("txt")) {
			// saveShiftData("SaveXLS");
			fileExtension = ".txt";
		}
		/* change-end by fafilipp */

		if (type.equals("xls")) {
			// saveShiftData("SaveXLS");
			fileExtension = ".xls";
		}

		if (type.equals("csv")) {
			// saveShiftData("SaveCSV");
			fileExtension = ".csv";
		}

		/* change-begin by fafilipp */
		// this.addWindowListener(new WindowListener() {
		// // the save file on the server will deleted before Window hide.
		// @Override
		// public void windowHide(WindowEvent we) {
		// if (fileExtension.equals(".dep") || fileExtension.equals(".shp")) {
		// deleteFile(filePath);
		// }
		// }
		// });
		/* change-end by fafilipp */
	}

	/*
	 * (non-Javadoc) the save file on the server will deleted if the user close
	 * the browser or navigate to another site
	 */
	@Override
	protected void onUnload() {
		/* change-begin by fafilipp */
		// deleteFile(filePath);
		/* change-end by fafilipp */
	}

	/**
	 * Save demand data call the saveDemandData method on the server side. If
	 * the method of the server side is successful it set the file path of the
	 * save data file.
	 * 
	 * @param message
	 *            is not used
	 */
	public void saveDemandData(String message) {
		PersPlanServiceAsync persPlanService = (PersPlanServiceAsync) GWT.create(PersPlanService.class);
		AsyncCallback<String> callback = new AsyncCallback<String>() {
			@Override
			public void onSuccess(String result) {
				filePath = result;
			}

			@Override
			public void onFailure(Throwable caught) {
				com.google.gwt.user.client.Window.alert(caught.getMessage());
			}
		};
		persPlanService.saveDemandData(BedarfsplanView.returnBedarf(), callback);
	}

	/**
	 * Save shift data call the saveShiftData method on the server side. If the
	 * method of the server side is successful it set the file path of the save
	 * data file.
	 * 
	 * @param message
	 *            is not used
	 */
	public void saveShiftData(String message) {
		if (ShiftlistView.returnShifts() == null) {
			com.google.gwt.user.client.Window.alert(constants.errorEmptyShift());
		}
		PersPlanServiceAsync persPlanService = (PersPlanServiceAsync) GWT.create(PersPlanService.class);
		AsyncCallback<String> callback = new AsyncCallback<String>() {
			@Override
			public void onSuccess(String result) {
				filePath = result;
			}

			@Override
			public void onFailure(Throwable caught) {
				com.google.gwt.user.client.Window.alert(caught.getMessage());
			}
		};
		persPlanService.saveShiftData(ShiftlistView.returnShifts(), callback);
	}

	/**
	 * Delete file call the deleteFile method on the server side.
	 * 
	 * @param message
	 *            is not used
	 */
	public void deleteFile(String message) {
		PersPlanServiceAsync persPlanService = (PersPlanServiceAsync) GWT.create(PersPlanService.class);
		AsyncCallback<String> callback = new AsyncCallback<String>() {
			@Override
			public void onSuccess(String result) {
				// doing nothing...
			}

			@Override
			public void onFailure(Throwable caught) {
				com.google.gwt.user.client.Window.alert(caught.getMessage());
			}
		};
		persPlanService.deleteFile(message, callback);
	}

	/**
	 * The method isValid check the value of the text field dataName. If there
	 * forbidden signs the result is false.
	 * 
	 * @return true, if is valid
	 */
	private boolean isValid() {
		if (dataName.getValue() == null) {
			return false;
		} else {
			String text = dataName.getValue();
			if (text.contains(".")) {
				return false;
			}
			if (text.contains("/")) {
				return false;
			}
			if (text.contains("\\")) {
				return false;
			}
			if (text.contains(":")) {
				return false;
			}
			if (text.contains("*")) {
				return false;
			}
			if (text.contains("?")) {
				return false;
			}
			if (text.contains("<")) {
				return false;
			}
			if (text.contains(">")) {
				return false;
			}
			if (text.contains(" ")) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Gets the user agent is a native method and return a String of the User
	 * Agent.
	 * 
	 * @return the user agent
	 */
	public static native String getUserAgent() /*-{
		return navigator.userAgent.toLowerCase();
	}-*/;

	/**
	 * The Class ButtonHandler is the SelectionListener for the buttons save and
	 * close.
	 */
	private class ButtonHandler extends SelectionListener<ButtonEvent> {

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * com.extjs.gxt.ui.client.event.SelectionListener#componentSelected
		 * (com.extjs.gxt.ui.client.event.ComponentEvent)
		 */
		@Override
		public void componentSelected(ButtonEvent ce) {
			Button button = ce.getButton();
			if (button.getText().compareTo(constants.saveUpperCase()) == 0) {
				if (isValid()) {
					String userAgent = getUserAgent();
					// if the user use firefox the FileDownloadServlet is call
					// via Window.open
					if (userAgent.contains("firefox")) {
						// two parameter are set: the filepath and the filename
						if (fileExtension.equals(".xls")) {
							com.google.gwt.user.client.Window.open(GWT.getHostPageBaseURL()
									+ "tagesplanung/excelDownloadServlet?format=xls&file=" + result + "&fileName=" + dataName.getValue(),
									"filedownload", "");
						} else if (fileExtension.equals(".csv")) {
							com.google.gwt.user.client.Window.open(GWT.getHostPageBaseURL()
									+ "tagesplanung/excelDownloadServlet?format=csv&file=" + result + "&fileName=" + dataName.getValue(),
									"filedownload", "");
							/* change-begin by fafilipp */
						} else if (fileExtension.equals(".txt")) {
							com.google.gwt.user.client.Window.open(GWT.getHostPageBaseURL()
									+ "tagesplanung/excelDownloadServlet?format=txt&file=" + result + "&fileName=" + dataName.getValue(),
									"filedownload", "");
							/* change-end by fafilipp */
						} else {
							com.google.gwt.user.client.Window.open(GWT.getModuleBaseURL() + "download?filePath=" + filePath + "&fileName="
									+ dataName.getValue() + fileExtension, "filedownload", "");
						}
					} else {
						// if the user use not firefox the FileDownloadServlet
						// is call via panel.submit
						if (fileExtension.equals(".xls")) {
							panel.setAction(GWT.getHostPageBaseURL() + "tagesplanung/excelDownloadServlet?format=xls&file=" + result
									+ "&fileName=" + dataName.getValue());
							panel.submit();
						} else if (fileExtension.equals(".csv")) {
							panel.setAction(GWT.getHostPageBaseURL() + "tagesplanung/excelDownloadServlet?format=csv&file=" + result
									+ "&fileName=" + dataName.getValue());
							panel.submit();
							/* change-begin by fafilipp */
						} else if (fileExtension.equals(".txt")) {
							panel.setAction(GWT.getHostPageBaseURL() + "tagesplanung/excelDownloadServlet?format=txt&file=" + result
									+ "&fileName=" + dataName.getValue());
							panel.submit();
							/* change-end by fafilipp */
						} else {
							panel.setAction(GWT.getModuleBaseURL() + "download?filePath=" + filePath + "&fileName=" + dataName.getValue()
									+ fileExtension);
							panel.submit();
						}
					}
				} else {
					com.google.gwt.user.client.Window.alert(constants.errorWrongSigns());
				}
			}
			if (button.getText().compareTo(constants.close()) == 0) {
				hide();
			}
		}
	}
}