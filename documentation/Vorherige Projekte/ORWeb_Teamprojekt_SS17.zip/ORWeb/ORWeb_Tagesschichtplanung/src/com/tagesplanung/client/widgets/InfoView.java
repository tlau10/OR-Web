package com.tagesplanung.client.widgets;

import com.extjs.gxt.ui.client.widget.ContentPanel;
import com.extjs.gxt.ui.client.widget.Label;
import com.extjs.gxt.ui.client.widget.Window;
import com.extjs.gxt.ui.client.widget.layout.FitData;
import com.extjs.gxt.ui.client.widget.layout.FitLayout;
import com.google.gwt.core.client.GWT;
import com.tagesplanung.shared.resources.Resources;

/**
 * The Class InfoView. It's a window which pops up as soon the user hits the
 * Info-Button in the menubar.
 *
 * @author Anton Dubs
 */
public class InfoView extends Window {
	
	// internationalization with .properties file
	/** The constants. With this variable we can reach all constant strings in different languages. */
	private PersPlanConstants constants = (PersPlanConstants) GWT.create(PersPlanConstants.class);

	/**
	 * Instantiates a new info view.
	 * Constructor, which creates the window.
	 */
	public InfoView(){
		this.setSize(300, 300);  
		this.setPlain(true);  
		this.setModal(true);  
		this.setBlinkModal(true);  
		this.setHeading(constants.about());  
		this.setLayout(new FitLayout());  	
		this.setIcon(Resources.ICONS.info());
		ContentPanel panel = new ContentPanel();  
		panel.setBorders(false);
		panel.setHeading("Teamprojekt Sommersemester 2010");
	// Text of the info window
		Label l = new Label("<html>" +
								"<br /><h2><b>"+constants.infoHeadline()+"</b></h2><br />" +
								"<p>&copy; 2010 by <br /><br />" +
								"Denny Banholzer,<br />" +
								"Anton Dubs,<br />" +
								"Anton Ebel,<br />" +
								"Steffen Kollosche,<br/>" +
								"Aleksandar Shapkarov,<br/>" +
								"Ellen Wieland<br /><br />" +
								"</p>" +
								"<p><b>HTWG Konstanz</b></p><br />" +
							"</html>");
		l.setStyleAttribute("font-size", "14");
		l.setStyleAttribute("text-align", "center");
		panel.add(l);      
		this.add(panel, new FitData(4));
	}
}