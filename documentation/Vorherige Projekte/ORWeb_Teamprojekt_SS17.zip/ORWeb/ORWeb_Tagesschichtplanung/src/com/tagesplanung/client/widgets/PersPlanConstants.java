package com.tagesplanung.client.widgets;

import com.google.gwt.i18n.client.Constants;

/**
 * Interface to enable internationalization with .properties files in GWT.
 * 
 */
public interface PersPlanConstants extends Constants {

	// GENERAL
	String from();

	String to();

	String back();

	String forth();

	String newItem();

	String apply();

	String helpTopics();

	String help();

	String languages();

	String german();

	String english();

	String file();

	String about();

	String dots();

	String infoHeadline();

	String interval();

	String timeInterval();

	String hour();

	String halfanhour();

	String workingTime();

	String persons();

	String number();

	String numberOfPersons();

	String maxPersons();

	String preference();

	String pleaseChoose();

	String chooseGraphics();

	// SHIFT
	String shift();

	String shifts();

	String shiftList();

	String shiftPlaning();

	String shiftNumber();

	String shiftStart();

	String shiftEnd();

	String addShift();

	String deleteShift();

	String visualizationOfShifts();

	String graphicRepresentationOfShifts();

	// DEMAND
	String demand();

	String demandList();

	String demandPlaning();

	String visualizationOfDemand();

	String graphicRepresentationOfDemand();

	String planningAssistant();

	String resetTable();

	String resetTableWarning();

	String showOverStaffing();

	// BREAK
	String breaks();

	String breakStart();

	String breakEnd();

	String breakArea();

	String showBreaks();

	// SOLVER
	String solve();

	String solver();

	String xa();

	String result();

	String exportAs();

	String lpModel();

	// SAVE & DELETE
	String save();

	String saveAs();

	String saveFile();

	String saveDemandList();

	String saveShiftList();

	String saveChanges();

	String saveWarning();

	String delete();

	String dataName();

	String saveUpperCase();

	String successfullyCreated();

	// OPEN & CLOSE
	String open();

	String openUpperCase();

	String openFile();

	String fileToOpen();

	String openDemandList();

	String openShiftList();

	String close();

	// ERROR MESSAGES
	String error();

	String errorInShiftNumber();

	String checkNumberOfPersons();

	String integrity();

	String notNegative();

	String not24Hours();

	String notBreakStartEqualsBreakEnd();

	String notOverMidnight();

	String breakInWorkingTime();

	String errorOpeningFile();

	String errorWrongType();

	String errorWrongSigns();

	String errorEmptyShift();

	String tooManyShifts();

	String noBreakInNightshift();

	String unsupportedMediaType();

	String internalServerError();

	String errorNoExportFormat();

	String errorNoExportFile();

	String wasRoundedWarning();

	String keinBedarfEingegben();

	String keineSchichtmuster();
	
	String fehlerhaftesSchichtmuster();

	String bildLegede();
}