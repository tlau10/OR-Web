package com.tagesplanung.client.widgets;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.extjs.gxt.charts.client.Chart;
import com.extjs.gxt.charts.client.model.ChartModel;
import com.extjs.gxt.charts.client.model.axis.Label;
import com.extjs.gxt.charts.client.model.axis.XAxis;
import com.extjs.gxt.charts.client.model.axis.YAxis;
import com.extjs.gxt.charts.client.model.charts.HorizontalStackedBarChart;
import com.extjs.gxt.ui.client.Style.HorizontalAlignment;
import com.extjs.gxt.ui.client.data.ModelData;
import com.extjs.gxt.ui.client.event.ButtonEvent;
import com.extjs.gxt.ui.client.event.Events;
import com.extjs.gxt.ui.client.event.GridEvent;
import com.extjs.gxt.ui.client.event.Listener;
import com.extjs.gxt.ui.client.event.SelectionListener;
import com.extjs.gxt.ui.client.store.ListStore;
import com.extjs.gxt.ui.client.widget.ContentPanel;
import com.extjs.gxt.ui.client.widget.LayoutContainer;
import com.extjs.gxt.ui.client.widget.MessageBox;
import com.extjs.gxt.ui.client.widget.button.Button;
import com.extjs.gxt.ui.client.widget.form.CheckBox;
import com.extjs.gxt.ui.client.widget.form.ComboBox.TriggerAction;
import com.extjs.gxt.ui.client.widget.form.SimpleComboBox;
import com.extjs.gxt.ui.client.widget.form.TextField;
import com.extjs.gxt.ui.client.widget.grid.CellEditor;
import com.extjs.gxt.ui.client.widget.grid.CheckColumnConfig;
import com.extjs.gxt.ui.client.widget.grid.ColumnConfig;
import com.extjs.gxt.ui.client.widget.grid.ColumnModel;
import com.extjs.gxt.ui.client.widget.grid.EditorGrid;
import com.extjs.gxt.ui.client.widget.grid.HeaderGroupConfig;
import com.extjs.gxt.ui.client.widget.layout.FitLayout;
import com.extjs.gxt.ui.client.widget.layout.RowLayout;
import com.extjs.gxt.ui.client.widget.toolbar.ToolBar;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.tagesplanung.client.PersPlanService;
import com.tagesplanung.client.PersPlanServiceAsync;
import com.tagesplanung.shared.ShiftBaseModel;
import com.tagesplanung.shared.TimeIntervall;
import com.tagesplanung.shared.resources.Resources;

/**
 * The Class ShiftlistView. This class represents the Shiftlist tab of the
 * application.
 * 
 * @author Anton Dubs
 */
public class ShiftlistView {

	// Begin of Change by fafilipp
	/**
	 * More then MAX_SHIFTS_ALLOWED are not allowed, because of XA restrictions
	 * limit
	 */
	private final int MAX_SHIFTS_ALLOWED = 15;
	// End of Change

	/**
	 * The Constant store. All the shifts will be saved in this store. It's
	 * linked to the grid.
	 */
	final static ListStore<ShiftBaseModel> store = new ListStore<ShiftBaseModel>();

	/** The table rows. It counts the number of shifts the user had created */
	private static int tableRows = 1;

	/** The grid. The grid of the tab. */
	private EditorGrid<ShiftBaseModel> grid = null;

	/** The container. */
	private LayoutContainer container = new LayoutContainer();

	/** The slg. Inner class, represents the grid. */
	private ShiftlistGrid slg = new ShiftlistGrid();

	/** The slc. Inner class, it represents the chart in the tab. */
	private ShiftlistChart slc = new ShiftlistChart();

	// Begin of Change by fafilipp
	/**
	 * The Night Break Start String Value (Default 22:00, is getted by Server
	 * call)
	 */
	private String nightBreakStart = "22:00";

	/**
	 * The Night Break End String Value (Default 06:00, is getted by Server
	 * call)
	 */
	private String nightBreakEnd = "06:00";
	// End of Change

	// internationalization with .properties file
	/** The constants. Needed for internationalization with property files */
	private PersPlanConstants constants = (PersPlanConstants) GWT.create(PersPlanConstants.class);

	/**
	 * The Class ShiftlistGrid. Private inner class. It contains the grid.
	 */
	private class ShiftlistGrid {

		/**
		 * Sets the combo box values for the shift start/end and
		 * shift-break-start/-end intervall
		 * 
		 * @param combo
		 *            the combobox which gets the text
		 */
		private void setComboBoxValues(final SimpleComboBox<String> combo) {
			// Writing 00:00 - 09:30 into the combo box
			for (int i = 0; i < 10; i++) {
				combo.add("0" + i + ":00");
				combo.add("0" + i + ":30");
			}
			// Writing 10:00 - 23:30 into the combo box
			for (int i = 10; i < 24; i++) {
				combo.add(i + ":00");
				combo.add(i + ":30");
			}
		}

		/**
		 * Creates and returns the CellEditor
		 * 
		 * @return the cell editor
		 */
		private CellEditor getCellEditor() {
			final SimpleComboBox<String> combo = new SimpleComboBox<String>();
			combo.setForceSelection(true);
			combo.setTriggerAction(TriggerAction.ALL);
			this.setComboBoxValues(combo);
			CellEditor editor = new CellEditor(combo) {
				@Override
				public Object preProcessValue(Object value) {
					if (value == null) {
						return value;
					}
					return combo.findModel(value.toString());
				}

				@Override
				public Object postProcessValue(Object value) {
					if (value == null) {
						return value;
					}
					return ((ModelData) value).get("value");
				}
			};
			return editor;
		}

		/**
		 * Creates and returns the (shiftlist) grid on a ContentPanel.
		 * 
		 * @return the shiftlist grid
		 */
		public ContentPanel getShiftlistGrid() {
			// New panel with fitlayout
			ContentPanel gridPane = new ContentPanel(new FitLayout());
			gridPane.setIcon(Resources.ICONS.table());
			gridPane.setCollapsible(true);
			gridPane.setSize(980, 300);
			// Setting margin values to 10
			gridPane.setStyleAttribute("margin", "10");
			gridPane.setFrame(true);
			List<ColumnConfig> configs = new ArrayList<ColumnConfig>();
			// Creating the CellEditors (Combo boxes)
			CellEditor start_editor = getCellEditor();
			CellEditor end_editor = getCellEditor();
			CellEditor start_pause_editor = getCellEditor();
			CellEditor end_pause_editor = getCellEditor();

			TextField<Integer> text = new TextField<Integer>();
			text.setAllowBlank(false);

			final SimpleComboBox<String> combo_praef = new SimpleComboBox<String>();
			combo_praef.setForceSelection(true);
			combo_praef.setTriggerAction(TriggerAction.ALL);
			for (int i = -5; i <= 5; i++) {
				combo_praef.add(String.valueOf(i));
			}
			CellEditor praef_editor = new CellEditor(combo_praef) {
				@Override
				public Object preProcessValue(Object value) {
					if (value == null) {
						return value;
					}
					return combo_praef.findModel(value.toString());
				}

				@Override
				public Object postProcessValue(Object value) {
					if (value == null) {
						return value;
					}
					return ((ModelData) value).get("value");
				}
			};
			// Creating the columns of the grid
			ColumnConfig column = new ColumnConfig("nummer", constants.number(), 50);
			column.setMenuDisabled(true);
			configs.add(column);
			column = new ColumnConfig("start", constants.shiftStart(), 120);
			column.setSortable(false);
			column.setMenuDisabled(true);
			column.setEditor(start_editor);
			configs.add(column);
			column = new ColumnConfig("end", constants.shiftEnd(), 120);
			column.setSortable(false);
			column.setMenuDisabled(true);
			column.setEditor(end_editor);
			configs.add(column);
			column = new ColumnConfig("start_pause", constants.breakStart(), 120);
			column.setSortable(false);
			column.setMenuDisabled(true);
			column.setEditor(start_pause_editor);
			configs.add(column);
			column = new ColumnConfig("end_pause", constants.breakEnd(), 120);
			column.setSortable(false);
			column.setMenuDisabled(true);
			column.setEditor(end_pause_editor);
			configs.add(column);
			column = new ColumnConfig("bedarf", constants.maxPersons(), 120);
			column.setMenuDisabled(true);
			column.setEditor(new CellEditor(text));
			configs.add(column);
			column = new ColumnConfig("praef", constants.preference(), 120);
			column.setSortable(false);
			column.setMenuDisabled(true);
			column.setEditor(praef_editor);
			configs.add(column);

			CheckColumnConfig checkColumn = new CheckColumnConfig("delete", constants.delete(), 55);
			CellEditor checkBoxEditor = new CellEditor(new CheckBox());
			checkColumn.setSortable(false);
			checkColumn.setMenuDisabled(true);
			checkColumn.setEditor(checkBoxEditor);
			configs.add(checkColumn);

			ColumnModel cm = new ColumnModel(configs);
			cm.addHeaderGroup(0, 1, new HeaderGroupConfig(constants.workingTime(), 1, 2));
			cm.addHeaderGroup(0, 2, new HeaderGroupConfig(constants.breakArea(), 1, 3));

			List<ShiftBaseModel> shiftlist = new ArrayList<ShiftBaseModel>();
			store.setMonitorChanges(true);
			// Adding the first (empty) shift to the grid
			shiftlist.add(new ShiftBaseModel(1, "00:00", "00:00", "00:00", "00:00", "0", "0", 0, 0, 0, 0, 0, 1.0, false));
			store.add(shiftlist);
			// Creating the grid and putting all together
			grid = new EditorGrid<ShiftBaseModel>(store, cm);
			grid.setAutoExpandColumn("praef");
			grid.setEnableColumnResize(false);
			grid.setBorders(true);
			grid.getView().setForceFit(true);
			grid.getView().setShowDirtyCells(false);
			// Adding a listener
			grid.addListener(Events.AfterEdit, new Listener<GridEvent<ShiftBaseModel>>() {
				@Override
				public void handleEvent(GridEvent<ShiftBaseModel> be) {
					store.commitChanges();
				}
			});
			gridPane.setHeading(constants.shiftList());
			// Creating a toolbar which will contain the buttons
			ToolBar toolBar = new ToolBar();
			toolBar.setAlignment(HorizontalAlignment.RIGHT);
			Button apply = new Button(constants.apply(), Resources.ICONS.apply());
			Button addRow = new Button(constants.addShift(), Resources.ICONS.addrow());
			Button deleteRow = new Button(constants.deleteShift(), Resources.ICONS.delete());
			// Defining what is to do as soon as the apply button gets clicked
			apply.addSelectionListener(new SelectionListener<ButtonEvent>() {
				@Override
				public void componentSelected(ButtonEvent ce) {
					// if the user typped in valid values
					if (slc.validate()) {
						// commit the changes and update the chart
						store.commitChanges();
						slc.updateChart();
					}
					// else do nothing.
				}
			});
			// Defining what is to do as soon as the addRow button gets clicked
			addRow.addSelectionListener(new SelectionListener<ButtonEvent>() {
				@Override
				public void componentSelected(ButtonEvent ce) {
					// Begin of Change by fafilipp
					if ((tableRows + 1) <= MAX_SHIFTS_ALLOWED) {
						// End of Change
						// Adding a row, if there are not twenty shifts yet
						// created
						grid.getStore().add(
								new ShiftBaseModel(++tableRows, "00:00", "00:00", "00:00", "00:00", "0", "0", 0, 0, 0, 0, 0, 1.0, false));
						if (slc.validate()) {
							// if every thing still valid commit + update chart
							store.commitChanges();
							slc.updateChart();
						}
					} else {
						// Error
						MessageBox.alert(constants.error(), constants.tooManyShifts(), null);
					}
				}
			});
			// Defining what is to do as soon as the delete button gets clicked
			deleteRow.addSelectionListener(new SelectionListener<ButtonEvent>() {
				@Override
				public void componentSelected(ButtonEvent ce) {
					slc.deleteSelectedRows();
					if (slc.validate()) {
						store.commitChanges();
						slc.updateChart();
					}
				}
			});
			toolBar.add(apply);
			toolBar.add(addRow);
			toolBar.add(deleteRow);
			gridPane.add(grid);
			gridPane.setBottomComponent(toolBar);
			// returning the complete pane
			return gridPane;
		}
	}

	/**
	 * The Class ShiftlistChart. This class represents the cart, it creates the
	 * contenpanel.
	 */
	protected class ShiftlistChart {

		/** The chart pane. */
		ContentPanel chartPane = null;

		/** The chart. */
		Chart chart = null;

		/** The bar chart. */
		HorizontalStackedBarChart barChart = null;

		/** The x axis. */
		XAxis xAxis = null;

		/** The y axis. */
		YAxis yAxis = null;

		/** The data. */
		List<HorizontalStackedBarChart.StackValue> data = null;

		/** The data array. */
		HorizontalStackedBarChart.StackValue[] dataArray = null;

		/** The model. */
		ChartModel model = null;

		/**
		 * Gets the shiftlist chart.
		 * 
		 * @return the (shiftlist) chart
		 */
		public ContentPanel getShiftlistChart() {
			// creating a new content panel
			chartPane = new ContentPanel(new FitLayout());
			chartPane.setFrame(true);
			chartPane.setIcon(Resources.ICONS.chart());
			chartPane.setCollapsible(true);
			chartPane.setHeading(constants.visualizationOfShifts());
			chartPane.setSize(980, 300);
			chartPane.setStyleAttribute("margin", "10");
			// defining where the compiler can find the flash file needed to
			// display the chart
			String url = "resources/chart/open-flash-chart.swf";
			chart = new Chart(url);

			barChart = new HorizontalStackedBarChart();
			data = new ArrayList<HorizontalStackedBarChart.StackValue>();
			data.add(new HorizontalStackedBarChart.StackValue(0, 0, "#ff0000", constants.shift() + " " + constants.interval()));
			data.add(new HorizontalStackedBarChart.StackValue(0, 0, "#1E90ff", constants.breaks() + " " + constants.interval()));
			dataArray = data.toArray(new HorizontalStackedBarChart.StackValue[0]);
			barChart.addStack(dataArray);
			barChart.setTooltip("");
			// Creating the x axis
			xAxis = new XAxis();
			xAxis.setMax(24);
			for (TimeIntervall t : TimeIntervall.getFullIntervalls()) {
				Label l = new Label(t.getStartIntervall());
				xAxis.addLabels(l);
			}
			xAxis.addLabels("24:00");
			// Creating the y axis
			yAxis = new YAxis();
			yAxis.setMin(0);
			yAxis.setMax(tableRows);
			yAxis.setSteps(1);

			model = new ChartModel(constants.graphicRepresentationOfShifts(),
					"font-weight: bold; font-size: 14px; font-family: Verdana; text-align: center;");
			model.setXAxis(xAxis);
			model.setYAxis(yAxis);
			model.setBackgroundColour("#fefefe");
			model.addChartConfig(barChart);

			chart.setChartModel(model);
			chart.setToolTip("");
			chartPane.add(chart);
			chartPane.setToolTip("");
			return chartPane;
		}

		/**
		 * Validate. This function validates the entered data from the grid
		 * 
		 * @return true, if everything's valid
		 */
		protected boolean validate() {
			String error_msg = "";

			for (int i = 0; i < store.getCount(); i++) {
				ShiftBaseModel sbm = store.getAt(i);
				// getting the double values of the time (e.g. 23:00 = 23)
				double start = sbm.convertToDouble(sbm.getStart());
				double end = sbm.convertToDouble(sbm.getEnd());
				double start_pause = sbm.convertToDouble(sbm.getStartPause());
				double end_pause = sbm.convertToDouble(sbm.getEndPause());
				double nachtschichtStart = sbm.convertToDouble(nightBreakStart);
				double nachtschichtEnde = sbm.convertToDouble(nightBreakEnd);

				int shiftnumber = sbm.getNummer();
				try {
					// is the demand an int value and bigger 0?
					error_msg = constants.checkNumberOfPersons() + shiftnumber + constants.integrity();
					int demand = Integer.parseInt(sbm.getBedarf());
					if (demand < 0) {
						error_msg = constants.checkNumberOfPersons() + shiftnumber + constants.notNegative();
						throw new NumberFormatException();
					}
				} catch (NumberFormatException ex) {
					sbm.setBedarfInt(0);
					MessageBox.alert(constants.error(), error_msg, null);
					return false;
				}

				// No 24 hour shifts allowed
				if (start == end && start != 0) {
					error_msg = constants.errorInShiftNumber() + shiftnumber + constants.not24Hours();
					MessageBox.alert(constants.error(), error_msg, null);
					return false;
				}

				/**
				 * Begin of change (jaglaubi)
				 */
				// keine Pausen in der Nachtschicht
				if (pauseIstInNachtschicht(nachtschichtStart, nachtschichtEnde, start_pause, end_pause, start, end)) {
					error_msg = constants.errorInShiftNumber() + shiftnumber + ": " + constants.noBreakInNightshift() + " (Intervall "
							+ nightBreakStart + " - " + nightBreakEnd + ")";
					MessageBox.alert(constants.error(), error_msg, null);
					return false;
				}
				/**
				 * End of change
				 */

				// no break entered
				if (start_pause == end_pause && start_pause == 0) {
					continue;
				}
				// break start = break end error
				if (start_pause == end_pause && start_pause != 0) {
					error_msg = constants.errorInShiftNumber() + shiftnumber + constants.notBreakStartEqualsBreakEnd();
					MessageBox.alert(constants.error(), error_msg, null);
					return false;
				}
				// break over midnight error
				if (start_pause > end_pause && end_pause != 0) {
					error_msg = constants.errorInShiftNumber() + shiftnumber + constants.notOverMidnight();
					MessageBox.alert(constants.error(), error_msg, null);
					return false;
				}
				if (start < end) {
					// every thing is fine
					if (start_pause >= start && start_pause < end && end_pause > start_pause && end_pause <= end) {
						continue;
					}
					// break not in shift intervall
					else {
						error_msg = constants.errorInShiftNumber() + shiftnumber + constants.breakInWorkingTime();
						MessageBox.alert(constants.error(), error_msg, null);
						return false;
					}
				}
				if (start > end) {
					// every thing is fine
					if (start_pause >= start && start_pause < end_pause && end_pause <= 24) {
						continue;
					}
					if (start_pause >= start && start_pause > end_pause && end_pause <= end) {
						continue;
					}
					if (start_pause >= start && start_pause > end && end_pause == 0) {
						continue;
					}
					if (start_pause < end && end_pause <= end && start_pause < end_pause) {
						continue;
					}
					// not fine
					else {
						error_msg = constants.errorInShiftNumber() + shiftnumber + constants.breakInWorkingTime();
						MessageBox.alert(constants.error(), error_msg, null);
						return false;
					}
				}
			}
			return true;
		}

		/**
		 * @param start_n
		 *            Beginn des festgelegten Nachtschichtintervalls
		 * @param ende_n
		 *            Ende des festgelegten Nachtschichtintervalls
		 * @param start_p
		 *            Beginn der eingegebenen Pause
		 * @param ende_p
		 *            Ende der eingegebenen Pause
		 * @param start
		 *            Beginn der eingegebenen Schicht (nur zum überprüfen ob es
		 *            ein Initialwert ist)
		 * @param ende
		 *            Ende der eingegenenen Schicht (nur zum überprüfen ob es
		 *            ein Initialwert ist)
		 */
		// prüft, ob sich eine Pause (Intervall start_p-ende_p) in
		// einer Nachtschicht (Intervall start_n - ende_n) befindet
		private boolean pauseIstInNachtschicht(double start_n, double ende_n, double start_p, double ende_p, double start, double ende) {

			// sollten Start und Ende der Pause 00 Uhr sein nicht abbrechen
			// lassen
			if ((start_p == 0.0) && (ende_p == 0.0)) {
				return false;
			}

			// beim Hinzufügen neuer Schichten (== alles 0.0) nicht abbrechen
			// lassen
			if ((start == 0.0) && (ende == 0.0) && (start_p == 0.0 && (ende_p == 0.0))) {
				return false;
			}

			if (ende_n <= start_n) {
				ende_n += 24;
			}

			// start_n < start_p < ende_n || start_n < start_p + 24 < ende_n
			if ((start_n < start_p && start_p < ende_n) || (start_n < (start_p + 24) && (start_p + 24) < ende_n)) {
				return true;
			}

			// start_n < ende_p < ende_n || start_n < ende_p + 24 < ende_n
			if ((start_n < ende_p && ende_p < ende_n) || (start_n < (ende_p + 24) && (ende_p + 24) < ende_n)) {
				return true;
			}

			// if(ende_p <= start_p) ende_p += 24
			if (ende_p <= start_p) {
				ende_p += 24;
			}

			// start_p < start_n < ende_n < ende_p || start_p < start_n + 24 <
			// ende_n + 24 < ende_p
			if (start_p < start_n && start_n < ende_n && ende_n < ende_p) {
				return true;
			}

			if (start_p < (start_n + 24) && (start_n + 24) < (ende_n + 24) && (ende_n + 24) < ende_p) {
				return true;
			}

			return false;
		}

		/**
		 * This function updates the chart. it redraws it.
		 */
		protected void updateChart() {
			barChart = new HorizontalStackedBarChart();
			int limit = tableRows;

			// Begin of Change by fafilipp
			// setting the limit of the shifts beeing displayed in the chart to
			// 20.
			if (limit > MAX_SHIFTS_ALLOWED) {
				limit = MAX_SHIFTS_ALLOWED;
			}
			// End of Change

			yAxis.setMax(limit);
			data = null;

			// drawing the chart
			for (int i = limit - 1; i >= 0; i--) {
				data = new ArrayList<HorizontalStackedBarChart.StackValue>();
				ShiftBaseModel sbm = store.getAt(i);
				sbm.setIntervalls(sbm.getStart(), sbm.getEnd(), sbm.getStartPause(), sbm.getEndPause());
				sbm.setPraefInteger(sbm.getPraef());
				double start = sbm.convertToDouble(sbm.getStart());
				double end = sbm.convertToDouble(sbm.getEnd());
				double start_pause = sbm.convertToDouble(sbm.getStartPause());
				double end_pause = sbm.convertToDouble(sbm.getEndPause());
				if (start < end) {
					if (start_pause != end_pause) {
						data.add(new HorizontalStackedBarChart.StackValue(start, start_pause, "#ff0000", constants.shift() + " "
								+ constants.interval()));
						data.add(new HorizontalStackedBarChart.StackValue(start_pause, end_pause, "#1E90ff", constants.breaks() + " "
								+ constants.interval()));
						data.add(new HorizontalStackedBarChart.StackValue(end_pause, end, "#ff0000", ""));
					} else {
						data.add(new HorizontalStackedBarChart.StackValue(start, end, "#ff0000", constants.shift() + " "
								+ constants.interval()));
					}
				}
				if (start > end) {
					if (start_pause == 0) {
						if (end_pause != 0) {
							data.add(new HorizontalStackedBarChart.StackValue(start_pause, end_pause, "#1E90ff", constants.breaks() + " "
									+ constants.interval()));
							data.add(new HorizontalStackedBarChart.StackValue(end_pause, end, "#ff0000", constants.shift() + " "
									+ constants.interval()));
							data.add(new HorizontalStackedBarChart.StackValue(start, 24, "#ff0000", ""));
						} else {
							data.add(new HorizontalStackedBarChart.StackValue(0, end, "#ff0000", constants.shift() + " "
									+ constants.interval()));
							data.add(new HorizontalStackedBarChart.StackValue(start, 24, "#ff0000", ""));
						}
					} else {
						if (start_pause == end_pause) {
							data.add(new HorizontalStackedBarChart.StackValue(0, end, "#ff0000", constants.shift() + " "
									+ constants.interval()));
							data.add(new HorizontalStackedBarChart.StackValue(start, 24, "#ff0000", ""));
						}
						if (start_pause < 24 && end_pause > 0 && start_pause > end_pause) {
							data.add(new HorizontalStackedBarChart.StackValue(0, end_pause, "#1E90ff", constants.breaks() + " "
									+ constants.interval()));
							data.add(new HorizontalStackedBarChart.StackValue(end_pause, end, "#ff0000", constants.shift() + " "
									+ constants.interval()));
							data.add(new HorizontalStackedBarChart.StackValue(start, start_pause, "#ff0000", ""));
							data.add(new HorizontalStackedBarChart.StackValue(start_pause, 24, "#1E90ff", ""));
						}
						if (start_pause < 24 && end_pause <= 24 && start_pause < end_pause && start_pause >= start) {
							data.add(new HorizontalStackedBarChart.StackValue(0, end, "#ff0000", constants.shift() + " "
									+ constants.interval()));
							data.add(new HorizontalStackedBarChart.StackValue(start, start_pause, "#ff0000", ""));
							data.add(new HorizontalStackedBarChart.StackValue(start_pause, end_pause, "#1E90ff", constants.breaks() + " "
									+ constants.interval()));
							data.add(new HorizontalStackedBarChart.StackValue(end_pause, 24, "#ff0000", ""));
						}
						if (start_pause < start && end_pause < start && start_pause != 0) {
							data.add(new HorizontalStackedBarChart.StackValue(0, start_pause, "#ff0000", constants.shift() + " "
									+ constants.interval()));
							data.add(new HorizontalStackedBarChart.StackValue(start_pause, end_pause, "#1E90ff", constants.breaks() + " "
									+ constants.interval()));
							data.add(new HorizontalStackedBarChart.StackValue(end_pause, end, "#ff0000", ""));
							data.add(new HorizontalStackedBarChart.StackValue(start, 24, "#ff0000", ""));
						}
						if (end_pause == 0) {
							data.add(new HorizontalStackedBarChart.StackValue(0, end, "#ff0000", constants.shift() + " "
									+ constants.interval()));
							data.add(new HorizontalStackedBarChart.StackValue(start, start_pause, "#ff0000", ""));
							data.add(new HorizontalStackedBarChart.StackValue(start_pause, 24, "#1E90ff", constants.breaks() + " "
									+ constants.interval()));
						}
					}
				}
				dataArray = data.toArray(new HorizontalStackedBarChart.StackValue[0]);
				barChart.addStack(dataArray);
			}
			barChart.setTooltip("");
			model = new ChartModel();
			model.setXAxis(xAxis);
			model.setYAxis(yAxis);
			model.addChartConfig(barChart);
			chart.setChartModel(model);
			chart.setToolTip("");
			chart.removeToolTip();
		}

		/**
		 * This function deletes the selected rows (clicked checkboxes)
		 */
		private void deleteSelectedRows() {
			for (int i = store.getCount() - 1; i >= 0; i--) {
				if (store.getAt(i).getDelete()) {
					store.remove(store.getAt(i));
					tableRows--;
				}
			}
			for (int i = 0; i < store.getCount(); i++) {
				store.getAt(i).setNummer(i + 1);
			}
		}

		/**
		 * Function to reset the store (delete all).
		 */
		public void resetStore() {
			for (int i = store.getCount() - 1; i >= 0; i--) {
				store.remove(store.getAt(i));
				tableRows--;
			}
			List<ShiftBaseModel> shiftlist = new ArrayList<ShiftBaseModel>();
			shiftlist.add(new ShiftBaseModel(++tableRows, "00:00", "00:00", "00:00", "00:00", "0", "0", 0, 0, 0, 0, 0, 1.0, false));
			store.add(shiftlist);
			if (slc.validate()) {
				store.commitChanges();
				slc.updateChart();
			}
		}
	}

	/**
	 * Creates the display of the chart.
	 * 
	 * @return the view
	 */
	public LayoutContainer getView() {
		RowLayout rl = new RowLayout();
		container.setLayout(rl);
		container.setSize(1000, 700);
		container.add(slg.getShiftlistGrid());
		ContentPanel chartPane = slc.getShiftlistChart();
		container.add(chartPane);

		loadNightAllownessProps();
		return container;
	}

	private void loadNightAllownessProps() {
		final PersPlanServiceAsync persPlanService = (PersPlanServiceAsync) GWT.create(PersPlanService.class);

		persPlanService.getNightBreakAllowness(new AsyncCallback<Map<Integer, String>>() {

			@Override
			public void onSuccess(Map<Integer, String> result) {
				nightBreakStart = result.get(0);
				nightBreakEnd = result.get(1);
			}

			@Override
			public void onFailure(Throwable caught) {
			}
		});
	}

	/**
	 * Returns the demand
	 * 
	 * @return the list
	 */
	public static List<ShiftBaseModel> returnShifts() {
		return store.getModels();
	}

	/**
	 * Sets the shift list.
	 * 
	 * @param sList
	 *            the new shift list
	 */
	public void setShiftList(List<ShiftBaseModel> sList) {
		slc.resetStore();
		store.removeAll();
		store.add(sList);
		tableRows = sList.size();
		store.commitChanges();
		slc.updateChart();
	}

	/**
	 * Gets the SLC (ShiftlistChart)
	 * 
	 * @return the chart
	 */
	public ShiftlistChart getSLC() {
		return this.slc;
	}

}
