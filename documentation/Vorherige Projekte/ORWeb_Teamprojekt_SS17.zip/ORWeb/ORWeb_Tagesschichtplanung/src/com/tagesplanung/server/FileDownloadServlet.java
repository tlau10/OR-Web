package com.tagesplanung.server;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// TODO: Auto-generated Javadoc
/**
 * The Class FileDownloadServlet executes a download dialog.
 */
public class FileDownloadServlet extends HttpServlet {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	private Properties properties;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest
	 * , javax.servlet.http.HttpServletResponse)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest
	 * , javax.servlet.http.HttpServletResponse)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String filePath = request.getParameter("filePath");

		loadProperties();

		// Prüfen, ob die geforderte Datei im Arbeitsverzeichnis liegt
		if (filePath.startsWith(properties.getProperty("working.directory")) || filePath.startsWith(System.getProperty("java.io.tmpdir"))) {

			String fileName = request.getParameter("fileName");
			File file = new File(filePath);
			InputStream in = new FileInputStream(file);

			response.addHeader("Content-Type", "application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
			response.addHeader("Pragma", "public");
			response.addHeader("Cache-Control", "max-age=0");

			ServletOutputStream outs = response.getOutputStream();
			byte uploadedFile[] = new byte[in.available()];
			in.read(uploadedFile);

			outs.write(uploadedFile);
			outs.flush();
			outs.close();
			in.close();

		} else {
			PrintWriter pw = response.getWriter();
			pw.write("Das glaube ich nicht.");
		}

	}

	public void loadProperties() {
		if (properties == null) {
			try {
				properties = new Properties();
				// properties.load(new FileInputStream(pathToProperties));
				properties.load(PersPlanServiceImpl.class.getResourceAsStream("tagesplanung.properties"));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}