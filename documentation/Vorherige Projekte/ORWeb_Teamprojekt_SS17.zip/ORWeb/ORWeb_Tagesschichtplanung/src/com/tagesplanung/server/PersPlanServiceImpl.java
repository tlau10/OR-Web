package com.tagesplanung.server;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.tagesplanung.client.PersPlanService;
import com.tagesplanung.server.data.Demand;
import com.tagesplanung.server.data.MarshallData;
import com.tagesplanung.server.data.SaveLoadDemand;
import com.tagesplanung.server.data.SaveLoadShift;
import com.tagesplanung.server.data.SolverInputData;
import com.tagesplanung.server.data.SolverOutputData;
import com.tagesplanung.server.data.UnMarshallData;
import com.tagesplanung.server.solver.DataTransformer;
import com.tagesplanung.server.solver.ISolver;
import com.tagesplanung.server.solver.xa.XASolver;
import com.tagesplanung.server.solver.xa.resources.XAResourceUtil;
import com.tagesplanung.shared.Bedarf;
import com.tagesplanung.shared.Result;
import com.tagesplanung.shared.ResultBaseModel;
import com.tagesplanung.shared.ShiftBaseModel;

/**
 * The Class PersPlanServiceImpl is the implementation of an RPC servlet. This
 * is the main class on the server side. All requests of the clients (WebGUI)
 * come to this servlet and it then passes the handling of the request to other
 * classes. It contains methods for saving and loading shift planning and demand
 * planning files and the solve method. It also gives access to the location of
 * the LP model file.
 */
public class PersPlanServiceImpl extends RemoteServiceServlet implements PersPlanService {

	/** The serialVersionUID for serialization. */
	private static final long serialVersionUID = 4045846777827682819L;

	/**
	 * Properties to determine paths.
	 */
	private Properties properties;
	public String sessionID;

	/**
	 * Loads the configuration properties.
	 * 
	 * @param properties
	 *            file where the paths can be configured
	 */
	public void loadProperties() {
		if (properties == null) {
			try {
				properties = new Properties();
				// properties.load(new FileInputStream(pathToProperties));
				properties.load(PersPlanServiceImpl.class.getResourceAsStream("tagesplanung.properties"));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.tagesplanung.client.PersPlanService#solve(java.util.List,
	 * java.util.List)
	 */
	@Override
	public List<Result> solve(List<Bedarf> bList, List<ShiftBaseModel> sList) {
		// Begin of Change by fafilipp
		// Prepare C:/Temp Directory with XA.exe
		XAResourceUtil.copyXAExeTo(getWorkingDir());
		// End of Change

		sessionID = this.getThreadLocalRequest().getSession().getId();

		loadProperties();

		// Transforming the data from the front-end
		DataTransformer transformer = new DataTransformer();
		SolverInputData inputData = transformer.transformInputData(bList, sList);

		// Calling the solver
		ISolver solver = new XASolver(getWorkingDir());
		SolverOutputData outputData = solver.solve(inputData, sessionID);

		// Transforming the result
		List<Result> result = transformer.transformOutputData(inputData, outputData);

		// Deleting files
		// FileDeleter deleter = new
		// FileDeleter(getWorkingDir());
		// deleter.deleteFiles(sessionID);

		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.tagesplanung.client.PersPlanService#getLPURL()
	 */
	@Override
	public String getLPURL() {
		// Begin of Change by fafilipp
		String filepath = getWorkingDir() + "XA_" + sessionID.substring(0, 5) + ".LP";
		if (new File(filepath).exists()) {
			return filepath;
		} else {
			return null;
		}
		// End of Change
	}

	/*
	 * (non-Javadoc) the method deleteFile delete a file if it exists and return
	 * the filepath.
	 */
	@Override
	public String deleteFile(String filePath) {
		loadProperties();
		File file = new File(filePath);
		if (file.exists()) {
			file.delete();
		}
		return getWorkingDir() + "LoadFile.xml";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.tagesplanung.client.PersPlanService#getResultBaseModel(java.util.
	 * List)
	 */
	@Override
	public List<ResultBaseModel> getResultBaseModel(List<Result> result) {
		loadProperties();
		return ResultBaseModel.transformResultObjectToBaseModel(result);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.tagesplanung.client.PersPlanService#getGraficVisualOfResult(java.
	 * util.List, java.util.List)
	 */
	@Override
	public int[][] getGraficVisualOfResult(List<Result> resultList, List<Bedarf> demand) {
		loadProperties();
		List<Result> resultShifts = new ArrayList<Result>();
		List<Result> resultShiftBreaks = new ArrayList<Result>();
		Demand demandTrans = new Demand();
		Iterator<Bedarf> bIterator = demand.iterator();

		while (bIterator.hasNext()) {

			Bedarf b = bIterator.next();
			if (demand.size() == 24) {
				demandTrans.add(b.getBedarf());
				demandTrans.add(b.getBedarf());
			} else {
				demandTrans.add(b.getBedarf());
			}
		}

		int breakCounter = 0;
		for (int i = 0; i < resultList.size(); i++) {
			Result r = resultList.get(i);
			if (r.getShiftStart() != null) {
				resultShifts.add(r);
				if ((r.getBreakIntervall() != null) && (r.getNumberOfPeopleInBreak() != 0)) {
					resultShiftBreaks.add(r);
					breakCounter++;
				}
			} else {
				if (r.getBreakIntervall() != null) {
					resultShiftBreaks.add(r);
					breakCounter++;
				}
			}
		}

		/**
		 * Begin of change (jaglaubi)
		 */
		int rows = 0;
		// größe des Arrays anhand der vom Solver ausgewählten
		// Schichten bestimmen.
		// (Anzahl der Schichten * 3) + 2
		// Pro Schicht werden scheinbar 3 Stellen benötigt
		// + 2 weitere für "Bedarf" (Index 0) und "realen Bedarf"
		// (Index l�nge - 1)
		if (resultShifts.size() != 0) {
			rows = (resultShifts.size() * 3) + 2;
		}

		// Mehrdimensionales Array erzeugen, o. berechnete Anzahl * 48 halbe
		// Stunden pro Tag
		//
		// setzt sich folgendermaßen zusammen:
		// Index 0: Bedarf
		//
		// for (Schicht : Schichten):
		// Index 1: Werte der Schichten (???)
		// Index 2: (???)
		// Index 3: (???)
		//
		// Index länge-1: realer Bedarf
		int[][] graphicVisual = new int[rows][48];

		// Fill first row with demands
		// Array index 0 = Bedarf je halbe Stunde
		for (int i = 0; i < demandTrans.size(); i++) {
			graphicVisual[0][i] = demandTrans.get(i);
		}

		// insert the shift values into the array starting by[1][X] next [4][x]
		// etc.
		//
		int counter = 1;

		// for-schleife über alle Schichten aus dem Ergebnis
		for (int i = 0; i < resultShifts.size(); i++) {
			Result r = resultShifts.get(i);

			// Schichtstart liegt vor dem Schichtende
			if (r.getIntShiftStart() < r.getIntShiftEnd()) {
				for (int h = r.getIntShiftStart() - 1; h <= r.getIntShiftEnd() - 1; h++) {
					// Für jede halbe Stunde der Schicht die Anzahl der Leute
					// setzen
					graphicVisual[counter][h] = r.getNumberOfPeople();
				}

				// Schichtende liegt vor dem Schichtstart (Tageswechsel)
			} else if (r.getIntShiftStart() > r.getIntShiftEnd()) {

				// Für jede halbe Stunde der Schicht die Anzahl der Leute setzen
				for (int l = 0; l < r.getIntShiftEnd(); l++) {
					graphicVisual[counter][l] = r.getNumberOfPeople();
				}
				for (int m = r.getIntShiftStart() - 1; m <= 47; m++) {
					graphicVisual[counter][m] = r.getNumberOfPeople();
				}
			}

			for (int h = r.getIntShiftStart() - 1; h <= r.getIntShiftEnd() - 1; h++) {
				graphicVisual[counter][h] = r.getNumberOfPeople();
			}
			counter += 3;
		}

		// insert Break values to the shifts in the visual array
		int counterBreak1 = -1;
		int counterBreak2 = 0;
		int peopleInBreakCounter = 0;

		for (int i = 0; i < resultList.size(); i++) {
			Result r = resultList.get(i);
			if (r.getShiftNumber() != 0) {
				peopleInBreakCounter = 0;
				counterBreak1 += 3;
				counterBreak2 += 3;
			}
			if ((r.getBreakIntervall() != null) && (r.getNumberOfPeopleInBreak() != 0)) {
				graphicVisual[counterBreak1][r.getBreakIntervallNumber() - 1] = peopleInBreakCounter;
				peopleInBreakCounter = peopleInBreakCounter + r.getNumberOfPeopleInBreak();
				graphicVisual[counterBreak2][r.getBreakIntervallNumber() - 1] = peopleInBreakCounter;
			}
		}

		// in last row of the array the "real demand" of every time interval
		// real demand = demand + people in Break!
		// "realer Bedarf" je halbe Stunde in den letzten Index,
		// => wird nicht mehr verwendet
		if (rows > 0) {
			for (int i = 0; i < 48; i++) {
				int peopleBreak = 0;
				int demandP = graphicVisual[0][i];
				for (int y = 1; y < graphicVisual.length - 3; y += 3) {
					peopleBreak += (graphicVisual[y + 2][i] - graphicVisual[y + 1][i]);
				}
				graphicVisual[graphicVisual.length - 1][i] = demandP + peopleBreak;
			}
		}
		/**
		 * End of change
		 */
		// for(int i = 0; i<graphicVisual.length;i++){
		// for(int y=0; y<graphicVisual[i].length; y++){
		// System.out.print("\t"+graphicVisual[i][y]);
		// }
		// System.out.println("");
		// }
		return graphicVisual;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.tagesplanung.client.PersPlanService#saveDemandData(java.util.List)
	 */
	@Override
	public String saveDemandData(List<Bedarf> bList) {
		loadProperties();
		// get the sessionID
		String sessionId = this.getThreadLocalRequest().getSession().getId();
		// the filepath consists of the working directory,
		// the name demand,the session id and the extension xml.
		String filePath = getWorkingDir() + "Demand_" + sessionId + ".xml";
		// create the wrapper class SaveLoadDemand
		SaveLoadDemand sld = new SaveLoadDemand();
		// set the bedarf list to the wrapper class
		sld.setBedarf(bList);
		// create the marshall class
		MarshallData marshall = new MarshallData();
		// marshall the SaveLoadDemand object in a xml document
		marshall.marshallDemand(filePath, sld);
		return filePath;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.tagesplanung.client.PersPlanService#saveShiftData(java.util.List)
	 */
	@Override
	public String saveShiftData(List<ShiftBaseModel> sList) {
		loadProperties();
		// get the sessionID
		String sessionId = this.getThreadLocalRequest().getSession().getId();
		// the filepath consists of the working directory,
		// the name shift,the session id and the extension xml.
		String filePath = getWorkingDir() + "Shift_" + sessionId + ".xml";
		// create the wrapper class SaveLoadShift
		SaveLoadShift sls = new SaveLoadShift();
		// set the shiftBaseModel list to the wrapper class
		sls.setShiftBaseModel(sList);
		// create the marshall class
		MarshallData marshall = new MarshallData();
		// marshall the SaveLoadShift object in a xml document
		marshall.marshallShift(filePath, sls);
		return filePath;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.tagesplanung.client.PersPlanService#loadDemandData()
	 */
	@Override
	public List<Bedarf> loadDemandData() {
		loadProperties();
		// the filepath consists of the working directory,
		// the name LoadFile and the extension xml.
		String filePath = getWorkingDir() + "LoadFile.xml";
		// create the unmarshall class
		UnMarshallData unMarshall = new UnMarshallData();
		// unmarshall the xml document in a SaveLoadDemand object
		SaveLoadDemand sld = unMarshall.unMarhallDemand(filePath);
		// delete the file
		File file = new File(filePath);
		file.delete();
		// return the bedarf list from the SaveLoadDemand object
		return sld.getBedarf();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.tagesplanung.client.PersPlanService#loadShiftData()
	 */
	@Override
	public List<ShiftBaseModel> loadShiftData() {
		loadProperties();
		// the filepath consists of the working directory,
		// the name LoadFile and the extension xml.
		String filePath = getWorkingDir() + "LoadFile.xml";
		// create the unmarshall class
		UnMarshallData unMarshall = new UnMarshallData();
		// unmarshall the xml document in a SaveLoadShift object
		SaveLoadShift sls = unMarshall.unMarshallShift(filePath);
		// delete the file
		File file = new File(filePath);
		file.delete();
		// return the ShiftBaseModel list from the SaveLoadShift object
		return sls.getShiftBaseModel();
	}

	// Begin of Change by fafilipp
	private String getWorkingDir() {
		File dir = new File(properties.getProperty("working.directory", System.getProperty("java.io.tmpdir")));
		if (!dir.exists()) {
			dir.mkdir();
		}
		return dir.getAbsolutePath() + "\\";
	}

	@Override
	public Map<Integer, String> getNightBreakAllowness() {
		Map<Integer, String> props = new HashMap<Integer, String>();
		loadProperties();
		props.put(0, properties.getProperty("nightbreak.start"));
		props.put(1, properties.getProperty("nightbreak.end"));
		return props;
	}
	// End of Change

}