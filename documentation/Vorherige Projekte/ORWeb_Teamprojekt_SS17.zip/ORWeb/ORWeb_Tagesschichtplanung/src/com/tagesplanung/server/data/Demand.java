package com.tagesplanung.server.data;

import java.util.ArrayList;

/**
 * The Class Demand represents the demand of workers during a day.
 * This list can have the length of 24 when the demand is assigned for every hour
 *  or the length of 48 when the demand is assigned for every half an hour.
 */
public class Demand extends ArrayList<Integer> {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 6929805252141096816L;
}
