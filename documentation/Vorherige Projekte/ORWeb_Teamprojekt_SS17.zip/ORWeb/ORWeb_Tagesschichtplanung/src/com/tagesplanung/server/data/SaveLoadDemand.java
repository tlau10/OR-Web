package com.tagesplanung.server.data;

import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import com.tagesplanung.shared.Bedarf;

// TODO: Auto-generated Javadoc
/**
 * The Class SaveLoadDemand is a wrapper class for the Bedarf class.
 * It is used to marshall the demand to a xml document.
 */

@XmlRootElement(name = "SaveLoadDemad") 
public class SaveLoadDemand {
	
	/** The bedarf. */
	List<Bedarf> bedarf;
	
	/**
	 * Instantiates a new save load demand.
	 */
	public SaveLoadDemand() {
		super();
	}
	
	/**
	 * Gets the bedarf.
	 *
	 * @return the bedarf list
	 */
	@XmlElement( name = "Demand" ) 
	public List<Bedarf> getBedarf() {
		return bedarf;
	}
	
	/**
	 * Sets the bedarf.
	 *
	 * @param bedarf the new bedarf list
	 */
	public void setBedarf(List<Bedarf> bedarf) {
		this.bedarf = bedarf;
	}
}