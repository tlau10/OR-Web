package com.tagesplanung.server.data;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.tagesplanung.shared.ShiftBaseModel;

/**
 * The Class SaveLoadShift is a wrapper class for all shiftBaseModels.
 * It is used to marshall all shifts to a xml document.
 */
@XmlRootElement(name = "SaveLoadShift") 
public class SaveLoadShift {	
	
	/** The shift base model. */
	List<ShiftBaseModel> shiftBaseModel;

	/**
	 * Instantiates a new save load shift.
	 */
	public SaveLoadShift() {
		super();
	}
	
	/**
	 * Gets the shift base model.
	 *
	 * @return the shift base model list
	 */
	@XmlElement( name = "Shift" ) 
	public List<ShiftBaseModel> getShiftBaseModel() {
		return shiftBaseModel;
	}
	
	/**
	 * Sets the shift base model list.
	 *
	 * @param shiftBaseModel the new shift base model
	 */
	public void setShiftBaseModel(List<ShiftBaseModel> shiftBaseModel) {
		this.shiftBaseModel = shiftBaseModel;
	}
}