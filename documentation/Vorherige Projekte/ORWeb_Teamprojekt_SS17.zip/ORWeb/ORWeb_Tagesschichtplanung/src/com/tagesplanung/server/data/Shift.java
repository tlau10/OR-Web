package com.tagesplanung.server.data;

/**
 * The Class Shift represents a shift of arbitrary length (but less than 24 hours).
 * A shift is period of time where a specific number of people are working.
 * How many people are working and who is taking a break is calculated by the solver.
 */
public class Shift {
	
	/** The id of the shift. */
	private int number;
	
	/** The start interval of the shift. */
	private int from;
	
	/** The end interval of the shift. */
	private int to;
	
	/** The String representation of the start interval. */
	private String startInterval;
	
	/** The String representation of the end interval. */
	private String endInterval;
	
	/** The priority of the shift. */
	private double priority;
	
	/** The maximum number of people who can be assigned to this shift. */
	private int maxPeople;
	
	/** The break area of this shift. */
	private BreakArea breakArea;
	
	/**
	 * Instantiates a new shift.
	 *
	 * @param number the id of the shift
	 * @param from the start interval of the shift
	 * @param to the end interval of the shift
	 * @param maxPeople the maximum number of people
	 * @param priority the priority
	 * @param startIntervall the String representation of start interval
	 * @param endIntervall the String representation of end interval
	 */
	public Shift(int number, int from, int to, int maxPeople, double priority, String startIntervall, String endIntervall) {
		this.number = number;
		this.from = from;
		this.to = to;
		this.priority = priority;
		this.maxPeople = maxPeople;
		this.startInterval = startIntervall;
		this.endInterval = endIntervall;
	}
	
	/**
	 * Gets the start interval.
	 *
	 * @return the start interval
	 */
	public String getStartInterval() {
		return startInterval;
	}
	
	/**
	 * Sets the start interval.
	 *
	 * @param startinterval the new start interval
	 */
	public void setStartInterval(String startinterval) {
		this.startInterval = startinterval;
	}
	
	/**
	 * Gets the end interval.
	 *
	 * @return the end interval
	 */
	public String getEndInterval() {
		return endInterval;
	}
	
	/**
	 * Sets the end interval.
	 *
	 * @param endinterval the new end interval
	 */
	public void setEndInterval(String endinterval) {
		this.endInterval = endinterval;
	}
	
	/**
	 * Gets the id of the shift.
	 *
	 * @return the id of the shift
	 */
	public int getNumber() {
		return number;
	}
	
	/**
	 * Sets the id of the shift.
	 *
	 * @param number the new id of the shift
	 */
	public void setNumber(int number) {
		this.number = number;
	}
	
	/**
	 * Gets the start interval of the shift.
	 *
	 * @return the start interval of the shift
	 */
	public int getFrom() {
		return from;
	}
	
	/**
	 * Sets the start interval of the shift.
	 *
	 * @param from the new start interval of the shift
	 */
	public void setFrom(int from) {
		this.from = from;
	}
	
	/**
	 * Gets the end interval of the shift.
	 *
	 * @return the end interval of the shift
	 */
	public int getTo() {
		return to;
	}
	
	/**
	 * Sets the end interval of the shift.
	 *
	 * @param to the new end interval of the shift
	 */
	public void setTo(int to) {
		this.to = to;
	}
	
	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public double getPriority() {
		return priority;
	}
	
	/**
	 * Sets the priority.
	 *
	 * @param priority the new priority
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}
	
	/**
	 * Gets the maximum number of people.
	 *
	 * @return the maximum number of people
	 */
	public int getMaxPeople() {
		return maxPeople;
	}
	
	/**
	 * Sets the maximum number of people.
	 *
	 * @param maxPeople the new maximum number of people
	 */
	public void setMaxPeople(int maxPeople) {
		this.maxPeople = maxPeople;
	}
	
	/**
	 * Gets the break area.
	 *
	 * @return the break area
	 */
	public BreakArea getBreakArea() {
		return breakArea;
	}
	
	/**
	 * Sets the break area.
	 *
	 * @param breakArea the new break area
	 */
	public void setBreakArea(BreakArea breakArea) {
		this.breakArea = breakArea;
	}
}