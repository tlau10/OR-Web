package com.tagesplanung.server.data;

import java.util.ArrayList;

/**
 * The Class SolverInputData encapsulates the information the solver needs 
 * to calculate the optimal solution.
 * At the moment only the XA Solver is supported.
 */
public class SolverInputData { 
	
	/** The shifts. */
	private ArrayList<Shift> shifts = new ArrayList<Shift>();
	
	/** The demand. */
	private Demand demand;
	
	/** The solver. */
	private String solver;
	
	/**
	 * Gets the shifts.
	 *
	 * @return the shifts
	 */
	public ArrayList<Shift> getShifts() {
		return shifts;
	}
	
	/**
	 * Sets the shifts.
	 *
	 * @param shifts the new shifts
	 */
	public void setShifts(ArrayList<Shift> shifts) {
		this.shifts = shifts;
	}	
	
	/**
	 * Gets the demand.
	 *
	 * @return the demand
	 */
	public Demand getDemand() {
		return demand;
	}
	
	/**
	 * Sets the demand.
	 *
	 * @param demand the new demand
	 */
	public void setDemand(Demand demand) {
		this.demand = demand;
	}
	
	/**
	 * Gets the solver.
	 *
	 * @return the solver
	 */
	public String getSolver() {
		return solver;
	}
	
	/**
	 * Sets the solver.
	 *
	 * @param solver the new solver
	 */
	public void setSolver(String solver) {
		this.solver = solver;
	}	
}