package com.tagesplanung.server.data;

import java.util.ArrayList;

/**
 * The Class SolverOutputData encapsulates the results from the solver.
 */
public class SolverOutputData {

	/** List of all shifts and how many people were assigned to each shift. */
	ArrayList<Integer> shiftList;

	/**
	 * List of all breaks and how many people the solver assigned to each break.
	 */
	ArrayList<Break> breakList;

	/**
	 * Will be true, if Math.round is been used and a round mistake could be
	 * done
	 */
	boolean rounded = false;

	/**
	 * Instantiates a new solver output data.
	 * 
	 * @param shiftList
	 *            the shift list
	 * @param breakList
	 *            the break list
	 */
	public SolverOutputData(ArrayList<Integer> shiftList, ArrayList<Break> breakList) {
		this.shiftList = shiftList;
		this.breakList = breakList;
	}

	/**
	 * Gets the shift list.
	 * 
	 * @return the shift list
	 */
	public ArrayList<Integer> getShiftList() {
		return shiftList;
	}

	/**
	 * Sets the shift list.
	 * 
	 * @param shiftList
	 *            the new shift list
	 */
	public void setShiftList(ArrayList<Integer> shiftList) {
		this.shiftList = shiftList;
	}

	/**
	 * Gets the break list.
	 * 
	 * @return the break list
	 */
	public ArrayList<Break> getBreakList() {
		return breakList;
	}

	/**
	 * Sets the break list.
	 * 
	 * @param breakList
	 *            the new break list
	 */
	public void setBreakList(ArrayList<Break> breakList) {
		this.breakList = breakList;
	}

	public void setRounded(boolean rounded) {
		this.rounded = rounded;
	}

	public boolean isRounded() {
		return rounded;
	}
}