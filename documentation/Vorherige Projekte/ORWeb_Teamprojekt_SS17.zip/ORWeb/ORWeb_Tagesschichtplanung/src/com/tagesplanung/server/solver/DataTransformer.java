package com.tagesplanung.server.solver;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.tagesplanung.server.data.Break;
import com.tagesplanung.server.data.BreakArea;
import com.tagesplanung.server.data.Demand;
import com.tagesplanung.server.data.Shift;
import com.tagesplanung.server.data.SolverInputData;
import com.tagesplanung.server.data.SolverOutputData;
import com.tagesplanung.shared.Bedarf;
import com.tagesplanung.shared.Result;
import com.tagesplanung.shared.ShiftBaseModel;
import com.tagesplanung.shared.TimeIntervall;

// TODO: Auto-generated Javadoc
/**
 * The Class DataTransformer.
 */
public class DataTransformer {

	/**
	 * Transform input data.
	 * 
	 * @param bList
	 *            the b list
	 * @param sList
	 *            the s list
	 * @return the solver input data
	 */
	public SolverInputData transformInputData(List<Bedarf> bList,
			List<ShiftBaseModel> sList) {
		SolverInputData inputData = new SolverInputData();
		// Transforming demand
		Demand demand = new Demand();
		Iterator<Bedarf> bIterator = bList.iterator();
		while (bIterator.hasNext()) {
			Bedarf b = bIterator.next();
			if (bList.size() == 24) {
				demand.add(b.getBedarf());
				demand.add(b.getBedarf());
			} else {
				demand.add(b.getBedarf());
			}
		}
		// Transforming shifts + break intervalls
		ArrayList<Shift> shiftList = new ArrayList<Shift>();
		Iterator<ShiftBaseModel> sIterator = sList.iterator();
		while (sIterator.hasNext()) {
			ShiftBaseModel shift = sIterator.next();
			// Extracting data from ShiftBaseModel for solver handeling
			Shift s = new Shift(shift.getNummer(), shift.getStartInt(),
					shift.getEndInt() - 1, Integer.parseInt(shift.getBedarf()),
					shift.getPraefDouble(), shift.getStart(), shift.getEnd());
			BreakArea breakArea = null;
			if (shift.getStartPauseInt() != shift.getEndPauseInt()) {
				breakArea = new BreakArea(shift.getStartPauseInt(),
						shift.getEndPauseInt() - 1, 100);
			}
			s.setBreakArea(breakArea);
			shiftList.add(s);
		}
		// solver inputdata
		inputData.setDemand(demand);
		inputData.setShifts(shiftList);
		inputData.setSolver("XA");
		return inputData;
	}

	/**
	 * Transform output data.
	 * 
	 * @param inputData
	 *            the input data
	 * @param outputData
	 *            the output data
	 * @return the list
	 */
	public List<Result> transformOutputData(SolverInputData inputData,
			SolverOutputData outputData) {
		ArrayList<Integer> shiftListResult = outputData.getShiftList();
		ArrayList<Shift> shiftList = inputData.getShifts();
		ArrayList<Break> breakResultList = outputData.getBreakList();
		ArrayList<Result> resultTemp = new ArrayList<Result>();
		ArrayList<Result> resultList = new ArrayList<Result>();

		for (int i = 0; i < shiftListResult.size(); i++) {
			if (shiftListResult.get(i) != 0) {
				Shift s = shiftList.get(i);
				Result r;
				if (s.getBreakArea() != null) {
					r = new Result(s.getNumber(), s.getStartInterval(),
							s.getEndInterval(), (int) shiftListResult.get(i),
							"", 0);
					r.setRounded(outputData.isRounded());
				} else {
					r = new Result(s.getNumber(), s.getStartInterval(),
							s.getEndInterval(), (int) shiftListResult.get(i),
							"---", 0);
					r.setRounded(outputData.isRounded());
				}
				r.setIntShiftStart(s.getFrom());
				r.setIntShiftEnd(s.getTo());
				resultTemp.add(r);
			}
		}

		Collections.sort(resultTemp);

		for (int i = 0; i < resultTemp.size(); i++) {

			Result result = resultTemp.get(i);

			// if (i == 2) {
			// resultList.add(result);
			// }

			int persInShift = result.getNumberOfPeople();

			boolean headerCopied = false;

			if (result.getBreakIntervall().contains("---")) {
				resultList.add(result);
			} else {
				boolean isSaved = false;
				for (int j = 0; j < breakResultList.size(); j++) {
					Break b = breakResultList.get(j);
					if (persInShift == 0) {
						break;
					} else if ((b.getNumber() <= result.getIntShiftEnd())
							&& (b.getNumber() >= result.getIntShiftStart())) {
						isSaved = true;
						int personPerBreak = b.getPeople();
						Result rTemp;
						if (!headerCopied) {
							rTemp = result;
						} else {
							rTemp = new Result();
						}
						rTemp.setRounded(outputData.isRounded());
						if (personPerBreak <= persInShift) {
							rTemp.setBreakIntervall(TimeIntervall
									.getIntervallbyNumber(b.getNumber()));
							rTemp.setNumberOfPeopleInBreak(b.getPeople());
							rTemp.setBreakIntervallNumber(b.getNumber());
							persInShift -= b.getPeople();
							breakResultList.remove(b);
							j--;
						} else {
							rTemp.setBreakIntervall(TimeIntervall
									.getIntervallbyNumber(b.getNumber()));
							rTemp.setNumberOfPeopleInBreak(persInShift);
							rTemp.setBreakIntervallNumber(b.getNumber());
							int allPeoplePerBreak = breakResultList.get(j)
									.getPeople();
							breakResultList.get(j).setPeople(
									allPeoplePerBreak - persInShift);
							persInShift = 0;
						}
						resultList.add(rTemp);
						headerCopied = true;
					}
				}
				if (!isSaved) {
					result.setNumberOfPeopleInBreak(0);
					result.setBreakIntervall("---");
					resultList.add(result);
				}
			}
		}
		// showResult(resultList);
		return resultList;
	}
	// public void showResult(List<Result> resultList){
	// for (int i = 0; i<resultList.size();i++){
	// Result r = resultList.get(i);
	// System.out.println(r.getShiftNumber()+" "+r.getShiftStart()+" "+r.getShiftEnd()+" "+r.getNumberOfPeople()+" "+r.getBreakIntervall()+" "+r.getNumberOfPeopleInBreak());
	// }
	// }
}
