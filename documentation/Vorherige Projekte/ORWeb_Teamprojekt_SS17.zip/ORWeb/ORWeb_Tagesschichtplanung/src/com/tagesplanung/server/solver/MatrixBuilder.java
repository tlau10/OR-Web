package com.tagesplanung.server.solver;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.ListIterator;

import com.tagesplanung.server.data.BreakArea;
import com.tagesplanung.server.data.Shift;
import com.tagesplanung.server.data.SolverInputData;

/**
 * The Class MatrixBuilder creates the break variables array and the LP matrix
 * of constraints for the solver. It also provides methods for the formatted
 * output of the matrix e.g. for debugging.
 */
public class MatrixBuilder {

	/** The session id. */
	private final String sessionID;

	/**
	 * Instantiates a new matrix builder.
	 * 
	 * @param sessionID
	 *            the session id
	 */
	public MatrixBuilder(String sessionID) {
		this.sessionID = sessionID;
	}

	/**
	 * Creates the break variables array. as the break areas of different shifts
	 * can overlap, it has to be determined in which intervals it is possible to
	 * take a break
	 * 
	 * @param data
	 *            the solver input data (list of shifts & demand)
	 * @return the array list of of all intervals in break areas
	 */
	public ArrayList<Integer> createBreakVariablesArray(SolverInputData data) {

		ArrayList<Integer> breakVariables = new ArrayList<Integer>();
		// determine how many break variables are needed
		for (int i = 0; i < data.getShifts().size(); i++) {
			BreakArea b = data.getShifts().get(i).getBreakArea();
			if (b != null) {
				for (int j = b.getFrom(); j < b.getTo() + 1; j++) {
					boolean found = false;
					Iterator<Integer> iterator = breakVariables.iterator();
					while (iterator.hasNext()) {
						if (iterator.next() == Integer.valueOf(j)) {
							found = true;
						}
					}
					if (!found) {
						breakVariables.add(j);
					}
				}
			}
		}
		// uncomment this for debug:
		// outputbreakVariables(breakVariables);
		// sorting of break variables
		Collections.sort(breakVariables);
		return breakVariables;
	}

	/**
	 * Builds the matrix of constraints.
	 * 
	 * @param data
	 *            the solver input data
	 * @param breakVariables
	 *            the break variables
	 * @return the int[][] matrix
	 */
	public int[][] buildMatrix(SolverInputData data, ArrayList<Integer> breakVariables) {
		int numberOfBreakVariables = breakVariables.size();
		int x = 48 + (2 * numberOfBreakVariables) + data.getShifts().size();
		int y = data.getShifts().size() + (numberOfBreakVariables) + 1;
		int[][] matrix = new int[x][y];
		int counter = 0;
		// Part 1 of matrix
		for (int i = 0; i < 48; i++) {
			for (int j = 0; j < data.getShifts().size(); j++) {
				// get current shift to read data
				Shift shift = data.getShifts().get(j);
				// write 1 into each half an hour interval where people are
				// working
				// if ((shift.getFrom() < shift.getTo() && i+1 >=
				// shift.getFrom() && i < shift.getTo()) ||
				// (shift.getFrom() > shift.getTo()) && !(i < shift.getFrom() &&
				// i >= shift.getTo())) {
				// matrix[i][j] = 1;
				// // the last column contains the demand
				// matrix[i][y-1] = data.getDemand().get(i);
				// }

				/**
				 * Begin of change (jaglaubi)
				 */
				if (shift.getFrom() < shift.getTo()) {
					if (i + 1 >= shift.getFrom()) {
						if (i < shift.getTo()) {
							matrix[i][j] = 1;
							// the last column contains the demand
							matrix[i][y - 1] = data.getDemand().get(i);
						}
					}
				}

				if ((shift.getFrom() >= shift.getTo())) {
					if (!(i + 1 < shift.getFrom() && i >= shift.getTo())) {
						matrix[i][j] = 1;
						// the last column contains the demand
						matrix[i][y - 1] = data.getDemand().get(i);
					} else if (i + 1 >= shift.getFrom()) {
						matrix[i][j] = 1;
						// the last column contains the demand
						matrix[i][y - 1] = data.getDemand().get(i);
					}
				}
				/**
				 * End of change
				 */

				// write -1 into each half an hour interval where people can
				// take a break
				// attention! i starts with 0 but the first interval is 1
				if (shift.getBreakArea() != null) {
					if ((shift.getBreakArea().getFrom() < shift.getBreakArea().getTo() && (i + 1) >= shift.getBreakArea().getFrom() && i < shift
							.getBreakArea().getTo())
							|| (shift.getBreakArea().getFrom() > shift.getBreakArea().getTo())
							&& !(i < shift.getBreakArea().getFrom() && (i + 1) >= shift.getBreakArea().getTo())) {
						// only write -1 and increment the counter, if break
						// variable wasn't set before
						if (matrix[i][data.getShifts().size() + counter - 1] != -1) {
							matrix[i][data.getShifts().size() + counter] = -1;
							counter++;
						}
					}
				}
			}
		}
		// Part 2: break control

		for (int j = 0; j < data.getShifts().size(); j++) {
			// get current shift to read data
			Shift shift = data.getShifts().get(j);
			// break area of current shift
			BreakArea breakArea = shift.getBreakArea();
			for (int i = 0; i < numberOfBreakVariables; i++) {
				if (breakArea != null) {
					// break area during the day
					if (breakArea.getFrom() < breakArea.getTo()) {
						// upper part
						if (breakArea.getFrom() <= breakVariables.get(i)) {
							matrix[i + 48][j] = 1;
						}
						// lower part
						if (breakVariables.get(i) <= breakArea.getTo()) {
							matrix[i + 48 + numberOfBreakVariables - 1][j] = 1;
						}
					}
					// break area over midnight
					else if (breakArea.getFrom() > breakArea.getTo()) {
						// not supported!!
					}
				}
				// write -1 into each half an hour interval where people can
				// take a break
				// attention! i starts with 0 but the first interval is 1
				int counter2 = 0;
				if (shift.getBreakArea() != null) {
					for (int k = 0; k < numberOfBreakVariables; k++) {
						matrix[i + 48 + k][data.getShifts().size() + counter2] = -1;
						counter2++;
					}
				}
				// everybody has to take abreak
				if (breakArea != null) {
					matrix[x - 1][j] = 1;
					matrix[x - 1][i + data.getShifts().size()] = -1;
				}
			}
			// add lines if max number of people is set
			if (shift.getMaxPeople() != 0) {
				matrix[j + 48 + (2 * numberOfBreakVariables) - 1][j] = 1;
				matrix[j + 48 + (2 * numberOfBreakVariables) - 1][y - 1] = shift.getMaxPeople();
			}
		}
		// outputMatrix(matrix);
		// outputMatrixToFile(matrix);
		// outputMatrixtoHTMLFile(matrix, data, breakVariables);
		return matrix;
	}

	/**
	 * Test output of the break matrix for debug in the console.
	 * 
	 * @param matrix
	 *            the matrix
	 */
	public void outputMatrix(int[][] matrix) {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				// System.out.print(matrix[i][j] + " ");
			}
			// System.out.println();
		}
	}

	/**
	 * Test output of the break matrix for debug into a text file.
	 * 
	 * @param matrix
	 *            the matrix
	 */
	public void outputMatrixToFile(int[][] matrix) {
		try {
			File f = new File("test.txt");
			f.createNewFile();
			FileWriter fw = new FileWriter(f);
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < matrix.length; i++) {
				sb.append(String.format("Z %2s: ", i + 1));
				for (int j = 0; j < matrix[i].length; j++) {
					if (j == (matrix[i].length - 1)) {
						sb.append(String.format(" %3s ", matrix[i][j]));
					} else {
						sb.append(String.format("%3s ", matrix[i][j] + " "));
					}
				}
				sb.append("\n");
			}
			fw.append(sb.toString());
			fw.flush();
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Output matrix to an HTML file, so that the user can see the LP model for
	 * his problem.
	 * 
	 * @param matrix
	 *            the matrix
	 * @param data
	 *            the data
	 * @param breakVariables
	 *            the break variables
	 */
	public void outputMatrixtoHTMLFile(int[][] matrix, SolverInputData data, ArrayList<Integer> breakVariables) {
		try {
			File f = new File("LP_" + sessionID + ".html");
			if (!f.exists()) {
				f.createNewFile();
			}
			FileWriter fw = new FileWriter(f);
			StringBuilder sb = new StringBuilder();
			sb.append("<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.0 Transitional//EN'>\n" + "<html>\n" + "<head><style type='text/css'>\n"
					+ "div.lp 	{ text-align: center; }\n"
					+ "h1.lp	{ font: 1.67em/0.9em, Verdana, sans-serif; margin-top: 0.9em; margin-bottom: 0.9em;	}\n"
					+ "h2.lp	{ font: 1.17em/1.29em, Verdana, sans-serif;	margin-top: 1.6em; margin-bottom: 1em;  }\n"
					+ "h3.lp	{ font: 0.80em/1.3em, Verdana, sans-serif; 	}\n"
					+ "table.lp    { font: 0.80em/1.3em, Verdana, sans-serif;	margin: 0 auto 20px; }\n"
					+ "table.lp td { background: white;   padding: 5px 8px; }\n" + ".red     { color: red; font-weight: bold; 	}\n"
					+ ".green   { color: green; font-weight: bold; 	}\n" + ".blue   	{ color: blue; font-weight: bold; 	}\n"
					+ ".purple 	{ color: purple; font-weight: bold; }\n" + ".bold 	{ font-weight: bold; }\n" + "</style></head>\n"
					+ "<body>\n<div  class='lp'><h1 class='lp'>LP-Matrix Personalplanung</h1>\n");
			// objective function
			sb.append("<h2 class='lp'>Zielfunktion:</h2>\n<h3 class='lp'><span class='bold'>MIN: </span>");
			for (int i = 0; i < data.getShifts().size(); i++) {
				sb.append("<span class='purple'> " + data.getShifts().get(i).getPriority() + "</span> s"
						+ data.getShifts().get(i).getNumber() + " ");
				if (i != data.getShifts().size() - 1) {
					sb.append(" +");
				}
			}
			ArrayList<Integer> bVariables = breakVariables;
			ListIterator<Integer> iterator = bVariables.listIterator();
			// break variables in objective function
			sb.append("+ 0 * (");
			while (iterator.hasNext()) {
				if (iterator.nextIndex() == breakVariables.size() - 1) {
					sb.append("+ p" + iterator.next());
				} else {
					sb.append("+ p" + iterator.next() + " ");
				}
			}
			sb.append(")</h3>\n<h2 class='lp'>Nebenbedingungen:</h2>\n<table class='lp'>\n");
			for (int i = 0; i < matrix.length; i++) {
				// test if there is somebody working in this interval of the day
				boolean zeroLine = false;
				for (int s = 0; s < data.getShifts().size(); s++) {
					if (matrix[i][s] == 0) {
						zeroLine = true;
					} else {
						zeroLine = false;
						break;
					}
				}
				// only print if there are'nt just zeros
				if (!zeroLine) {
					sb.append("<tr>");
					sb.append("<td><span class='bold'>");
					sb.append(String.format("Z %2s: ", i + 1));
					sb.append("</span></td>");
					for (int j = 0; j < matrix[i].length; j++) {
						// B-Vector
						if (j == (matrix[i].length - 1)) {
							sb.append("<td class='green'>");
							if (i == matrix.length - 1) {
								sb.append(String.format("= %3s ", matrix[i][j]));
							} else if (i >= (48 + (2 * breakVariables.size()) - 1)) {
								sb.append(String.format("=< %3s ", matrix[i][j]));
							} else {
								sb.append(String.format(">= %3s ", matrix[i][j]));
							}
							// rest of the matrix
						} else {
							if (matrix[i][j] < 0) {
								sb.append("<td class='red'>");
							} else if (matrix[i][j] == 1) {
								sb.append("<td class='blue'>");
							} else {
								sb.append("<td>");
							}
							if (j == 0 || matrix[i][j] < 0) {
								sb.append(matrix[i][j]);
							} else {
								sb.append("+ " + matrix[i][j]);
							}
						}
						sb.append("</td>");
					}
					sb.append("</tr>\n");
					sb.append("\n");
				}
			}
			sb.append("</table>\n</div></body>\n</html>");
			fw.append(sb.toString());
			fw.flush();
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Test output of break variables for debug.
	 * 
	 * @param breakVariables
	 *            the break variables
	 */
	public void outputbreakVariables(ArrayList<Integer> breakVariables) {
		for (int i = 0; i < breakVariables.size(); i++) {
			// System.out.println(breakVariables.get(i));
		}
	}
}