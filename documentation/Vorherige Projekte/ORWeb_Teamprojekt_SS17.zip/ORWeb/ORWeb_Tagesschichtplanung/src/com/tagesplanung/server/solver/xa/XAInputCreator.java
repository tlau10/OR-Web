package com.tagesplanung.server.solver.xa;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.ListIterator;

import com.tagesplanung.server.data.SolverInputData;

/**
 * The Class XAInputCreator contains methods to create all the files needed for
 * using the XA Solver.
 */
public class XAInputCreator {
	// array to determine how many break variables we need
	/** The break variables. */
	private ArrayList<Integer> breakVariables;

	/** The matrix. */
	private int[][] matrix;

	/**
	 * Instantiates a new XA input creator.
	 * 
	 * @param matrix
	 *            the matrix of constraints
	 * @param breakVariables
	 *            the break variables
	 */
	public XAInputCreator(int[][] matrix, ArrayList<Integer> breakVariables) {
		this.matrix = matrix;
		this.breakVariables = breakVariables;
	}

	/**
	 * Creates the .LP file (input file for XA solver). The file consists of 4
	 * parts: ..TITLE - title of LP Model ..OBJECTIVE MINIMIZE - objective
	 * function ..BOUNDS - bounds for variables ..CONSTRAINTS - constraints
	 * 
	 * @param pathToLP
	 *            the path to the folder where the LP file is created
	 * @param data
	 *            the solver input data
	 * @return true, if successful
	 */
	public boolean createLPFile(String pathToLP, SolverInputData data) {
		try {
			File solverInput = new File(pathToLP);
			boolean success = true;
			if (!solverInput.exists()) {
				success = solverInput.createNewFile();
			}
			if (success) {
				// write input file
				BufferedWriter writer = new BufferedWriter(new FileWriter(solverInput));
				// input file for XA-Solver consists of 4 parts:
				// 1. name of LP-Model
				writer.append("..TITLE");
				writer.newLine();
				writer.append(" Personaltagesplanung");
				writer.newLine();
				// 2. objective function
				writer.append("..OBJECTIVE MINIMIZE");
				writer.newLine();
				// shift variables
				for (int i = 0; i < data.getShifts().size(); i++) {
					writer.append(" " + data.getShifts().get(i).getPriority() + "s" + data.getShifts().get(i).getNumber() + " +");
				}
				ArrayList<Integer> bVariables = breakVariables;
				ListIterator<Integer> iterator = bVariables.listIterator();
				// break variables
				writer.append(" 0(");
				while (iterator.hasNext()) {
					if (iterator.nextIndex() == breakVariables.size() - 1) {
						writer.append("p" + iterator.next());
					} else {
						writer.append("p" + iterator.next() + " + ");
					}
				}
				writer.append(")");
				writer.newLine();
				// 3. maximum bounds (non negativity)
				writer.append("..BOUNDS");
				writer.newLine();
				int counter = 0;
				// bounds for shift variables
				for (int i = 0; i < data.getShifts().size(); i++) {
					writer.append(" Z" + ++counter + ": s" + data.getShifts().get(i).getNumber() + ">=0");
					writer.newLine();
				}
				// bounds for break variables
				ArrayList<Integer> bVariables2 = breakVariables;
				ListIterator<Integer> iterator2 = bVariables2.listIterator();
				while (iterator2.hasNext()) {
					writer.append(" Z" + ++counter + ": p" + iterator2.next() + ">=0");
					writer.newLine();
				}
				// 4. constraints
				writer.append("..CONSTRAINTS");
				writer.newLine();

				for (int i = 0; i < matrix.length; i++) {
					// line number
					String line = " Z" + ++counter + ": ";
					for (int j = 0; j < matrix[i].length - 1; j++) {
						// shift variables
						if (matrix[i][j] == 1) {
							if (line.contains("s")) {
								line = line + "+s" + (j + 1);
							} else {
								line = line + "s" + (j + 1);
							}
						}
						// break variables
						if (matrix[i][j] == -1) {
							line = line + "-p" + breakVariables.get(j - data.getShifts().size());
						}
					}
					// don't write empty lines to LP file (only zeros)
					// TODO: hier wird Z80 ignoriert
					if (line.contains("s") || line.contains("p")) {
						// last line = everybody has to take a break
						if (i == (matrix.length - 1)) {
							writer.append(line + "=" + matrix[i][matrix[i].length - 1]);
						}
						// max number of people
						else if (i >= (matrix.length - data.getShifts().size() - 1)) {
							writer.append(line + "<=" + matrix[i][matrix[i].length - 1]);
						}
						// normal line
						else {
							writer.append(line + ">=" + matrix[i][matrix[i].length - 1]);
						}
						writer.newLine();
					}

				}
				// write to file
				writer.flush();
				writer.close();
				return true;
			} else {
				// System.out.println("File already exists!");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * Creates the solver.CLP file. In this file the output file name and the
	 * options for the XA solver are set.
	 * 
	 * @param pathToClpFile
	 *            the path to the .CLP file
	 * @param id
	 *            part of the session id
	 * @return true, if successful
	 */
	public boolean createCLPFile(String pathToClpFile, String id) {
		try {
			File clpFile = new File(pathToClpFile);
			// write CLP file
			BufferedWriter writer = new BufferedWriter(new FileWriter(clpFile));
			writer.append(" " + id + ".lp LISTINPUT NO");
			writer.newLine();
			writer.append("                    OUTPUT " + id + ".out");
			writer.newLine();
			writer.append("                    PAGESIZE 24");
			writer.newLine();
			writer.append("                    LINESIZE 40");
			writer.newLine();
			writer.append("                    TMARGINS 0");
			writer.newLine();
			writer.append("                    BMARGINS 0");
			writer.newLine();
			writer.append("                    FIELDSIZE 11");
			writer.newLine();
			writer.append("                    DECIMALS 3");
			writer.newLine();
			writer.append("                    EUROPEAN NO");
			writer.newLine();
			writer.append("                    LMARGINS 0");
			writer.newLine();
			writer.append("                    COPIES 1");
			writer.newLine();
			writer.append("                    WAIT NO");
			writer.newLine();
			writer.append("                    MUTE YES");
			writer.newLine();
			writer.append("                    LISTINPUT NO");
			writer.newLine();
			writer.append("                    WARNING YES");
			writer.newLine();
			writer.append("                    SOLUTION YES");
			writer.newLine();
			writer.append("                    CONSTRAINTS YES");
			writer.newLine();
			writer.append("                    COSTANALYSIS NO");
			writer.newLine();
			writer.append("                    MARGINANALYSIS NO");
			writer.newLine();
			writer.append("                    MATLIST NO");
			writer.newLine();
			writer.append("                    DEFAULTS NO");

			writer.flush();
			writer.close();
			return true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * Creates the start.CMD file. This start the XA solver via the console.
	 * 
	 * @param pathToSolver
	 *            the path to folder which contains the solver
	 * @return true, if successful
	 */
	public boolean createCMDFile(String pathToSolver) {
		try {
			File cmdFile = new File(pathToSolver + "start.cmd");
			// write .CMD file
			BufferedWriter writer = new BufferedWriter(new FileWriter(cmdFile));
			
			// Begin Change (mibauer)
			String[] splitString = pathToSolver.split(":");
			writer.append(splitString[0] + ":");
			writer.newLine();
			// path with blanks also possible
			writer.append("cd " + "\"" + pathToSolver + "\"");
			writer.newLine();
			writer.append("xa solver.CLP");
			writer.newLine();
			writer.append("exit");
			writer.newLine();
			// End Change
			
			writer.flush();
			writer.close();

			return true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
}