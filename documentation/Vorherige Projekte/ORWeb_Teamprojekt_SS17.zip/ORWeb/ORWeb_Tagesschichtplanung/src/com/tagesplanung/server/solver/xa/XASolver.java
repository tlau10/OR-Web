package com.tagesplanung.server.solver.xa;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.tagesplanung.server.data.SolverInputData;
import com.tagesplanung.server.data.SolverOutputData;
import com.tagesplanung.server.solver.ISolver;
import com.tagesplanung.server.solver.MatrixBuilder;

/**
 * The Class XASolver is a concrete implementation of a solver. It implements
 * all logic needed to solve the LP problem with the XA Solver.
 */
public class XASolver implements ISolver {

	/** The path to the folder which contains the solver. */
	private final String PATH_TO_SOLVER;

	/** The solver output data to store the result in. */
	private SolverOutputData sod;

	/**
	 * Instantiates a new XA solver.
	 * 
	 * @param servletContextPath
	 *            the path to the folder which contains the solver (can be the
	 *            servlet context path)
	 */
	public XASolver(String servletContextPath) {
		PATH_TO_SOLVER = servletContextPath;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.tagesplanung.server.solver.xa.ISolver#solve(com.tagesplanung.server
	 * .data.SolverInputData, java.lang.String)
	 */
	@SuppressWarnings("static-access")
	public SolverOutputData solve(SolverInputData data, String sessionID) {
		try {
			// part of session id
			String id = sessionID.substring(0, 5);
			// create LP matrix
			MatrixBuilder matrixBuilder = new MatrixBuilder(sessionID);
			ArrayList<Integer> breakVariables = matrixBuilder.createBreakVariablesArray(data);
			int[][] matrix = matrixBuilder.buildMatrix(data, breakVariables);
			// generate XA input file & others
			XAInputCreator xaInput = new XAInputCreator(matrix, breakVariables);
			xaInput.createCMDFile(PATH_TO_SOLVER);
			xaInput.createLPFile(PATH_TO_SOLVER + "XA_" + id + ".LP", data);
			xaInput.createCLPFile(PATH_TO_SOLVER + "solver.CLP", "XA_" + id);
			// start solver

			// Begin of Change mibauer
			String startCmd = "\"" + PATH_TO_SOLVER + "\\" + "start.cmd" + "\"";
			ProcessBuilder builder = new ProcessBuilder("cmd", "/c", "start", "/WAIT", "\"Tagesschichtplanung Solver\"", startCmd);

			Process p = builder.start();
			//Wait until the process is finished
			p.waitFor();
			// End Change
			
			// create result object from solver output file
			XAOutputCreator xaOutput = new XAOutputCreator();
			sod = xaOutput.createSolution(PATH_TO_SOLVER + "XA_" + id + ".OUT");
		} catch (IOException exception) {
			Logger.getLogger(XAOutputCreator.class.getName()).log(Level.SEVERE, null, exception);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// return result
		return sod;
	}
}