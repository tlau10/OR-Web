package com.tagesplanung.shared;

import java.io.Serializable;

import com.extjs.gxt.ui.client.data.BaseModel;

// TODO: Auto-generated Javadoc
/**
 * The Class Bedarf.
 */
public class Bedarf extends BaseModel implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1705806297650013243L;

	/**
	 * Instantiates a new bedarf.
	 */
	public Bedarf() {
		super();
	}

	/**
	 * Instantiates a new bedarf.
	 * 
	 * @param startIntervall
	 *            the start intervall
	 * @param endIntervall
	 *            the end intervall
	 * @param intervall
	 *            the intervall
	 * @param intIntervall
	 *            the int intervall
	 * @param bedarf
	 *            the bedarf
	 */
	public Bedarf(String startIntervall, String endIntervall, String intervall,
			int intIntervall, int bedarf) {
		set("bedarf", bedarf);
		set("intervall", intervall);
		set("intIntervall", intIntervall);
		set("startIntervall", startIntervall);
		set("endIntervall", endIntervall);
	}

	/**
	 * Gets the bedarf.
	 * 
	 * @return the bedarf
	 */
	public int getBedarf() {
		return (Integer) get("bedarf");
	}

	/**
	 * Sets the bedarf.
	 * 
	 * @param bedarf
	 *            the new bedarf
	 */
	public void setBedarf(int bedarf) {
		set("bedarf", bedarf);
	}

	/**
	 * Gets the intervall.
	 * 
	 * @return the intervall
	 */
	public String getIntervall() {
		return (String) get("intervall");
	}

	/**
	 * Sets the intervall.
	 * 
	 * @param intervall
	 *            the new intervall
	 */
	public void setIntervall(String intervall) {
		set("intervall", intervall);
	}

	/**
	 * Gets the int intervall.
	 * 
	 * @return the int intervall
	 */
	public int getIntIntervall() {
		return (Integer) get("intIntervall");
	}

	/**
	 * Sets the int intervall.
	 * 
	 * @param intIntervall
	 *            the new int intervall
	 */
	public void setIntIntervall(int intIntervall) {
		set("intIntervall", intIntervall);
	}

	/**
	 * Gets the start intervall.
	 * 
	 * @return the start intervall
	 */
	public String getStartIntervall() {
		return (String) get("startIntervall");
	}

	/**
	 * Sets the start intervall.
	 * 
	 * @param startIntervall
	 *            the new start intervall
	 */
	public void setStartIntervall(String startIntervall) {
		set("startIntervall", startIntervall);
	}

	/**
	 * Gets the end intervall.
	 * 
	 * @return the end intervall
	 */
	public String getEndIntervall() {
		return (String) get("endIntervall");
	}

	/**
	 * Sets the end intervall.
	 * 
	 * @param endIntervall
	 *            the new end intervall
	 */
	public void setEndIntervall(String endIntervall) {
		set("endIntervall", endIntervall);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return getIntervall();
	}
}