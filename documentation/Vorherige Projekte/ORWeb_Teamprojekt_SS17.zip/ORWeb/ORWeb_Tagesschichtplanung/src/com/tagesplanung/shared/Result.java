package com.tagesplanung.shared;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class Result.
 */
public class Result implements Comparable<Result>, Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 7636426317440516269L;

	/** Rounded Solutions are marked here */
	private boolean isRounded;

	/** The shift number. */
	private int shiftNumber;

	/** The int shift start. */
	private int intShiftStart;

	/** The int shift end. */
	private int intShiftEnd;

	/** The shift start. */
	private String shiftStart;

	/** The shift end. */
	private String shiftEnd;

	/** The number of people. */
	private int numberOfPeople;

	/** The break intervall. */
	private String breakIntervall;

	/** The break intervall number. */
	private int breakIntervallNumber;

	/** The number of people in break. */
	private int numberOfPeopleInBreak;

	/**
	 * Instantiates a new result.
	 */
	public Result() {
		super();
	}

	/**
	 * Gets the break intervall number.
	 * 
	 * @return the break intervall number
	 */
	public int getBreakIntervallNumber() {
		return breakIntervallNumber;
	}

	/**
	 * Sets the break intervall number.
	 * 
	 * @param breakIntervallNumber
	 *            the new break intervall number
	 */
	public void setBreakIntervallNumber(int breakIntervallNumber) {
		this.breakIntervallNumber = breakIntervallNumber;
	}

	/**
	 * Instantiates a new result.
	 * 
	 * @param shiftNumber
	 *            the shift number
	 * @param shiftStart
	 *            the shift start
	 * @param shiftEnd
	 *            the shift end
	 * @param numberOfPeople
	 *            the number of people
	 * @param breakIntervall
	 *            the break intervall
	 * @param numberOfPeopleInBreak
	 *            the number of people in break
	 */
	public Result(int shiftNumber, String shiftStart, String shiftEnd, int numberOfPeople, String breakIntervall, int numberOfPeopleInBreak) {
		this.shiftNumber = shiftNumber;
		this.shiftStart = shiftStart;
		this.shiftEnd = shiftEnd;
		this.numberOfPeople = numberOfPeople;
		this.breakIntervall = breakIntervall;
		this.numberOfPeopleInBreak = numberOfPeopleInBreak;
	}

	/**
	 * Gets the shift number.
	 * 
	 * @return the shift number
	 */
	public int getShiftNumber() {
		return shiftNumber;
	}

	/**
	 * Sets the shift number.
	 * 
	 * @param shiftNumber
	 *            the new shift number
	 */
	public void setShiftNumber(int shiftNumber) {
		this.shiftNumber = shiftNumber;
	}

	/**
	 * Gets the shift start.
	 * 
	 * @return the shift start
	 */
	public String getShiftStart() {
		return shiftStart;
	}

	/**
	 * Sets the shift start.
	 * 
	 * @param shiftStart
	 *            the new shift start
	 */
	public void setShiftStart(String shiftStart) {
		this.shiftStart = shiftStart;
	}

	/**
	 * Gets the int shift start.
	 * 
	 * @return the int shift start
	 */
	public int getIntShiftStart() {
		return intShiftStart;
	}

	/**
	 * Sets the int shift start.
	 * 
	 * @param intShiftStart
	 *            the new int shift start
	 */
	public void setIntShiftStart(int intShiftStart) {
		this.intShiftStart = intShiftStart;
	}

	/**
	 * Gets the int shift end.
	 * 
	 * @return the int shift end
	 */
	public int getIntShiftEnd() {
		return intShiftEnd;
	}

	/**
	 * Sets the int shift end.
	 * 
	 * @param intShiftEnd
	 *            the new int shift end
	 */
	public void setIntShiftEnd(int intShiftEnd) {
		this.intShiftEnd = intShiftEnd;
	}

	/**
	 * Gets the shift end.
	 * 
	 * @return the shift end
	 */
	public String getShiftEnd() {
		return shiftEnd;
	}

	/**
	 * Sets the shift end.
	 * 
	 * @param shiftEnd
	 *            the new shift end
	 */
	public void setShiftEnd(String shiftEnd) {
		this.shiftEnd = shiftEnd;
	}

	/**
	 * Gets the number of people.
	 * 
	 * @return the number of people
	 */
	public int getNumberOfPeople() {
		return numberOfPeople;
	}

	/**
	 * Sets the number of people.
	 * 
	 * @param numberOfPeople
	 *            the new number of people
	 */
	public void setNumberOfPeople(int numberOfPeople) {
		this.numberOfPeople = numberOfPeople;
	}

	/**
	 * Gets the break intervall.
	 * 
	 * @return the break intervall
	 */
	public String getBreakIntervall() {
		return breakIntervall;
	}

	/**
	 * Sets the break intervall.
	 * 
	 * @param breakIntervall
	 *            the new break intervall
	 */
	public void setBreakIntervall(String breakIntervall) {
		this.breakIntervall = breakIntervall;
	}

	/**
	 * Gets the number of people in break.
	 * 
	 * @return the number of people in break
	 */
	public int getNumberOfPeopleInBreak() {
		return numberOfPeopleInBreak;
	}

	/**
	 * Sets the number of people in break.
	 * 
	 * @param numberOfPeopleInBreak
	 *            the new number of people in break
	 */
	public void setNumberOfPeopleInBreak(int numberOfPeopleInBreak) {
		this.numberOfPeopleInBreak = numberOfPeopleInBreak;
	}

	/**
	 * Rounded Solutions are marked here
	 * 
	 * @return Rounded Solutions Marker
	 */
	public boolean isRounded() {
		return isRounded;
	}

	/**
	 * Rounded Solutions are marked here
	 * 
	 * @param isRounded
	 *            marker for rounded
	 */
	public void setRounded(boolean isRounded) {
		this.isRounded = isRounded;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(Result o) {
		return ((Integer) intShiftStart).compareTo((Integer) o.intShiftStart);
	}
}
