package com.tagesplanung.shared;

import java.io.Serializable;

import com.extjs.gxt.ui.client.data.BaseModel;

// TODO: Auto-generated Javadoc
/**
 * The Class ShiftBaseModel.
 * 
 * @author Anton Dubs
 */
public class ShiftBaseModel extends BaseModel implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -2571996665277496920L;

	/**
	 * Instantiates a new shift base model.
	 */
	public ShiftBaseModel() {
		super();
	}

	/**
	 * Creates a new shift base model, setting all the fields.
	 * 
	 * @param nummer
	 *            the shift number / id
	 * @param start
	 *            the start time of the shift interval
	 * @param end
	 *            the end time of the shift interval
	 * @param start_pause
	 *            the start_pause is the start time of the break interval
	 * @param end_pause
	 *            the end_pause is the end time of the break interval
	 * @param bedarf
	 *            the maximal amount of persons
	 * @param praef
	 *            the popularity of a shift
	 * @param start_int
	 *            start time of a shift as an int value
	 * @param end_int
	 *            end time as of a shift an int value
	 * @param start_pause_int
	 *            the start time of a break interval as an int value
	 * @param end_pause_int
	 *            the end time of a break interval as an int value
	 * @param bedarf_int
	 *            the maxmimal amount of persons working in a shift as an int
	 *            value
	 * @param praef_double
	 *            the popularity of a shift as a double value
	 * @param delete
	 *            the boolean field (checkbox), if true the shift will be
	 *            deleted
	 */
	public ShiftBaseModel(int nummer, String start, String end,
			String start_pause, String end_pause, String bedarf, String praef,
			int start_int, int end_int, int start_pause_int, int end_pause_int,
			int bedarf_int, double praef_double, boolean delete) {
		set("nummer", nummer);
		set("start", start);
		set("end", end);
		set("start_pause", start_pause);
		set("end_pause", end_pause);
		set("bedarf", bedarf);
		set("praef", praef);
		set("start_int", start_int);
		set("end_int", end_int);
		set("start_pause_int", start_pause_int);
		set("end_pause_int", end_pause_int);
		set("praef_double", praef_double);
		set("bedarf_int", bedarf_int);
		set("delete", delete);
	}

	/**
	 * Sets the nummer.
	 * 
	 * @param nummer
	 *            the new number / id
	 */
	public void setNummer(int nummer) {
		set("nummer", nummer);
	}

	/**
	 * Sets the start time of the shift
	 * 
	 * @param start
	 *            the new start time
	 */
	public void setStart(String start) {
		set("start", start);
	}

	/**
	 * Sets the end time of the shigt
	 * 
	 * @param end
	 *            the new end time
	 */
	public void setEnd(String end) {
		set("end", end);
	}

	/**
	 * Sets the start pause.
	 * 
	 * @param start_pause
	 *            the new start pause
	 */
	public void setStartPause(String start_pause) {
		set("start_pause", start_pause);
	}

	/**
	 * Sets the end pause.
	 * 
	 * @param end_pause
	 *            the new end pause
	 */
	public void setEndPause(String end_pause) {
		set("end_pause", end_pause);
	}

	/**
	 * Sets the bedarf.
	 * 
	 * @param bedarf
	 *            the new bedarf
	 */
	public void setBedarf(String bedarf) {
		set("bedarf", bedarf);
	}

	/**
	 * Sets the bedarf int.
	 * 
	 * @param bedarf_int
	 *            the new bedarf int
	 */
	public void setBedarfInt(int bedarf_int) {
		set("bedarf_int", bedarf_int);
	}

	/**
	 * Sets the start int.
	 * 
	 * @param start_int
	 *            the new start int
	 */
	public void setStartInt(int start_int) {
		set("start_int", start_int);
	}

	/**
	 * Sets the end int.
	 * 
	 * @param end_int
	 *            the new end int
	 */
	public void setEndInt(int end_int) {
		set("end_int", end_int);
	}

	/**
	 * Sets the start pause int.
	 * 
	 * @param start_pause_int
	 *            the new start pause int
	 */
	public void setStartPauseInt(int start_pause_int) {
		set("start_pause_int", start_pause_int);
	}

	/**
	 * Sets the end pause int.
	 * 
	 * @param end_pause_int
	 *            the new end pause int
	 */
	public void setEndPauseInt(int end_pause_int) {
		set("end_pause_int", end_pause_int);
	}

	/**
	 * Sets the praef double.
	 * 
	 * @param praef_double
	 *            the new praef double
	 */
	public void setPraefDouble(double praef_double) {
		set("praef_double", praef_double);
	}

	/**
	 * Sets the praef.
	 * 
	 * @param praef
	 *            the new praef
	 */
	public void setPraef(String praef) {
		set("praef", praef);
	}

	/**
	 * Sets the delete.
	 * 
	 * @param delete
	 *            the new delete
	 */
	public void setDelete(boolean delete) {
		set("delete", delete);
	}

	/**
	 * Gets the delete.
	 * 
	 * @return the delete
	 */
	public boolean getDelete() {
		return (Boolean) get("delete");
	}

	/**
	 * Gets the nummer.
	 * 
	 * @return the nummer
	 */
	public int getNummer() {
		return (Integer) get("nummer");
	}

	/**
	 * Gets the start.
	 * 
	 * @return the start
	 */
	public String getStart() {
		return (String) get("start");
	}

	/**
	 * Gets the end.
	 * 
	 * @return the end
	 */
	public String getEnd() {
		return (String) get("end");
	}

	/**
	 * Gets the start pause.
	 * 
	 * @return the start pause
	 */
	public String getStartPause() {
		return (String) get("start_pause");
	}

	/**
	 * Gets the end pause.
	 * 
	 * @return the end pause
	 */
	public String getEndPause() {
		return (String) get("end_pause");
	}

	/**
	 * Gets the bedarf.
	 * 
	 * @return the bedarf
	 */
	public String getBedarf() {
		return (String) get("bedarf");
	}

	/**
	 * Gets the bedarf int.
	 * 
	 * @return the bedarf int
	 */
	public int getBedarfInt() {
		return (Integer) get("bedarf_int");
	}

	/**
	 * Gets the start int.
	 * 
	 * @return the start int
	 */
	public int getStartInt() {
		return (Integer) get("start_int");
	}

	/**
	 * Gets the end int.
	 * 
	 * @return the end int
	 */
	public int getEndInt() {
		return (Integer) get("end_int");
	}

	/**
	 * Gets the start pause int.
	 * 
	 * @return the start pause int
	 */
	public int getStartPauseInt() {
		return (Integer) get("start_pause_int");
	}

	/**
	 * Gets the end pause int.
	 * 
	 * @return the end pause int
	 */
	public int getEndPauseInt() {
		return (Integer) get("end_pause_int");
	}

	/**
	 * Gets the praef double.
	 * 
	 * @return the praef double
	 */
	public double getPraefDouble() {
		return (Double) get("praef_double");
	}

	/**
	 * Gets the praef.
	 * 
	 * @return the praef
	 */
	public String getPraef() {
		return (String) get("praef");
	}

	/**
	 * Convert to double. Converts the time-strings to double values. e.g. 23:30
	 * = 23.5
	 * 
	 * @param value
	 *            the time-string
	 * @return the double value
	 */
	public double convertToDouble(String value) {
		if (value.charAt(0) == '0') {
			if (value.charAt(3) == '0') {
				return Double.parseDouble(value.substring(1, 2));
			} else {
				return Double.parseDouble(value.substring(1, 2)) + 0.5;
			}
		}
		if (value.charAt(3) == '0') {
			return Double.parseDouble(value.substring(0, 2));
		} else {
			return Double.parseDouble(value.substring(0, 2)) + 0.5;
		}
	}

	/**
	 * Sets the intervalls.
	 * 
	 * @param start
	 *            the start
	 * @param end
	 *            the end
	 * @param start_pause
	 *            the start_pause
	 * @param end_pause
	 *            the end_pause
	 */
	public void setIntervalls(String start, String end, String start_pause,
			String end_pause) {
		double start_double = this.convertToDouble(start);
		double end_double = this.convertToDouble(end);
		double start_pause_double = this.convertToDouble(start_pause);
		double end_pause_double = this.convertToDouble(end_pause);
		this.setStartInt((int) (start_double * 2 + 1));
		if (end_double == 24.0) {
			end_double = 0.0;
		}
		this.setEndInt((int) (end_double * 2 + 1));
		this.setStartPauseInt((int) (start_pause_double * 2 + 1));
		if (end_pause_double == 24.0) {
			end_pause_double = 0.0;
		}
		this.setEndPauseInt((int) (end_pause_double * 2 + 1));
	}

	/**
	 * Sets the praef integer. Sets the double Zielfunktionswert for a shift.
	 * 
	 * @param praef
	 *            the new praef integer
	 */
	public void setPraefInteger(String praef) {
		int v = Integer.parseInt(praef);
		double zielfunktionswert = 1.0;
		switch (v) {
		case -5:
			zielfunktionswert = 1.5;
			break;
		case -4:
			zielfunktionswert = 1.4;
			break;
		case -3:
			zielfunktionswert = 1.3;
			break;
		case -2:
			zielfunktionswert = 1.2;
			break;
		case -1:
			zielfunktionswert = 1.1;
			break;
		case 0:
			zielfunktionswert = 1.0;
			break;
		case 1:
			zielfunktionswert = 0.9;
			break;
		case 2:
			zielfunktionswert = 0.8;
			break;
		case 3:
			zielfunktionswert = 0.7;
			break;
		case 4:
			zielfunktionswert = 0.6;
			break;
		case 5:
			zielfunktionswert = 0.5;
			break;
		}
		this.setPraefDouble(zielfunktionswert);
	}
}