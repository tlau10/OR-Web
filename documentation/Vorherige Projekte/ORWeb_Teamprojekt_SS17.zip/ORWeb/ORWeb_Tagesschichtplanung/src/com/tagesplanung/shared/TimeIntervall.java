package com.tagesplanung.shared;

import java.util.ArrayList;
import java.util.List;

// TODO: Auto-generated Javadoc
public enum TimeIntervall { 

	Intervall_0_00h("0:00","0:30",1,true), Intervall_0_30h("0:30","1:00",2,true), Intervall_1_00h("1:00","1:30",3,true),
	Intervall_1_30h("1:30","2:00",4,true), Intervall_2_00h("2:00","2:30",5,true), Intervall_2_30h("2:30","3:00",6,true),
	Intervall_3_00h("3:00","3:30",7,true), Intervall_3_30h("3:30","4:00",8,true), Intervall_4_00h("4:00","4:30",9,true),
	Intervall_4_30h("4:30","5:00",10,true), Intervall_5_00h("5:00","5:30",11,true), Intervall_5_30h("5:30","6:00",12,true),
	Intervall_6_00h("6:00","6:30",13,true), Intervall_6_30h("6:30","7:00",14,true), Intervall_7_00h("7:30","7:30",15,true),
	Intervall_7_30h("7:30","8:00",16,true), Intervall_8_00h("8:00","8:30",17,true), Intervall_8_30h("8:30","9:00",18,true),
	Intervall_9_00h("9:00","9:30",19,true), Intervall_9_30h("9:30","10:00",20,true), Intervall_10_00h("10:00","10:30",21,true),
	Intervall_10_30h("10:30","11:00",22,true), Intervall_11_00h("11:00","11:30",23,true), Intervall_11_30h("11:30","12:00",24,true),
	Intervall_12_00h("12:00","12:30",25,true), Intervall_12_30h("12:30","13:00",26,true), Intervall_13_00h("13:00","13:30",27,true),
	Intervall_13_30h("13:30","14:00",28,true), Intervall_14_00h("14:00","14:30",29,true), Intervall_14_30h("14:30","15:00",30,true),
	Intervall_15_00h("15:00","15:30",31,true), Intervall_15_30h("15:30","16:00",32,true), Intervall_16_00h("16:00","16:30",33,true),
	Intervall_16_30h("16:30","17:00",34,true), Intervall_17_00h("17:00","17:30",35,true), Intervall_17_30h("17:30","18:00",36,true),
	Intervall_18_00h("18:00","18:30",37,true), Intervall_18_30h("18:30","19:00",38,true), Intervall_19_00h("19:00","19:30",39,true),
	Intervall_19_30h("19:30","20:00",40,true), Intervall_20_00h("20:00","20:30",41,true), Intervall_20_30h("20:30","21:00",42,true),
	Intervall_21_00h("21:00","21:30",43,true), Intervall_21_30h("21:30","22:00",44,true), Intervall_22_00h("22:00","22:30",45,true),
	Intervall_22_30h("22:30","23:00",46,true), Intervall_23_00h("23:00","23:30",47,true), Intervall_23_30h("23:30","0:00",48,true),
		
	Intervall_0_00f("0:00","1:00",1,false), Intervall_1_00f("1:00","2:00",2,false), Intervall_2_00f("2:00","3:00",3,false),
	Intervall_3_00f("3:00","4:00",4,false), Intervall_4_00f("4:00","5:00",5,false), Intervall_5_00f("5:00","6:00",6,false),
	Intervall_6_00f("6:00","7:00",7,false), Intervall_7_00f("7:00","8:00",8,false), Intervall_8_00f("8:00","9:00",9,false),
	Intervall_9_00f("9:00","10:00",10,false), Intervall_10_00f("10:00","11:00",11,false), Intervall_11_00f("11:00","12:00",12,false),
	Intervall_12_00f("12:00","13:00",13,false), Intervall_13_00f("13:00","14:00",14,false), Intervall_14_00f("14:00","15:00",15,false),
	Intervall_15_00f("15:00","16:00",16,false), Intervall_16_00f("16:00","17:00",17,false), Intervall_17_00f("17:00","18:00",18,false),
	Intervall_18_00f("18:00","19:00",19,false), Intervall_19_00f("19:00","20:00",20,false), Intervall_20_00f("20:00","21:00",21,false),
	Intervall_21_00f("21:00","22:00",22,false), Intervall_22_00f("22:00","23:00",23,false), Intervall_23_00f("23:00","0:00",24,false); 
	
	private String startIntervall;
	private String endIntervall;
	private int intIntervall;
	private String intervall;
	private boolean halfHour;
	
	/**
	 * Instantiates a new time intervall.
	 *
	 * @param startIntervall the start intervall
	 * @param endIntervall the end intervall
	 * @param intIntervall the int intervall
	 * @param halfHour the half hour
	 */
	private TimeIntervall(String startIntervall,String endIntervall,int intIntervall, boolean halfHour){
		this.startIntervall = startIntervall;
		this.endIntervall = endIntervall;
		this.intIntervall = intIntervall;
		this.intervall = startIntervall+"-"+endIntervall;
		this.halfHour = halfHour;
	}
	
	/**
	 * Gets the start intervall.
	 *
	 * @return the start intervall
	 */
	public String getStartIntervall(){
		return startIntervall;
	}
	
	/**
	 * Gets the end intervall.
	 *
	 * @return the end intervall
	 */
	public String getEndIntervall(){
		return endIntervall;
	}
	
	/**
	 * Gets the int intervall.
	 *
	 * @return the int intervall
	 */
	public int getIntIntervall(){
		return intIntervall;
	}
	
	/**
	 * Gets the intervall.
	 *
	 * @return the intervall
	 */
	public String getIntervall(){
		return intervall;
	}
	
	/**
	 * Gets the type intervall.
	 *
	 * @return the type intervall
	 */
	private boolean getTypeIntervall(){
		return halfHour;
	}
	
	/**
	 * Gets the full intervalls.
	 *
	 * @return the full intervalls
	 */
	public static List<TimeIntervall> getFullIntervalls(){
		List<TimeIntervall> timeIntervall = new ArrayList<TimeIntervall>();	
		for (TimeIntervall t: TimeIntervall.values()){
			if(t.getTypeIntervall()== false){
				timeIntervall.add(t);
			}
		}
		return timeIntervall;
	}
	
	/**
	 * Gets the half intervalls.
	 *
	 * @return the half intervalls
	 */
	public static List<TimeIntervall> getHalfIntervalls(){
		List<TimeIntervall> timeIntervall = new ArrayList<TimeIntervall>();			
		for (TimeIntervall t: TimeIntervall.values()){
			if(t.getTypeIntervall()== true){
				timeIntervall.add(t);
			}
		}
		return timeIntervall;		
	}
	
	/**
	 * Gets the intervallby number.
	 *
	 * @param number the number
	 * @return the intervallby number
	 */
	public static String getIntervallbyNumber(int number){
		for (TimeIntervall t: TimeIntervall.values()){
			if(t.getIntIntervall()== number){
				return t.getIntervall();
			}
		}
		return "";
	}
}