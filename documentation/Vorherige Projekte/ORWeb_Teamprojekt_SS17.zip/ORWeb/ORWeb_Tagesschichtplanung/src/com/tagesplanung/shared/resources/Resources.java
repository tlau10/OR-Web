package com.tagesplanung.shared.resources;


import com.google.gwt.core.client.GWT;

// TODO: Auto-generated Javadoc
/**
 * The Class Resources.
 */
public class Resources {
	
	/** The Constant ICONS. */
	public static final MyIcons ICONS = GWT.create(MyIcons.class);
}