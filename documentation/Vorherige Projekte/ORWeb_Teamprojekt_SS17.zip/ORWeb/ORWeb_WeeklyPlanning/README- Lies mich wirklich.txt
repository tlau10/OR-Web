1. Um das Beispiel zu starten, erstmal das File build.properties anpassen.
2. Im Tomcatverzeichnis\conf das File tomcat-users.xml um folgende xml eintr�ge erweitern.
	<role rolename="admin"/>
	<role rolename="user"/>
  	<user username="admin1" password="password" roles="user,admin"/>
  	<user username="user1" password="password" roles="user"/>
3. Ant ausf�hren:
	Rechtsclick auf build.xml und Run As Ant build
	(Erstellt die Datei schichtplanung.war und kopiert sie ins webapps Verzeichnis -> damit ist die Anwendung deployt)
4. Tomcat starten:
	Am besten mit dem Batchskript startup.bat aus dem Verzeichnis Tomcatverzeichnis\bin
	Das starten von Eclipse heraus hat bei mir das Problem, da� die �nderungen an der Datei tomcat-users.xml nicht beachtet werden.
5. Die Anwendung ist nun unter 
	http://localhost:8080/schichtplanung/
	erreichbar.
	
6. Zum beenden von Tomcat das Batchskript shutdown.bat aus dem Verzeichnis Tomcatverzeichnis\bin verwenden

Hat man etwas neues gehackt, kann man bei laufendem Server Schritt 3 ausf�hren und innerhalb weniger Sekunden steht die neue Funktionalit�t zum testen bereit.

Click Quick Start Application
=============================

The structure of this web application is detailed below:

 +---[lib]                  Build time JAR libs directory
 |
 +---[src]                  Java source files directory
 |
 +---[webapp]               Web application root directory
 |    |
 |    +---[admin]           Admin role pages directory 
 |    |
 |    +---[assets]          Web static assets directory 
 |    |    
 |    +---[META-INF]        Tomcat context.xml directory
 |    |
 |    +---[user]            User role pages directory 
 |    |
 |    +---[WEB-INF]         Protected Web Inf directory
 |         |
 |         +---[classes]    Compile classes output directory
 |         |
 |         +---click.xml    Click configuration file
 |         |
 |         +---menu.xml     Menu configuration file
 |         |
 |         +---web.xml      Web configuration file
 |
 +---build.xml              Ant build script file
 |
 +---README.txt             Read Me description file


To build the application WAR file using the Ant command:

    ant build
