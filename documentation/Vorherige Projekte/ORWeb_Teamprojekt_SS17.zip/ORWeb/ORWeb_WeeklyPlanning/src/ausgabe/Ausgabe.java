/**
 * 
 */
package ausgabe;

import schichtmuster.Schichtfolge;

/** 
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @author drossman
 * 
 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class Ausgabe {

	
	public Ausgabe(Integer anzahlSchichtfolgen, Schichtfolge schichtfolge) {
		super();
		this.anzahlSchichtfolgen = anzahlSchichtfolgen;
		this.schichtfolge = schichtfolge;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated   "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Integer anzahlSchichtfolgen;

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return anzahlSchichtfolgen
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Integer getAnzahlSchichtfolgen() {
		// begin-user-code
		return anzahlSchichtfolgen;
		// end-user-code
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param dededsnalcihfle Festzulegender anzahlSchichtfolgen
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setAnzahlSchichtfolgen(Integer dededsnalcihfle) {
		// begin-user-code
		anzahlSchichtfolgen = dededsnalcihfle;
		// end-user-code
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Schichtfolge schichtfolge;

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return schichtfolge
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Schichtfolge getSchichtfolge() {
		// begin-user-code
		return schichtfolge;
		// end-user-code
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param dededscihfle Festzulegender schichtfolge
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setSchichtfolge(Schichtfolge dededscihfle) {
		// begin-user-code
		schichtfolge = dededscihfle;
		// end-user-code
	}
	
	@Override
	public String toString() {
	StringBuffer buffer = new StringBuffer("Ausgabe\n");
	buffer.append("anzahl "+this.anzahlSchichtfolgen+"\n");
	buffer.append(schichtfolge);
	return buffer.toString();
	}
}