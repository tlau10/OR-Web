/**
 * 
 */
package ausgabe;

import java.util.ArrayList;

/** 
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @author drossman
 * 
 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class Schichtplan {
	public Schichtplan() {
		super();
		ausgabe = new ArrayList<Ausgabe>();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated  "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private ArrayList<Ausgabe> ausgabe;

	public void addAusgabe(Ausgabe eineAusgabe){
		ausgabe.add(eineAusgabe);
	}
	
	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return ausgabe
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public ArrayList<Ausgabe> getAusgabe() {
		// begin-user-code
		return ausgabe;
		// end-user-code
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param dededsugb Festzulegender ausgabe
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setAusgabe(ArrayList<Ausgabe> dededsugb) {
		// begin-user-code
		ausgabe = dededsugb;
		// end-user-code
	}
	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer("Schichtplan\n");
		for(Ausgabe ausgab:ausgabe){
			buffer.append(ausgab);
		}
		return buffer.toString();
	}
}