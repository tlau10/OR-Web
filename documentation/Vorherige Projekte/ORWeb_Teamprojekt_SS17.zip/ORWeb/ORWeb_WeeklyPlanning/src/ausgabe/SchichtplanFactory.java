/**
 * 
 */
package ausgabe;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * <!-- begin-user-doc --> <!-- end-user-doc -->
 * 
 * @author drossman
 * 
 * @generated "UML in Java
 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class SchichtplanFactory {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param fileName
	 * @param schichtplan
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void saveToFile(String fileName, Schichtplan schichtplan) {
		// begin-user-code
		try {
			saveSchichtplan(schichtplan, new BufferedOutputStream(
					new FileOutputStream(fileName)));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// end-user-code
	}

	public static void saveSchichtplan(Schichtplan schichtplan, OutputStream out) {
		XMLEncoder encoder = new XMLEncoder(out);
		encoder.writeObject(schichtplan);
		encoder.close();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param filename
	 * @return
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Schichtplan loadFromFile(String filename) {
		// begin-user-code
		Schichtplan schichtplan = null;
		try {
			schichtplan = loadSchichtplan(new BufferedInputStream(
					new FileInputStream(filename)));

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return schichtplan;
		// end-user-code
	}

	public static Schichtplan loadSchichtplan(InputStream input) {
		java.beans.XMLDecoder decoder = new XMLDecoder(input);
		Schichtplan schichtplan = (Schichtplan) decoder.readObject();
		decoder.close();
		return schichtplan;
	}
}