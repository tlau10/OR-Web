/**
 * 
 */
package bedarf;

import java.util.ArrayList;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;

/**
 * <!-- begin-user-doc --> <!-- end-user-doc -->
 * 
 * @author drossman
 * 
 * @generated "UML in Java
 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class Bedarf {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private HashMap<GregorianCalendar, TagesBedarf> bedarf;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return bedarf
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public HashMap<GregorianCalendar, TagesBedarf> getBedarf() {
		// begin-user-code
		return bedarf;
		// end-user-code
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param dededseaf
	 *            Festzulegender bedarf
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setBedarf(HashMap<GregorianCalendar, TagesBedarf> dededseaf) {
		// begin-user-code
		bedarf = dededseaf;
		// end-user-code
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private GregorianCalendar startZeitpunkt;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return startZeitpunkt
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public GregorianCalendar getStartZeitpunkt() {
		// begin-user-code
		return startZeitpunkt;
		// end-user-code
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param dededstrZipnt
	 *            Festzulegender startZeitpunkt
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setStartZeitpunkt(GregorianCalendar dededstrZipnt) {
		// begin-user-code
		startZeitpunkt = dededstrZipnt;
		// end-user-code
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private GregorianCalendar endZeitpunkt;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return endZeitpunkt
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public GregorianCalendar getEndZeitpunkt() {
		// begin-user-code
		return endZeitpunkt;
		// end-user-code
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param dededsnZipnt
	 *            Festzulegender endZeitpunkt
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setEndZeitpunkt(GregorianCalendar dededsnZipnt) {
		// begin-user-code
		endZeitpunkt = dededsnZipnt;
		// end-user-code
	}

	public Bedarf(GregorianCalendar startZeitpunkt,
			GregorianCalendar endZeitpunkt) {
		super();
		this.startZeitpunkt = startZeitpunkt;
		this.endZeitpunkt = endZeitpunkt;
	}

	public Bedarf() {
		super();
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Start " + startZeitpunkt.getTime() + "\n");
		builder.append("Ende " + endZeitpunkt.getTime() + "\n");
		List<TagesBedarf> liste = new ArrayList<TagesBedarf>(bedarf.values());
		Collections.sort(liste);
		for (TagesBedarf tagesBedarf : liste) {
			builder.append(tagesBedarf + "\n");
		}
		return builder.toString();
	}
}