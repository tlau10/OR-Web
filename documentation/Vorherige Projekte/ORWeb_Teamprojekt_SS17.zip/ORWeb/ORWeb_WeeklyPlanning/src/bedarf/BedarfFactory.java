/**
 * 
 */
package bedarf;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.GregorianCalendar;
import java.util.HashMap;

import org.exolab.castor.mapping.Mapping;
import org.exolab.castor.mapping.MappingException;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;

import schichtmuster.Schicht;

/**
 * <!-- begin-user-doc --> <!-- end-user-doc -->
 * 
 * @author drossman
 * 
 * @generated "UML in Java
 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class BedarfFactory {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param start
	 * @param ende
	 * @return
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform
	 *            )"
	 */
	public static Bedarf getRandomBedarf(GregorianCalendar start, GregorianCalendar ende) {
		Bedarf bedarf = getKonstanterBedarf(start, ende, (int) (Math.random() * 50), (int) (Math.random() * 50), (int) (Math.random() * 50));

		for (int i = 0; i < 10000; i++) {
			GregorianCalendar calendar = (GregorianCalendar) bedarf.getStartZeitpunkt().clone();
			calendar.add(GregorianCalendar.DAY_OF_YEAR, (int) (Math.random() * 2000));
			if (calendar.before(bedarf.getEndZeitpunkt())) {
				int j = (int) (Math.random() * 3);
				if (j == 1) {
					bedarf = changeBedarf(calendar, Schicht.FRUEHSCHICHT, (int) (Math.random() * 30), bedarf);
				}
				if (j == 2) {
					bedarf = changeBedarf(calendar, Schicht.SPAETSCHICHT, (int) (Math.random() * 30), bedarf);
				} else {
					bedarf = changeBedarf(calendar, Schicht.NACHTSCHICHT, (int) (Math.random() * 30), bedarf);
				}

			}
		}
		return bedarf;
		// end-user-code
	}

	public static Bedarf setBedarfsZeitraumAlleSchichten(GregorianCalendar start, GregorianCalendar end, int bedarfAnzahl, Bedarf bedarf,
			int wochentag) {
		for (Schicht schicht : SCHICHTEN)
			bedarf = setBedarfsZeitraum(start, end, schicht, bedarfAnzahl, bedarf, wochentag);

		return bedarf;
	}

	private static final Schicht[] SCHICHTEN = new Schicht[] { Schicht.FRUEHSCHICHT, Schicht.SPAETSCHICHT, Schicht.NACHTSCHICHT };
	private static final Integer[] WOCHENTAGE = new Integer[] { GregorianCalendar.MONDAY, GregorianCalendar.TUESDAY,
			GregorianCalendar.WEDNESDAY, GregorianCalendar.THURSDAY, GregorianCalendar.FRIDAY, GregorianCalendar.SATURDAY,
			GregorianCalendar.SUNDAY };

	public static Bedarf setBedarfsZeitraumAlleTage(GregorianCalendar start, GregorianCalendar end, Schicht schicht, int bedarfAnzahl,
			Bedarf bedarf) {
		for (int wochentag : WOCHENTAGE) {
			bedarf = setBedarfsZeitraum(start, end, schicht, bedarfAnzahl, bedarf, wochentag);
		}
		return bedarf;
	}

	public static Bedarf setBedarfsZeitraumAlleSchichtenAlleTage(GregorianCalendar start, GregorianCalendar end, int bedarfAnzahl,
			Bedarf bedarf) {
		for (int wochentag : WOCHENTAGE) {
			for (Schicht schicht : SCHICHTEN) {
				bedarf = setBedarfsZeitraum(start, end, schicht, bedarfAnzahl, bedarf, wochentag);
			}
		}
		return bedarf;
	}

	// TODO String schicht in Schicht schicht ändern. GC Wochentag
	public static Bedarf setBedarfsZeitraum(GregorianCalendar start, GregorianCalendar end, Schicht schicht, int bedarfAnzahl,
			Bedarf bedarf, int wochentag) {

		for (TagesBedarf tagesBedarf : bedarf.getBedarf().values()) {
			if (!tagesBedarf.getDatum().before(start) && !tagesBedarf.getDatum().after(end)) {

				if (tagesBedarf.getDatum().get(GregorianCalendar.DAY_OF_WEEK) == wochentag) {
					if (schicht.equals(Schicht.FRUEHSCHICHT)) {
						bedarf = changeBedarf(tagesBedarf.getDatum(), Schicht.FRUEHSCHICHT, bedarfAnzahl, bedarf);
					}
					if (schicht.equals(Schicht.SPAETSCHICHT)) {

						bedarf = changeBedarf(tagesBedarf.getDatum(), Schicht.SPAETSCHICHT, bedarfAnzahl, bedarf);
					}
					if (schicht.equals(Schicht.NACHTSCHICHT)) {
						bedarf = changeBedarf(tagesBedarf.getDatum(), Schicht.NACHTSCHICHT, bedarfAnzahl, bedarf);
					}

				}
			}

		}

		return bedarf;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param start
	 * @param ende
	 * @param frueh
	 * @param nacht
	 * @param spaet
	 * @return
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform
	 *            )"
	 */
	public static Bedarf getKonstanterBedarf(GregorianCalendar start, GregorianCalendar ende, Integer frueh, Integer spaet, Integer nacht) {
		// begin-user-code
		Bedarf bedarf = new Bedarf(start, ende);
		GregorianCalendar current = (GregorianCalendar) start.clone();
		HashMap<GregorianCalendar, TagesBedarf> mapTagesbedarf = new HashMap<GregorianCalendar, TagesBedarf>();
		while (!current.after(ende)) {

			TagesBedarf tagesBedarf = new TagesBedarf();
			tagesBedarf.setDatum((GregorianCalendar) current.clone());
			tagesBedarf.setBedarfFrueh(new SchichtBedarf(frueh));
			tagesBedarf.setBedarfSpaet(new SchichtBedarf(spaet));
			tagesBedarf.setBedarfNacht(new SchichtBedarf(nacht));
			mapTagesbedarf.put(tagesBedarf.getDatum(), tagesBedarf);
			current.add(GregorianCalendar.DAY_OF_YEAR, 1);
		}
		bedarf.setBedarf(mapTagesbedarf);

		return bedarf;
		// end-user-code
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param start
	 * @param ende
	 * @param fruehWT
	 * @param nachtWT
	 * @param spaetWT
	 * @param fruehWE
	 * @param nachtWE
	 * @param spaetWE
	 * @return
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform
	 *            )"
	 */
	public static Bedarf getATWEBedarf(GregorianCalendar start, GregorianCalendar ende, Integer fruehWT, Integer spaetWT, Integer nachtWT,
			Integer fruehWE, Integer spaetWE, Integer nachtWE) {
		// begin-user-code
		Bedarf bedarf = new Bedarf(start, ende);
		GregorianCalendar current = (GregorianCalendar) start.clone();
		HashMap<GregorianCalendar, TagesBedarf> mapTagesbedarf = new HashMap<GregorianCalendar, TagesBedarf>();
		while (!current.after(ende)) {
			TagesBedarf tagesBedarf = new TagesBedarf();
			if (current.get(GregorianCalendar.DAY_OF_WEEK) > 1 && current.get(GregorianCalendar.DAY_OF_WEEK) < 7) {
				tagesBedarf.setBedarfFrueh(new SchichtBedarf(fruehWT));
				tagesBedarf.setBedarfSpaet(new SchichtBedarf(spaetWT));
				tagesBedarf.setBedarfNacht(new SchichtBedarf(nachtWT));
			} else {
				tagesBedarf.setBedarfFrueh(new SchichtBedarf(fruehWE));
				tagesBedarf.setBedarfSpaet(new SchichtBedarf(spaetWE));
				tagesBedarf.setBedarfNacht(new SchichtBedarf(nachtWE));
			}
			tagesBedarf.setDatum((GregorianCalendar) current.clone());
			mapTagesbedarf.put(tagesBedarf.getDatum(), tagesBedarf);
			current.add(GregorianCalendar.DAY_OF_YEAR, 1);
		}
		bedarf.setBedarf(mapTagesbedarf);

		return bedarf;
		// end-user-code
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param datum
	 * @param schicht
	 * @param neueAnzahl
	 * @param bedarf
	 * @return
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform
	 *            )"
	 */

	public static Bedarf changeBedarf(GregorianCalendar datum, Schicht schicht, Integer neueAnzahl, Bedarf bedarf) {
		// begin-user-code
		switch (schicht) {
		case FRUEHSCHICHT:
			bedarf.getBedarf().get(datum).getBedarfFrueh().setAnzahlPersonen(neueAnzahl);
			break;
		case SPAETSCHICHT:
			bedarf.getBedarf().get(datum).getBedarfSpaet().setAnzahlPersonen(neueAnzahl);
			break;
		case NACHTSCHICHT:
			bedarf.getBedarf().get(datum).getBedarfNacht().setAnzahlPersonen(neueAnzahl);
			break;

		default:
			break;
		}

		return bedarf;
		// end-user-code
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param bedarf
	 * @param fileName
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform
	 *            )"
	 */
	public static void saveBedarf(Bedarf bedarf, String fileName) {
		// begin-user-code
		try {
			saveBedarf(bedarf, new BufferedOutputStream(new FileOutputStream(fileName)));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		// end-user-code
	}

	public static void saveBedarf(Bedarf bedarf, OutputStream out) {
		PrintWriter writer = new PrintWriter(out);
		try {
			Marshaller marshaller = new Marshaller();
			marshaller.setWriter(writer);
			Mapping mapping = new Mapping();
			mapping.loadMapping(BedarfFactory.class.getResource("mapping.xml"));
			marshaller.setMapping(mapping);
			marshaller.marshal(bedarf);
		} catch (MarshalException e) {
			e.printStackTrace();
		} catch (ValidationException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (MappingException e) {
			e.printStackTrace();
		}
		writer.flush();
		writer.close();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param fileName
	 * @return
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform
	 *            )"
	 */
	public static Bedarf loadBedarf(String fileName) {
		// begin-user-code
		Bedarf bedarf = null;
		try {
			bedarf = loadBedarf(new BufferedInputStream(new FileInputStream(fileName)));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		return bedarf;
	}

	public static Bedarf loadBedarf(InputStream inputStream) {
		Bedarf bedarf = null;
		Unmarshaller unmarshaller = new Unmarshaller(Bedarf.class);
		Mapping mapping = new Mapping();
		try {
			mapping.loadMapping(BedarfFactory.class.getResource("mapping.xml"));
			unmarshaller.setMapping(mapping);
			bedarf = (Bedarf) unmarshaller.unmarshal(new InputStreamReader(inputStream));
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (MappingException e1) {
			e1.printStackTrace();
		} catch (MarshalException e) {
			e.printStackTrace();
		} catch (ValidationException e) {
			e.printStackTrace();
		}

		try {
			inputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return bedarf;
	}
}