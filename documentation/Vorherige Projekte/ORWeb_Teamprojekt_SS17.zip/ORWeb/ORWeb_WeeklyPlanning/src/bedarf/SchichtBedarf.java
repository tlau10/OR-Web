/**
 * 
 */
package bedarf;

/** 
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @author drossman
 * 
 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class SchichtBedarf {
	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Integer anzahlPersonen;

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return anzahlPersonen
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Integer getAnzahlPersonen() {
		// begin-user-code
		return anzahlPersonen;
		// end-user-code
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param dededsnalesnn Festzulegender anzahlPersonen
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setAnzahlPersonen(Integer dededsnalesnn) {
		// begin-user-code
		anzahlPersonen = dededsnalesnn;
		// end-user-code
	}

	public SchichtBedarf(Integer anzahlPersonen) {
		super();
		this.anzahlPersonen = anzahlPersonen;
	}
	
	public SchichtBedarf(){
		super();
	}

	@Override
	public String toString() {
		// TODO Automatisch erstellter Methoden-Stub
		StringBuilder builder = new StringBuilder();
		builder.append(anzahlPersonen);
		return builder.toString();
	}
}