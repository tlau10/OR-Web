/**
 * 
 */
package bedarf;

import java.util.GregorianCalendar;

/**
 * <!-- begin-user-doc --> <!-- end-user-doc -->
 * 
 * @author drossman
 * 
 * @generated "UML in Java
 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class TagesBedarf implements Comparable {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private SchichtBedarf bedarfSpaet;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return bedarfSpaet
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public SchichtBedarf getBedarfSpaet() {
		// begin-user-code
		return bedarfSpaet;
		// end-user-code
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param dededseafpe
	 *            Festzulegender bedarfSpaet
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setBedarfSpaet(SchichtBedarf dededseafpe) {
		// begin-user-code
		bedarfSpaet = dededseafpe;
		// end-user-code
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private SchichtBedarf bedarfNacht;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return bedarfNacht
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public SchichtBedarf getBedarfNacht() {
		// begin-user-code
		return bedarfNacht;
		// end-user-code
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param dededseafah
	 *            Festzulegender bedarfNacht
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setBedarfNacht(SchichtBedarf dededseafah) {
		// begin-user-code
		bedarfNacht = dededseafah;
		// end-user-code
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private SchichtBedarf bedarfFrueh;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return bedarfFrueh
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public SchichtBedarf getBedarfFrueh() {
		// begin-user-code
		return bedarfFrueh;
		// end-user-code
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param dededseafre
	 *            Festzulegender bedarfFrueh
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setBedarfFrueh(SchichtBedarf dededseafre) {
		// begin-user-code
		bedarfFrueh = dededseafre;
		// end-user-code
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private GregorianCalendar datum;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return datum
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public GregorianCalendar getDatum() {
		// begin-user-code
		return datum;
		// end-user-code
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param dededsau
	 *            Festzulegender datum
	 * @generated "UML in Java
	 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setDatum(GregorianCalendar dededsau) {
		// begin-user-code
		datum = dededsau;
		// end-user-code
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(datum.getTime() + "\t" + bedarfFrueh + "\t"
				+ bedarfSpaet + "\t" + bedarfNacht);
		return builder.toString();
	}

	public int compareTo(Object o) {
		if (TagesBedarf.class.isInstance(o)) {
			if (this.getDatum().after(((TagesBedarf) o).getDatum())) {
				return 1;
			} else {
				return -1;
			}
		}
		return 0;
	}
}