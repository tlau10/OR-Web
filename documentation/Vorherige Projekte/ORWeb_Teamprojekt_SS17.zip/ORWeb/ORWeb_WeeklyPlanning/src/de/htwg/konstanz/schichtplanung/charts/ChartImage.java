package de.htwg.konstanz.schichtplanung.charts;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.DateTickMarkPosition;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.DatasetRenderingOrder;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYStepRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.time.Day;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.TimeSeriesDataItem;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYDataset;

import ausgabe.Ausgabe;
import ausgabe.Schichtplan;
import bedarf.Bedarf;
import bedarf.SchichtBedarf;
import bedarf.TagesBedarf;
import de.htwg.konstanz.schichtplanung.utils.SessionAttributes;
import schichtmuster.Schicht;

public class ChartImage extends HttpServlet {

	private static int counter = 0;

	public enum SchichtTyp {
		FRUEH, SPAET, NACHT, FNS
	};

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		SchichtTyp schichtTyp = SchichtTyp.valueOf(request.getParameter("schichttyp"));

		Boolean mitUeberdeckung = Boolean.parseBoolean(request.getParameter("mitueberdeckung"));

		response.setContentType("image/png");
		OutputStream out = response.getOutputStream();
		ImageIO.write(generateImage(request, schichtTyp, mitUeberdeckung), "png", out);
		out.flush();
		out.close();
	}

	public static BufferedImage generateImage(HttpServletRequest request, SchichtTyp schichtTyp, Boolean mitUeberdeckung) {
		JFreeChart chart = null;
		switch (schichtTyp) {
		case FRUEH:
		case SPAET:
		case NACHT:
			chart = createOverlaidChart(request, schichtTyp, mitUeberdeckung);
			break;
		case FNS:
			chart = ChartFactory.createBarChart("Bedarf - Früh Spät Nacht", "Zeit", "Anzahl Personen", getCategoryDataset(request),
					PlotOrientation.VERTICAL, true, true, true);
			break;
		default:
			break;
		}

		BufferedImage bufferedImage = new BufferedImage(1000, 400, BufferedImage.TYPE_INT_ARGB);

		Graphics2D g2d = bufferedImage.createGraphics();

		chart.draw(g2d, new Rectangle(1000, 400));

		return bufferedImage;
	}

	private static JFreeChart createChartForSchicht(HttpServletRequest request, SchichtTyp schichtTyp) {
		JFreeChart chart;
		TimeSeries ts = getTimeSeriesBedarf(request, schichtTyp);
		final IntervalXYDataset dataset = new TimeSeriesCollection(ts);
		final XYItemRenderer renderer1 = new XYBarRenderer(0.20);

		final DateAxis domainAxis = new DateAxis("Zeit");
		domainAxis.setTickMarkPosition(DateTickMarkPosition.MIDDLE);
		final ValueAxis rangeAxis = new NumberAxis("Anzahl Personen");
		final XYPlot plot = new XYPlot(dataset, domainAxis, rangeAxis, renderer1);

		// return a new chart containing the overlaid plot...
		return new JFreeChart(getMessage(schichtTyp), JFreeChart.DEFAULT_TITLE_FONT, plot, true);
	}

	private static String getMessage(SchichtTyp schichtTyp) {
		switch (schichtTyp) {
		case FRUEH:
			return "Früh";
		case SPAET:
			return "Spät";
		case NACHT:
			return "Nacht";
		case FNS:
			return "Früh Spät Nacht - Diagram";
		}
		return "";
	}

	private static TimeSeries getTimeSeriesBedarf(HttpServletRequest request, SchichtTyp schichtTyp) {
		TimeSeries ts = new TimeSeries("Bedarf", Day.class);

		Bedarf bedarf = (Bedarf) request.getSession().getAttribute(SessionAttributes.BEDARF);
		ArrayList<TagesBedarf> list = new ArrayList<TagesBedarf>(bedarf.getBedarf().values());
		Collections.sort(list);

		for (TagesBedarf tagesBedarf : list) {
			switch (schichtTyp) {
			case FRUEH:
				ts.add(new TimeSeriesDataItem(new Day(tagesBedarf.getDatum().getTime()), tagesBedarf.getBedarfFrueh().getAnzahlPersonen()));
				break;
			case NACHT:
				ts.add(new TimeSeriesDataItem(new Day(tagesBedarf.getDatum().getTime()), tagesBedarf.getBedarfNacht().getAnzahlPersonen()));
				break;
			case SPAET:
				ts.add(new TimeSeriesDataItem(new Day(tagesBedarf.getDatum().getTime()), tagesBedarf.getBedarfSpaet().getAnzahlPersonen()));
				break;
			default:
				break;
			}
		}
		return ts;
	}

	private static TimeSeries getTimeSeriesDeckung(HttpServletRequest request, SchichtTyp schichtTyp) {
		Schichtplan schichtplan = (Schichtplan) request.getSession().getAttribute(SessionAttributes.SCHICHTPLAN);

		Bedarf bedarf = (Bedarf) request.getSession().getAttribute(SessionAttributes.BEDARF);

		TimeSeries ts = new TimeSeries("Deckung", Day.class);

		ArrayList<TagesBedarf> deckunglist = new ArrayList<TagesBedarf>();

		ArrayList<TagesBedarf> list = new ArrayList<TagesBedarf>(bedarf.getBedarf().values());
		Collections.sort(list);

		for (int i = 0; i < list.size(); i++) {
			int frueh = 0;
			int nacht = 0;
			int spaet = 0;
			for (Ausgabe ausgabe : schichtplan.getAusgabe()) {
				Schicht schicht = ausgabe.getSchichtfolge().getSchichten().get(i);
				switch (schicht) {
				case FRUEHSCHICHT:
					frueh = frueh + ausgabe.getAnzahlSchichtfolgen();
					break;
				case NACHTSCHICHT:
					nacht = nacht + ausgabe.getAnzahlSchichtfolgen();
					break;
				case SPAETSCHICHT:
					spaet = spaet + ausgabe.getAnzahlSchichtfolgen();
					break;
				}
			}
			TagesBedarf deckung = new TagesBedarf();
			deckung.setBedarfFrueh(new SchichtBedarf(frueh));
			deckung.setBedarfNacht(new SchichtBedarf(nacht));
			deckung.setBedarfSpaet(new SchichtBedarf(spaet));
			deckung.setDatum(list.get(i).getDatum());
			deckunglist.add(deckung);
		}

		for (TagesBedarf tagesBedarf : deckunglist) {
			switch (schichtTyp) {
			case FRUEH:
				ts.add(new TimeSeriesDataItem(new Day(tagesBedarf.getDatum().getTime()), tagesBedarf.getBedarfFrueh().getAnzahlPersonen()));
				break;
			case NACHT:
				ts.add(new TimeSeriesDataItem(new Day(tagesBedarf.getDatum().getTime()), tagesBedarf.getBedarfNacht().getAnzahlPersonen()));
				break;
			case SPAET:
				ts.add(new TimeSeriesDataItem(new Day(tagesBedarf.getDatum().getTime()), tagesBedarf.getBedarfSpaet().getAnzahlPersonen()));
				break;
			default:
				break;
			}
		}

		// if(schichtTyp.toString().equals("FRUEH")){
		// TagesBedarf tb = deckunglist.get(deckunglist.size()-1);
		// tb.getDatum().add(Calendar.DAY_OF_MONTH, 1);
		// ts.add(new TimeSeriesDataItem(new Day(tb.getDatum().getTime()),
		// tb.getBedarfFrueh().getAnzahlPersonen()));
		// }

		// if(schichtTyp.toString().equals("SPAET")){
		// TagesBedarf tb = deckunglist.get(deckunglist.size()-1);
		// tb.getDatum().add(Calendar.DAY_OF_MONTH, 1);
		// ts.add(new TimeSeriesDataItem(new Day(tb.getDatum().getTime()),
		// tb.getBedarfSpaet().getAnzahlPersonen()));
		// }

		// if(schichtTyp.toString().equals("NACHT")){
		// TagesBedarf tb = deckunglist.get(deckunglist.size()-1);
		// tb.getDatum().add(Calendar.DAY_OF_MONTH, 1);
		// ts.add(new TimeSeriesDataItem(new Day(tb.getDatum().getTime()),
		// tb.getBedarfNacht().getAnzahlPersonen()));
		// }
		return ts;
	}

	public static CategoryDataset getCategoryDataset(HttpServletRequest request) {

		DefaultCategoryDataset categoryDataset = new DefaultCategoryDataset();

		Bedarf bedarf = (Bedarf) request.getSession().getAttribute(SessionAttributes.BEDARF);
		ArrayList<TagesBedarf> list = new ArrayList<TagesBedarf>(bedarf.getBedarf().values());

		Collections.sort(list);

		counter = 0;

		for (TagesBedarf tagesBedarf : list) {

			counter++;

			// System.out.println(tagesBedarf.getBedarfFrueh() + " " +
			// tagesBedarf.getDatum());
			categoryDataset.addValue(tagesBedarf.getBedarfFrueh().getAnzahlPersonen(), "Früh", tagesBedarf);

			categoryDataset.addValue(tagesBedarf.getBedarfSpaet().getAnzahlPersonen(), "Spät", tagesBedarf);

			categoryDataset.addValue(tagesBedarf.getBedarfNacht().getAnzahlPersonen(), "Nacht", tagesBedarf);

		}

		return categoryDataset;
	}

	/**
	 * Creates an overlaid chart.
	 * 
	 * @param schichtTyp
	 * @param request
	 * @param mitUeberdeckung
	 * 
	 * @return The chart.
	 * 
	 * Modified by toehrlin
	 * 
	 * 
	 */
	private static JFreeChart createOverlaidChart(HttpServletRequest request, SchichtTyp schichtTyp, Boolean mitUeberdeckung) {
		if (!mitUeberdeckung) {
			return createChartForSchicht(request, schichtTyp);
		}
		//Beginn of change by toehrlin
		// create plot ...
		/**
		 * Im folgenden wird der letzte Tag der Deckung ausgelesen und um einen
		 * Tag erweitert. Hiermit wird die Linie der Deckung auch über den
		 * letzten Tag komplett gezogen, anstatt nur bis zum Beginn des letzten
		 * Tages
		 */
		TimeSeries tsDeckung = getTimeSeriesDeckung(request, schichtTyp);
		if (schichtTyp.toString().equals("SPAET")) {
			TimeSeriesDataItem tsdi = tsDeckung.getDataItem(tsDeckung.getItemCount() - 1);
			Date lastDay = tsdi.getPeriod().getEnd();
			GregorianCalendar gc = new GregorianCalendar();
			gc.setTime(lastDay);
			gc.add(Calendar.DAY_OF_MONTH, 1);
			tsDeckung.add(new TimeSeriesDataItem(new Day(gc.getTime()), tsdi.getValue()));
		}
		if (schichtTyp.toString().equals("FRUEH")) {
			TimeSeriesDataItem tsdi = tsDeckung.getDataItem(tsDeckung.getItemCount() - 1);
			Date lastDay = tsdi.getPeriod().getEnd();
			GregorianCalendar gc = new GregorianCalendar();
			gc.setTime(lastDay);
			gc.add(Calendar.DAY_OF_MONTH, 1);
			tsDeckung.add(new TimeSeriesDataItem(new Day(gc.getTime()), tsdi.getValue()));
		}
		if (schichtTyp.toString().equals("NACHT")) {
			TimeSeriesDataItem tsdi = tsDeckung.getDataItem(tsDeckung.getItemCount() - 1);
			Date lastDay = tsdi.getPeriod().getEnd();
			GregorianCalendar gc = new GregorianCalendar();
			gc.setTime(lastDay);
			gc.add(Calendar.DAY_OF_MONTH, 1);
			tsDeckung.add(new TimeSeriesDataItem(new Day(gc.getTime()), tsdi.getValue()));
		}

		// End of change by toehrlin
		
		final IntervalXYDataset data1 = new TimeSeriesCollection(getTimeSeriesBedarf(request, schichtTyp));
		final XYItemRenderer renderer1 = new XYBarRenderer(0.20);

		final DateAxis domainAxis = new DateAxis("Zeit");
		domainAxis.setTickMarkPosition(DateTickMarkPosition.MIDDLE);
		final ValueAxis rangeAxis = new NumberAxis("Anzahl Personen");
		final XYPlot plot = new XYPlot(data1, domainAxis, rangeAxis, renderer1);

		// final XYDataset data2 = new
		// TimeSeriesCollection(getTimeSeriesDeckung(request, schichtTyp));
		final XYDataset data2 = new TimeSeriesCollection(tsDeckung);
		// final StandardXYItemRenderer renderer2 = new
		// StandardXYItemRenderer();
		// Beginn of change by toehrlin
		final XYStepRenderer renderer2 = new XYStepRenderer();
		//End of change by toehrlin
		plot.setDataset(1, data2);
		plot.setRenderer(1, renderer2);

		plot.setDatasetRenderingOrder(DatasetRenderingOrder.FORWARD);

		// return a new chart containing the overlaid plot...
		return new JFreeChart(getMessage(schichtTyp), JFreeChart.DEFAULT_TITLE_FONT, plot, true);

	}

}
