package de.htwg.konstanz.schichtplanung.page;

import java.util.ArrayList;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.List;

import de.htwg.konstanz.schichtplanung.page.bedarf.BedarfPage;
import de.htwg.konstanz.schichtplanung.utils.SessionAttributes;

import net.sf.click.control.Column;
import net.sf.click.control.Panel;
import net.sf.click.control.Table;
import net.sf.click.extras.control.DateField;
import net.sf.click.extras.graph.JSBarChart;
import net.sf.click.extras.panel.TabbedPanel;
import bedarf.Bedarf;
import bedarf.BedarfFactory;
import bedarf.SchichtBedarf;
import bedarf.TagesBedarf;

public class EinFormular extends BorderPage {

	public String title = "Anzeige des Bedarfs";

	public Table table = new Table();

	public TabbedPanel tabbedPanel = new TabbedPanel();

	private Bedarf bedarf;

	public EinFormular() {
		table.setClass(Table.CLASS_ITS);
		table.setPageSize(7);
		table.setShowBanner(true);
		table.setSortable(false);

		Column column = new Column("datum.time","Datum");
		column.setFormat("{0,date,E dd.MM.yyyy}");
		column.setWidth("90px");
		column.setDataStyle("white-space", "nowrap");
		table.addColumn(column);

		column = new Column("bedarfFrueh.anzahlPersonen","Bedarf Früh");
		column.setWidth("140px;");
		column.setTextAlign("right");
		table.addColumn(column);

		column = new Column("bedarfSpaet.anzahlPersonen","Bedarf Spät");
		column.setWidth("140px;");
		column.setTextAlign("right");
		table.addColumn(column);

		column = new Column("bedarfNacht.anzahlPersonen", "Bedarf Nacht");
		column.setWidth("140px;");
		column.setTextAlign("right");
		table.addColumn(column);

	}

	public void onInit() {
		super.onInit();

		bedarf = (Bedarf) getContext().getSessionAttribute(
				SessionAttributes.BEDARF);
		if (bedarf == null) {
			setForward(getContext().createPage(BedarfPage.class));
		}else{
		List<TagesBedarf> liste = new ArrayList<TagesBedarf>(bedarf.getBedarf()
				.values());
		Collections.sort(liste);

		table.setRowList(liste);
		fillCharts(bedarf);
		}
	}

	private void fillCharts(Bedarf bedarf) {
		if (bedarf != null) {

			List<TagesBedarf> liste = new ArrayList<TagesBedarf>(bedarf
					.getBedarf().values());
			Collections.sort(liste);

			Panel panel4 = new Panel("panel4", "panel/chartPanelFNS.htm");
			panel4.setLabel("Combi FNS");
			tabbedPanel.addControl(panel4);

			Panel panel1 = new Panel("panel1", "panel/chartPanelFrueh.htm");
			panel1.setLabel("Früh");
			tabbedPanel.addControl(panel1);

			Panel panel2 = new Panel("panel2", "panel/chartPanelSpaet.htm");
			panel2.setLabel("Spät");
			tabbedPanel.addControl(panel2);

			Panel panel3 = new Panel("panel3", "panel/chartPanelNacht.htm");
			panel3.setLabel("Nacht");
			tabbedPanel.addControl(panel3);

		}
	}
}