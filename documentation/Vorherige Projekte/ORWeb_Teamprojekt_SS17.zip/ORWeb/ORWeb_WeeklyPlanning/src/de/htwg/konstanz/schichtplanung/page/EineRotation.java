package de.htwg.konstanz.schichtplanung.page;

import java.util.Iterator;
import java.util.List;

import net.sf.click.control.Field;
import net.sf.click.control.FieldSet;
import net.sf.click.control.FileField;
import net.sf.click.control.Form;
import net.sf.click.control.Option;
import net.sf.click.control.Select;
import net.sf.click.control.Submit;
import net.sf.click.control.TextField;
import net.sf.click.util.ClickUtils;
import schichtmuster.Rotation;

public class EineRotation extends BorderPage {

	public String title = "Eine Rotation";

	public Form formRotation = new Form();
	public TextField textField1;
	public Select select1;
	public FileField fileField;

	public EineRotation() {
		// ---Beginn Formular
		FieldSet fieldSet = new FieldSet("rotationsDetails");
		formRotation.add(fieldSet);

		textField1 = new TextField("schichtlaenge (Wochen): ", true);
		textField1.setSize(3);
		textField1.setMaxLength(3);
		textField1.setRequired(false);
		fieldSet.add(textField1);

		select1 = new Select("rotation: ", true);
		select1.setRequired(false);
		for (Rotation rotation : Rotation.values()) {
			select1.add(new Option(rotation.name(), rotation.name()));
		}
		fieldSet.add(select1);

		fileField = new FileField("schichtdaten ausw�hlen:");
		fileField.setRequired(false);
		fieldSet.add(fileField);

		formRotation
				.add(new Submit("ok", "    Rotieren    ", this, "onOkClick"));
		// ---Ende Formular

	}

	// --Methode wird nach Klick auf Rotieren ausgeführt
	public boolean onOkClick() {
		if (formRotation.isValid()) {

			// Speichert Werte auf FieldSet in Liste
			List fieldSetValues = ClickUtils.getFormFields(formRotation);
			int fieldSetElements = 0;

			for (Iterator i = fieldSetValues.iterator(); i.hasNext();) {

				fieldSetElements = fieldSetValues.size();
				Field field = (Field) i.next();

				// System.out.println(field.getName() + "=" + field.getValue());
			}

		}
		return true;
	}

}
