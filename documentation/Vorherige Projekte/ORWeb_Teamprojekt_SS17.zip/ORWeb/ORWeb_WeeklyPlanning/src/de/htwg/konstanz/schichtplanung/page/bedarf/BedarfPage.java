package de.htwg.konstanz.schichtplanung.page.bedarf;

import java.util.GregorianCalendar;

import net.sf.click.control.FieldSet;
import net.sf.click.control.Form;
import net.sf.click.control.Submit;
import net.sf.click.extras.control.DateField;
import net.sf.click.extras.control.FormTable;
import bedarf.Bedarf;
import bedarf.BedarfFactory;
import de.htwg.konstanz.schichtplanung.page.BorderPage;
import de.htwg.konstanz.schichtplanung.page.projektzeitraum.ProjektzeitraumPage;
import de.htwg.konstanz.schichtplanung.utils.SessionAttributes;

public class BedarfPage extends BorderPage {

	public String title = "Bedarfszeitraum eingeben";
	private static final String DAY_FORMAT_PATTERN = "dd.MM.yyyy";

	public Bedarf bedarf;

	public Form formBedarfZeit = new Form();

	public FormTable table = new FormTable();

	public DateField vonDateField = new DateField("Von", true);
	public DateField bisDateField = new DateField("Bis", true);

	public BedarfPage() {
		bedarf = (Bedarf) getContext().getSession().getAttribute(SessionAttributes.BEDARF);
		if (bedarf != null && bedarf.getStartZeitpunkt() != null) {
			setForward((getContext().createPage(SetzenPage.class)));
		} else {
			FieldSet bedarfszeitraumFieldSet = new FieldSet("Bedarfszeitraum");
			vonDateField.setFormatPattern(DAY_FORMAT_PATTERN);
			bisDateField.setFormatPattern(DAY_FORMAT_PATTERN);
			bedarfszeitraumFieldSet.add(vonDateField);
			bedarfszeitraumFieldSet.add(bisDateField);
			formBedarfZeit.add(bedarfszeitraumFieldSet);
			formBedarfZeit.add(new Submit("ok", this, "onButtonCreateTable"));
		}
	}

	/**
	 * modified by: toehrlin
	 * fafilipp: Diese Methode übernimmt den gesetzten Start und End Datum des
	 * Benutzers für die Bedarfseingabe
	 * 
	 * @return true wenn alles richtig verläuft, false wenn nicht
	 */
	public boolean onButtonCreateTable() {
		// Begin of Change by fafilipp
		if (formBedarfZeit.isValid()) {
			// End of Change
			//Begin of Change by toehrlin
			if (vonDateField.getDate().before(bisDateField.getDate())) {
			//End of Change by toehrlin
				Bedarf bedarf = new Bedarf();
				GregorianCalendar start = new GregorianCalendar();
				GregorianCalendar ende = new GregorianCalendar();
				start.setTime(vonDateField.getDate());
				ende.setTime(bisDateField.getDate());
				bedarf = BedarfFactory.getKonstanterBedarf(start, ende, 0, 0, 0);
				getContext().getSession().setAttribute(SessionAttributes.BEDARF, bedarf);
				setForward((getContext().createPage(SetzenPage.class)));
				//begin of change by toehrlin
				return true;
				//end of change by toehrlin
			}
			setForward(ProjektzeitraumPage.class);
			return false;
		}
		return true;
	}

}
