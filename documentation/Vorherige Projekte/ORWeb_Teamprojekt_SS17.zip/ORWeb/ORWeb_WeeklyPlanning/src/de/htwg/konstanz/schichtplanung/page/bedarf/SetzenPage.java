package de.htwg.konstanz.schichtplanung.page.bedarf;

import java.util.ArrayList;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import net.sf.click.control.ActionButton;
import net.sf.click.control.Column;
import net.sf.click.control.FieldSet;
import net.sf.click.control.Form;
import net.sf.click.control.Option;
import net.sf.click.control.Select;
import net.sf.click.control.Submit;
import net.sf.click.control.Table;
import net.sf.click.extras.control.DateField;
import net.sf.click.extras.control.FieldColumn;
import net.sf.click.extras.control.FormTable;
import net.sf.click.extras.control.NumberField;
import schichtmuster.Schicht;
import bedarf.Bedarf;
import bedarf.BedarfFactory;
import bedarf.TagesBedarf;
import de.htwg.konstanz.schichtplanung.page.BorderPage;
import de.htwg.konstanz.schichtplanung.utils.SessionAttributes;

public class SetzenPage extends BorderPage {

	public String title = "Bedarf Einlesen";
	private static final String DAY_FORMAT_PATTERN = "dd.MM.yyyy";

	public Bedarf bedarf;

	public Form auswahlBedarf = new Form();

	public FormTable table = new FormTable();

	public DateField vonField = new DateField("Bedarf von", true);
	public DateField bisField = new DateField("Bedarf bis", true);
	public Select auswahl;
	public NumberField bedarfNumberField;
	public Select schichten;
	public ActionButton cancelButton;

	public ActionButton deleteZeitraumButton;

	public String nachricht = "";

	public SetzenPage() {

		FieldSet bedarfszeitraumFieldSet = new FieldSet("Bedarfszeitraum");

		FieldSet fieldSetChange = new FieldSet("Setze Bedarf");
		vonField.setFormatPattern(DAY_FORMAT_PATTERN);
		bisField.setFormatPattern(DAY_FORMAT_PATTERN);

		fieldSetChange.add(vonField);
		fieldSetChange.add(bisField);

		bedarfNumberField = new NumberField("Bedarf", true);

		fieldSetChange.add(bedarfNumberField);

		auswahl = new Select("Wochentag(e)");
		auswahl.add(new Option(999, "Alle"));

		auswahl.add(new Option(GregorianCalendar.MONDAY, "Montag"));
		auswahl.add(new Option(GregorianCalendar.TUESDAY, "Dienstag"));
		auswahl.add(new Option(GregorianCalendar.WEDNESDAY, "Mittwoch"));
		auswahl.add(new Option(GregorianCalendar.THURSDAY, "Donnerstag"));
		auswahl.add(new Option(GregorianCalendar.FRIDAY, "Freitag"));
		auswahl.add(new Option(GregorianCalendar.SATURDAY, "Samstag"));
		auswahl.add(new Option(GregorianCalendar.SUNDAY, "Sonntag"));

		fieldSetChange.add(auswahl);

		schichten = new Select("Schichten");

		schichten.add(new Option(999, "Alle"));
		schichten.add(Schicht.FRUEHSCHICHT.toString());
		schichten.add(Schicht.SPAETSCHICHT.toString());
		schichten.add(Schicht.NACHTSCHICHT.toString());

		fieldSetChange.add(schichten);
		auswahlBedarf.add(fieldSetChange);

		auswahlBedarf.add(new Submit("ok", this, "onButtonChange"));

		deleteZeitraumButton = new ActionButton("Zeitraum ändern", this,
				"deleteZeitraumOnClick");
		auswahlBedarf.add(deleteZeitraumButton);

		// Erstelle Tab.e

		table.getForm().setMethod("get");

		table.setClass(Table.CLASS_SIMPLE);
		table.setWidth("700px");
		table.getForm().setButtonAlign(Form.ALIGN_RIGHT);
		// Beginn of Change (magerhar)
		// With this Change 30 Days can be plant at once
		table.setPageSize(30);
		// End of Change
		table.setShowBanner(true);

		Column column2 = new Column("datum.time", "Datum");
		column2.setFormat("{0,date,E dd.MM.yyyy}");
		column2.setWidth("90px");
		column2.setDataStyle("white-space", "nowrap");
		table.addColumn(column2);

		FieldColumn column;
		NumberField numberField = new NumberField();

		column = new FieldColumn("bedarfFrueh.anzahlPersonen", "Frühschicht",
				numberField);
		column.setTextAlign("right");
		table.addColumn(column);

		column = new FieldColumn("bedarfSpaet.anzahlPersonen", "Spätschicht",
				numberField);
		column.setTextAlign("right");
		table.addColumn(column);

		column = new FieldColumn("bedarfNacht.anzahlPersonen", "Nachtschicht",
				numberField);
		column.setTextAlign("right");
		table.addColumn(column);
		Submit sub = new Submit("buttonSave", "save", this,
				"speichereBedarfOnClick");

		table.getForm()
				.add(new Submit("buttonSave", "save", this,
						"speichereBedarfOnClick"));

		cancelButton = new ActionButton("reset", this, "cancelBedarfOnClick");

	}

	public boolean speichereBedarfOnClick() {

		List rowList = table.getRowList();
		HashMap<GregorianCalendar, TagesBedarf> tagesbedarfList = new HashMap<GregorianCalendar, TagesBedarf>();

		for (Iterator i = rowList.iterator(); i.hasNext();) {
			TagesBedarf tbedarf = (TagesBedarf) i.next();
			tagesbedarfList.put(tbedarf.getDatum(), tbedarf);

		}
		// for (TagesBedarf run: tagesbedarfList){
		// System.out.println(run);
		//
		// }
		// for (Iterator i = rowList.iterator(); i.hasNext();) {
		// System.out.println(i.next());
		//
		// }
		Bedarf bedarf = (Bedarf) getContext().getSession().getAttribute(
				SessionAttributes.BEDARF);

		bedarf.setBedarf(tagesbedarfList);

		updateTable(bedarf);
		this.nachricht = "alert('Eingabe gespeichert');";
		return true;
	}

	public boolean cancelBedarfOnClick() {
		Bedarf bedarf = new Bedarf();
		bedarf = (Bedarf) getContext().getSession().getAttribute(
				SessionAttributes.BEDARF);

		bedarf = BedarfFactory.getKonstanterBedarf(bedarf.getStartZeitpunkt(),
				bedarf.getEndZeitpunkt(), 0, 0, 0);

		updateTable(bedarf);
		// System.out.println("cancelBedarfOnClick");

		return true;
	}

	/*
	 * public boolean onButtonCreateTable() { Wird nicht mehr ben�tigt!
	 * 
	 * GregorianCalendar c = new GregorianCalendar(); GregorianCalendar c1 = new
	 * GregorianCalendar(); // // c.setTime();
	 * 
	 * Bedarf bedarf = new Bedarf();
	 * 
	 * // formBedarfZeit.copyTo(bedarf);
	 * 
	 * // c1.setTime(dateField2.getDate());
	 * 
	 * // c.setTime(new Date(2008, 06, 1)); // c1.setTime(new Date(2008, 17,
	 * 1)); // System.out.println(c.getTime()+" "+c1.getTime());
	 * 
	 * // bedarf = BedarfFactory.getKonstanterBedarf(bedarf.getStartZeitpunkt(),
	 * bedarf.getEndZeitpunkt(), 0, 0, 0); GregorianCalendar start = new
	 * GregorianCalendar(); GregorianCalendar ende = new GregorianCalendar();
	 * 
	 * start.setTime(vonDateField.getDate());
	 * ende.setTime(bisDateField.getDate());
	 * 
	 * bedarf = BedarfFactory.getKonstanterBedarf(start, ende, 0, 0, 0);
	 * 
	 * updateTable(bedarf);
	 * 
	 * return true; }
	 */

	private void updateTable(Bedarf bedarf) {
		List<TagesBedarf> liste = new ArrayList<TagesBedarf>(bedarf.getBedarf()
				.values());
		Collections.sort(liste);

		table.setRowList(liste);
		getContext().getSession()
				.setAttribute(SessionAttributes.BEDARF, bedarf);
	}

	public boolean onButtonChange() {

		if (auswahlBedarf.isValid()) {
			GregorianCalendar von = new GregorianCalendar();
			GregorianCalendar bis = new GregorianCalendar();

			int wochentag = Integer.parseInt(auswahl.getValue());

			von.setTime(vonField.getDate());

			bis.setTime(bisField.getDate());

			int bedarfAnzahl = bedarfNumberField.getNumber().intValue();

			String schicht = schichten.getValue();

			bedarf = (Bedarf) getContext().getSession().getAttribute(
					SessionAttributes.BEDARF);

			if (schicht.equals("999") && wochentag == 999) {
				bedarf = BedarfFactory.setBedarfsZeitraumAlleSchichtenAlleTage(
						von, bis, bedarfAnzahl, bedarf);
			}
			if (schicht.equals("999") && wochentag != 999) {
				bedarf = BedarfFactory.setBedarfsZeitraumAlleSchichten(von,
						bis, bedarfAnzahl, bedarf, wochentag);
			}
			if (!schicht.equals("999") && wochentag == 999) {
				Schicht schichtEnum = Schicht.valueOf(schicht);
				bedarf = BedarfFactory.setBedarfsZeitraumAlleTage(von, bis,
						schichtEnum, bedarfAnzahl, bedarf);

			}
			if (!schicht.equals("999") && wochentag != 999) {
				Schicht schichtEnum = Schicht.valueOf(schicht);
				bedarf = BedarfFactory.setBedarfsZeitraum(von, bis,
						schichtEnum, bedarfAnzahl, bedarf, wochentag);

			}

			updateTable(bedarf);
		}

		return true;
	}

	public boolean deleteZeitraumOnClick() {

		getContext().getSession().setAttribute(SessionAttributes.BEDARF, null);

		setForward((getContext().createPage(BedarfPage.class)));

		return true;
	}

	@Override
	public void onInit() {
		super.onInit();

		bedarf = (Bedarf) getContext().getSession().getAttribute(
				SessionAttributes.BEDARF);
		vonField.setDate(bedarf.getStartZeitpunkt().getTime());
		bisField.setDate(bedarf.getEndZeitpunkt().getTime());
		if (bedarf != null) {
			updateTable(bedarf);

		}

	}

}
