package de.htwg.konstanz.schichtplanung.page.hilfe;

import de.htwg.konstanz.schichtplanung.page.BorderPage;

public class HilfePage extends BorderPage{
	public String title = "Hilfe";

}
