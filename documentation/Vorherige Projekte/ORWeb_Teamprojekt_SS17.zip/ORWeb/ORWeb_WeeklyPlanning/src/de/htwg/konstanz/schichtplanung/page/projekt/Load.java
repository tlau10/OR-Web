package de.htwg.konstanz.schichtplanung.page.projekt;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import ausgabe.Schichtplan;
import ausgabe.SchichtplanFactory;
import bedarf.Bedarf;
import bedarf.BedarfFactory;
import de.htwg.konstanz.schichtplanung.page.BorderPage;
import de.htwg.konstanz.schichtplanung.page.EinFormular;
import de.htwg.konstanz.schichtplanung.page.click.ErrorPage;
import de.htwg.konstanz.schichtplanung.page.user.HomePage;
import de.htwg.konstanz.schichtplanung.projektdatei.ProjektDatei;
import de.htwg.konstanz.schichtplanung.utils.SessionAttributes;
import net.sf.click.control.FieldSet;
import net.sf.click.control.FileField;
import net.sf.click.control.Form;
import net.sf.click.control.Submit;
import net.sf.click.extras.control.PageSubmit;
import schichtmuster.Schichtmuster;
import schichtmuster.SchichtmusterFactory;

public class Load extends BorderPage {
	public Form form = new Form();
	private FileField file;
	public String title = "Projekt laden";

	public Load() {
		FieldSet fieldSet = new FieldSet("upload", "Upload");
		form.add(fieldSet);

		file = new FileField("uploadFile", "Datei auswählen", 40);
		file.setRequired(true);
		fieldSet.add(file);

		form.add(new Submit("ok", "  OK  ", this, "onOkClick"));
		form.add(new PageSubmit("cancel", HomePage.class));

	}

	public boolean onOkClick() {

		if (form.isValid()) {
			if (file.getFileItem() != null) {
				// addModel("uploadFile", file.getFileItem());
				try {
					processZipInputStream(file.getFileItem().getInputStream());
					EinFormular formularPage = (EinFormular) getContext()
							.createPage(EinFormular.class);
					setForward(formularPage);
				} catch (IOException e) {
					ErrorPage errorPage = (ErrorPage) getContext().createPage(
							ErrorPage.class);
					setForward(errorPage);
					e.printStackTrace();
				}
			}
		}
		return true;
	}

	private void processZipInputStream(InputStream stream) throws IOException {
		ZipInputStream zipStream = new ZipInputStream(stream);
		while (true) {
			ZipEntry entry = zipStream.getNextEntry();
			if (entry == null) {
				break;
			}

			// System.out.println(entry.getName());

			BufferedReader reader = new BufferedReader(new InputStreamReader(
					zipStream));
			StringBuffer str = new StringBuffer();
			while (reader.ready()) {
				str.append(reader.readLine());
			}
			ByteArrayInputStream arrayInputStream = new ByteArrayInputStream(
					str.toString().getBytes());

			if (entry.getName().equals(ProjektDatei.FILENAME_BEDARF)) {

				Bedarf bedarf = BedarfFactory.loadBedarf(arrayInputStream);
				// if (bedarf != null) {
				// System.out.println(bedarf.toString());
				// }

				getContext().getSession().setAttribute(
						SessionAttributes.BEDARF, bedarf);

			}
			if (entry.getName().equals(ProjektDatei.FILENAME_SCHICHTMUSTER)) {
				Schichtmuster schichtmuster = SchichtmusterFactory
						.loadSchichtmuster(arrayInputStream);
				// if (schichtmuster != null) {
				// System.out.println(schichtmuster.toString());
				// }

				getContext().getSession().setAttribute(
						SessionAttributes.SCHICHTMUSTER, schichtmuster);
			}

			if (entry.getName().equals(ProjektDatei.FILENAME_SCHICHTPLAN)) {
				Schichtplan schichtplan = SchichtplanFactory
						.loadSchichtplan(arrayInputStream);
				// if (schichtplan != null) {
				// System.out.println(schichtplan.toString());
				// }

				getContext().getSession().setAttribute(
						SessionAttributes.SCHICHTPLAN, schichtplan);
			}
		}
	}

}
