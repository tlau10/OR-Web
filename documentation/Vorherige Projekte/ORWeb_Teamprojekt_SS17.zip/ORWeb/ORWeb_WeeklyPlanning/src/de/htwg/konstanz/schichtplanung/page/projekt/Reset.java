package de.htwg.konstanz.schichtplanung.page.projekt;

import net.sf.click.Page;
import de.htwg.konstanz.schichtplanung.page.EinFormular;
import de.htwg.konstanz.schichtplanung.utils.SessionAttributes;

public class Reset extends Page{
	public String title = "Reset Projekt";
	
public Reset(){
	
}

public void onInit() {
	getContext().getSession().setAttribute(SessionAttributes.BEDARF, null);
	getContext().getSession().setAttribute(SessionAttributes.SCHICHTMUSTER, null);
	getContext().getSession().setAttribute(SessionAttributes.SCHICHTPLAN, null);
	setForward(getContext().createPage(EinFormular.class));
	}
}
