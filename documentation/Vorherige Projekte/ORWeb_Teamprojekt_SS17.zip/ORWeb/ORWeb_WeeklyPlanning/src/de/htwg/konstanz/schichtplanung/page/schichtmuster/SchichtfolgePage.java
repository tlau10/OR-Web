package de.htwg.konstanz.schichtplanung.page.schichtmuster;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.click.control.Column;
import net.sf.click.control.Panel;
import net.sf.click.control.Submit;
import net.sf.click.control.Table;
import net.sf.click.extras.control.FieldColumn;
import net.sf.click.extras.control.FormTable;
import schichtmuster.Rotation;
import schichtmuster.Schicht;
import schichtmuster.Schichtfolge;
import schichtmuster.SchichtfolgenFactory;
import schichtmuster.Schichtmuster;
import schichtmuster.SchichtmusterFactory;
import de.htwg.konstanz.schichtplanung.page.BorderPage;
import de.htwg.konstanz.schichtplanung.utils.RotationSelect;
import de.htwg.konstanz.schichtplanung.utils.SchichtSelect;
import de.htwg.konstanz.schichtplanung.utils.SessionAttributes;

public class SchichtfolgePage extends BorderPage {
	public String title = "Eingabe der Schichtfolgelänge";
	public FormTable musterFolgeTable = new FormTable("musterFolgeTable");

	private static final String SCHICHTLAENGE = "SCHICHTLAENGE";

	private static final String[] WOCHENTAGE = new String[] { "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag",
			"Sonntag" };

	private static final String EINS_NULLEN = "0";

	private static final String ZWEI_NULLEN = "00";

	public Panel panel2 = new Panel("panel2", "schichtmuster/panel2.htm");

	public Panel panel3 = new Panel("panel3", "schichtmuster/panel3.htm");

	public String message;

	@Override
	public void onInit() {
		super.onInit();
		musterFolgeTable.getForm().add(new Submit("anzeigen", "Anzeigen", this, "onMusterOnClick"));
		musterFolgeTable.getForm().add(new Submit("cancel", "Schichtlänge ändern", this, "onCancelClick"));
		musterFolgeTable.getForm().add(new Submit("save", "Hinzufügen", this, "onFactorySave"));
		musterFolgeTable.setClass(Table.CLASS_SIMPLE);
		initMusterFolge(Integer.parseInt((String) getContext().getSessionAttribute(SCHICHTLAENGE)));

	}

	private void initMusterFolge(int schichtLaenge) {
		while (0 < musterFolgeTable.getColumnList().size()) {
			musterFolgeTable.removeColumn((Column) musterFolgeTable.getColumnList().get(0));
		}
		Map map = new HashMap();
		musterFolgeTable.addColumn(new FieldColumn("Feld0", "Rotationstyp", new RotationSelect()));
		map.put("Feld0", Rotation.KEINE_ROTATION);

		for (int i = 0; i < schichtLaenge; i++) {
			String offset = "";
			if (i < 99) {
				offset = EINS_NULLEN;
			}
			if (i < 9) {
				offset = ZWEI_NULLEN;
			}

			musterFolgeTable.addColumn(new FieldColumn("Feld" + offset + (i + 1), WOCHENTAGE[i % 7], new SchichtSelect()));
			map.put("Feld" + offset + (i + 1), Schicht.FREISCHICHT);
		}
		List<Map> list = new ArrayList<Map>();
		list.add(map);
		musterFolgeTable.setRowList(list);
	}

	public boolean onMusterOnClick() {
		List rowList = musterFolgeTable.getRowList();
		Map map = new HashMap();
		for (Iterator i = rowList.iterator(); i.hasNext();) {
			map = (Map) i.next();
		}
		List<String> keys = new ArrayList<String>(map.keySet());
		Collections.sort(keys);
		Rotation rotation = Rotation.KEINE_ROTATION;
		Schichtfolge schichtfolge = new Schichtfolge();
		ArrayList<Schicht> schichten = new ArrayList<Schicht>();
		for (String string : keys) {
			if (string.equals("Feld0")) {
				rotation = Rotation.get((String) map.get(string));
			} else {
				schichten.add(Schicht.valueOf((String) map.get(string)));
			}
		}
		schichtfolge.setSchichten(schichten);
		SchichtfolgenFactory schichtfolgenFactory = new SchichtfolgenFactory();
		schichtfolgenFactory.setMusterFolge(schichtfolge);
		schichtfolgenFactory.setRotation(rotation);
		tableMitSchichtFolgenFactoryVelocity2(schichtfolgenFactory);
		return true;
	}

	private void tableMitSchichtFolgenFactoryVelocity2(SchichtfolgenFactory schichtfolgenFactory) {
		List<String> panelList = new ArrayList<String>();
		for (Schichtfolge folge : SchichtmusterFactory.getSchichtfolgenfuerBedarf(schichtfolgenFactory)) {
			panel3.getModel().remove("sf3");
			panel3.addModel("sf3", folge);
			panelList.add(panel3.toString());
		}
		List<String> beschriftungWochentage = new ArrayList<String>();
		for (int i = 0; i < schichtfolgenFactory.getMusterFolge().getSchichten().size(); i++) {
			beschriftungWochentage.add(WOCHENTAGE[i % 7]);
		}

		panel2.getModel().remove("sf");
		panel2.addModel("sf", panelList);
		panel2.getModel().remove("days");
		panel2.addModel("days", beschriftungWochentage);

	}

	public boolean onCancelClick() {
		setForward(getContext().createPage(SchichtfolgenlaengePage.class));
		return true;
	}

	public boolean onFactorySave() {
		Schichtmuster schichtmuster = (Schichtmuster) getContext().getSession().getAttribute(SessionAttributes.SCHICHTMUSTER);
		if (schichtmuster == null) {
			schichtmuster = new Schichtmuster();
		}

		List rowList = musterFolgeTable.getRowList();
		Map map = new HashMap();
		for (Iterator i = rowList.iterator(); i.hasNext();) {
			map = (Map) i.next();
		}
		List<String> keys = new ArrayList<String>(map.keySet());
		Collections.sort(keys);
		Rotation rotation = Rotation.KEINE_ROTATION;
		Schichtfolge schichtfolge = new Schichtfolge();
		ArrayList<Schicht> schichten = new ArrayList<Schicht>();
		for (String string : keys) {
			if (string.equals("Feld0")) {
				rotation = Rotation.get((String) map.get(string));
			} else {
				schichten.add(Schicht.valueOf((String) map.get(string)));
			}
		}
		schichtfolge.setSchichten(schichten);
		SchichtfolgenFactory schichtfolgenFactory = new SchichtfolgenFactory();
		schichtfolgenFactory.setMusterFolge(schichtfolge);
		schichtfolgenFactory.setRotation(rotation);

		SchichtmusterFactory.addSchichtfolgenFactory(schichtmuster, schichtfolgenFactory);
		getContext().getSession().setAttribute(SessionAttributes.SCHICHTMUSTER, schichtmuster);
		tableMitSchichtFolgenFactoryVelocity2(schichtfolgenFactory);
		message = schichtmuster.toString();
		setForward(getContext().createPage(SchichtmusterPage.class));

		return true;
	}
}
