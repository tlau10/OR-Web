package de.htwg.konstanz.schichtplanung.page.schichtplan;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import bedarf.Bedarf;
import bedarf.TagesBedarf;
import net.sf.click.control.Panel;
import ausgabe.Ausgabe;
import ausgabe.Schichtplan;
import de.htwg.konstanz.schichtplanung.page.BorderPage;
import de.htwg.konstanz.schichtplanung.page.solver.SolvePage;
import de.htwg.konstanz.schichtplanung.utils.SessionAttributes;

public class SchichtplanPage extends BorderPage {
	public String title = "Schichtplan";

	public String string = "";
	
	public Panel bedarftagpanel = new Panel("bedarftagpanel", "schichtplan/bedarftagpanel.htm");
	
	public Panel deckungpanel = new Panel("deckungpanel", "schichtplan/deckungpanel.htm");
	
	public Panel ueberunterdeckungpanel = new Panel("ueberunterdeckungpanel", "schichtplan/ueberunterdeckungpanel.htm");
	
	public Panel tageszeile= new Panel("tageszeile", "schichtplan/tageszeile.htm");
	
	public Panel ausgabepanel = new Panel("ausgabepanel","schichtplan/ausgabepanel.htm");
	
	private static final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy");
	

	@Override
	public void onInit() {
		super.onInit();
		Schichtplan schichtplan = (Schichtplan) getContext().getSession().getAttribute(SessionAttributes.SCHICHTPLAN);
		if(schichtplan == null){
			setForward(getContext().createPage(SolvePage.class));
		}else{
			Bedarf bedarf = (Bedarf) getContext().getSession().getAttribute(SessionAttributes.BEDARF);

			List<TagesBedarf> tagesbedarfList = new ArrayList<TagesBedarf>(bedarf.getBedarf().values());

			Collections.sort(tagesbedarfList);
			
			List<Map<String, String>> zeilen = new ArrayList<Map<String, String>>();
			for(int i =0; i<tagesbedarfList.size();i++){
				Map<String, String> map = new HashMap<String, String>();
				map.put("datum", simpleDateFormat.format(tagesbedarfList.get(i).getDatum().getTime()));
				
				map.put("tagesbedarftable", getTableForTagesbedarf(bedarftagpanel,tagesbedarfList.get(i).getBedarfFrueh().getAnzahlPersonen(),tagesbedarfList.get(i).getBedarfSpaet().getAnzahlPersonen(),tagesbedarfList.get(i).getBedarfNacht().getAnzahlPersonen()));
				List<Map<String, String>> ausgabenList = new ArrayList<Map<String,String>>();
				int deckungFrueh=0;
				int deckungSpaet=0;
				int deckungNacht=0;
				for(Ausgabe ausgabe: schichtplan.getAusgabe()){
					if(ausgabe.getAnzahlSchichtfolgen()>0){
					Map<String, String> ausgabeMap = new HashMap<String, String>();
					ausgabeMap.put("anzahl", ""+ausgabe.getAnzahlSchichtfolgen());
					ausgabeMap.put("typ", ausgabe.getSchichtfolge().getSchichten().get(i).toString());
					ausgabenList.add(ausgabeMap);
					
					switch (ausgabe.getSchichtfolge().getSchichten().get(i)) {
					case FRUEHSCHICHT:
						deckungFrueh = deckungFrueh+ ausgabe.getAnzahlSchichtfolgen();
						break;
					case SPAETSCHICHT:
						deckungSpaet = deckungSpaet+ausgabe.getAnzahlSchichtfolgen();
						break;
					case NACHTSCHICHT:
						deckungNacht = deckungNacht + ausgabe.getAnzahlSchichtfolgen();
						break;
					}
					}
				}
				map.put("deckung", getTableForTagesbedarf(deckungpanel,deckungFrueh, deckungSpaet, deckungNacht));
				map.put("ueberdeckung", getTableForTagesbedarf(ueberunterdeckungpanel,deckungFrueh-tagesbedarfList.get(i).getBedarfFrueh().getAnzahlPersonen(),deckungSpaet-tagesbedarfList.get(i).getBedarfSpaet().getAnzahlPersonen(),deckungNacht-tagesbedarfList.get(i).getBedarfNacht().getAnzahlPersonen()));
				ausgabepanel.getModel().remove("ausgabenList");
				ausgabepanel.addModel("ausgabenList", ausgabenList);
				map.put("ausgabentable", ausgabepanel.toString());
				zeilen.add(map);
				
			}
			tageszeile.getModel().remove("zeilen");
			tageszeile.addModel("zeilen", zeilen);
			string = string + tageszeile.toString();
		}
		
	}


	private String getTableForTagesbedarf(Panel currentPanel, int frueh, int spaet, int nacht) {
		currentPanel.getModel().remove("frueh");
		currentPanel.addModel("frueh", frueh);
		currentPanel.getModel().remove("spaet");
		currentPanel.addModel("spaet", spaet);
		currentPanel.getModel().remove("nacht");
		currentPanel.addModel("nacht", nacht);
		return currentPanel.toString();
	}
}
