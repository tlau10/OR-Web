package de.htwg.konstanz.schichtplanung.page.solver;

import solver.MopsSolver;
import solver.MopsSolverGoal;
import de.htwg.konstanz.schichtplanung.utils.SessionAttributes;

public class SolveGoalPage extends SolvePage {
	private Integer ueber = null;
	private Integer unter = null;

	@Override
	public MopsSolver getMopsSolver() {
		ueber = (Integer) getContext().getSession().getAttribute(
				SessionAttributes.GOAL_UEBER_SCHREITUNG);
		unter = (Integer) getContext().getSession().getAttribute(
				SessionAttributes.GOAL_UNTER_SCHREITUNG);

		return new MopsSolverGoal(ueber, unter);
	}
}
