package de.htwg.konstanz.schichtplanung.page.solver;

import java.io.FileNotFoundException;
import java.io.IOException;

import resources.MopsResources;
import schichtmuster.Schichtmuster;
import solver.InfeasibleException;
import solver.MopsSolver;
import solver.NichtOptimalException;
import solver.UnboundedException;
import ausgabe.Schichtplan;
import bedarf.Bedarf;
import de.htwg.konstanz.schichtplanung.page.BorderPage;
import de.htwg.konstanz.schichtplanung.page.schichtplan.SchichtplanPage;
import de.htwg.konstanz.schichtplanung.utils.SessionAttributes;

public class SolvePage extends BorderPage {

	public String message = "";
	public String title = "Solver";

	public SolvePage() {
	}

	public MopsSolver getMopsSolver() {
		// TODO Auto-generated method stub
		return new MopsSolver();
	}

	/**
	 * JavaDoc by fafilipp: Beim Erstellen dieser Klasse wird die onInit()
	 * Methode ausgeführt. Hierzu werden die Eingabedaten aus der Session geholt
	 * (Bedarf und Schichtmuster) und daraufhin mittels den Mops-Solver
	 * optimiert. Der erzeugte Schichtplan wird daraufhin visualisiert.
	 */
	@Override
	public void onInit() {
		// Bedarf und Schichtmuster einlesen
		Bedarf bedarf = (Bedarf) getContext().getSession().getAttribute(SessionAttributes.BEDARF);
		Schichtmuster schichtmuster = (Schichtmuster) getContext().getSession().getAttribute(SessionAttributes.SCHICHTMUSTER);

		try {
			// Begin of Change fafilipp
			// CurrentDir ist ein Temp-Verzeichnis welches von der Session des
			// Benutzers abhängt
			String currentDir = MopsResources.prepareCurrentDir(getContext().getSession().getId().substring(0, 7));
			// End of Change
			if (bedarf == null) {
				message = message + "Bedarf muss eingegeben werden<br>";
			}
			if (schichtmuster == null) {
				message = message + "Schichtmuster muss angegeben werden";
			}
			if (bedarf != null && schichtmuster != null) {
				Schichtplan schichtplan = new Schichtplan();
				try {
					// Begin of Change fafilipp
					schichtplan = getMopsSolver().optimiere(currentDir, schichtmuster, bedarf);
					// End of Change
					getContext().getSession().setAttribute(SessionAttributes.SCHICHTPLAN, schichtplan);
					setForward(getContext().createPage(SchichtplanPage.class));
				} catch (FileNotFoundException e) {
					message = message + " FileNotFoundException: " + e.getMessage();
					e.printStackTrace(); // For Debug Messages
				} catch (IOException e) {
					message = message + " IOException:" + e.getMessage();
					e.printStackTrace(); // For Debug Messages
				} catch (UnboundedException e) {
					message = message + " UnboundedException: " + e.getMessage();
					e.printStackTrace(); // For Debug Messages
				} catch (InfeasibleException e) {
					message = message + " Das eigegebene Modell ist nicht lösbar.";
					e.printStackTrace(); // For Debug Messages
				} catch (NichtOptimalException e) {
					message = message + " Es wurde keine Optimallösung gefunden.";
					e.printStackTrace(); // For Debug Messages
				} catch (InterruptedException e) {
					message = message + " Der Solveraufruf wurde unterbrochen: " + e.getMessage();
					e.printStackTrace(); // For Debug Messages
				}
			}
			// Begin of Change fafilipp
			// Das Temp-Verzeichnis wird bis auf die Eingabedatei geleert (Die
			// Eingabedatei wird für den Export des LP-Ansatzes gebraucht)
			MopsResources.cleanDirectory(currentDir);
			// End of Change
		} catch (NullPointerException e) {
			message = message + " Die Mops.exe konnte nicht gefunden werden. Es ist kein Solven möglich!";
		} catch (IOException e) {
			message = message + e.getMessage() + "<br>";
		}

	}
}
