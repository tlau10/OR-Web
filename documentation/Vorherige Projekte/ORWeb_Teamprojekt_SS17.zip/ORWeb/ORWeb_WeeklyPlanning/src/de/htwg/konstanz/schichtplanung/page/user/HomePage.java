package de.htwg.konstanz.schichtplanung.page.user;

import de.htwg.konstanz.schichtplanung.page.BorderPage;

public class HomePage extends BorderPage {

    public String title = "Home";

}
