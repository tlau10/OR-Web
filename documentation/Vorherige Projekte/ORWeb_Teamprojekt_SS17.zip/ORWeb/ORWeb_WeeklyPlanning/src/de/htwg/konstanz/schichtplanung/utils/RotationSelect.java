package de.htwg.konstanz.schichtplanung.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.sf.click.control.Option;
import net.sf.click.control.Select;
import schichtmuster.Rotation;

public class RotationSelect extends Select {
	static final List ROTATION_OPTIONS = new ArrayList();
	static{
		
		for(Rotation rotation:Rotation.values()){
			ROTATION_OPTIONS.add(new Option(rotation.toString()));
		}
	}
		

	public RotationSelect() {
		super();
		setOptionList(ROTATION_OPTIONS);
	}

	public RotationSelect(String name) {
		super(name);
		setOptionList(ROTATION_OPTIONS);

	}
}
