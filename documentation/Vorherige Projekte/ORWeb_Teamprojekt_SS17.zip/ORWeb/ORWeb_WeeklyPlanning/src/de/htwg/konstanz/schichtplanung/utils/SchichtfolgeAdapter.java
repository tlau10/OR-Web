package de.htwg.konstanz.schichtplanung.utils;

import java.awt.*;

import schichtmuster.Schicht;
import schichtmuster.Schichtfolge;

public class SchichtfolgeAdapter {
	
	private Schichtfolge schichtfolge;
	
	public SchichtfolgeAdapter(Schichtfolge schichtfolge) {
		this.schichtfolge = schichtfolge;
	}
	public String getMo(){
		return schichtfolge.getSchichten().get(0).toString();
	}
	public String getDi(){
		return schichtfolge.getSchichten().get(1).toString();
	}
	public String getMi(){
		return schichtfolge.getSchichten().get(2).toString();
	}
	public String getDo(){
		return schichtfolge.getSchichten().get(3).toString();
	}
	public String getFr(){
		return schichtfolge.getSchichten().get(4).toString();
	}
	public String getSa(){
		return schichtfolge.getSchichten().get(5).toString();
	}
	public String getSo(){
		return schichtfolge.getSchichten().get(6).toString();
	}

	
	public void setMo(String str){
		schichtfolge.getSchichten().set(0, Schicht.valueOf(str));
	} 
	public void setDi(String str){
		schichtfolge.getSchichten().set(1, Schicht.valueOf(str));
	} 
	public void setMi(String str){
		schichtfolge.getSchichten().set(2, Schicht.valueOf(str));
	} 
	public void setDo(String str){
		schichtfolge.getSchichten().set(3, Schicht.valueOf(str));
	} 
	public void setFr(String str){
		schichtfolge.getSchichten().set(4, Schicht.valueOf(str));
	} 
	public void setSa(String str){
		schichtfolge.getSchichten().set(5, Schicht.valueOf(str));
	} 
	public void setSo(String str){
		schichtfolge.getSchichten().set(6, Schicht.valueOf(str));
	} 

	
	public Schichtfolge getSchichtfolge(){
		return schichtfolge;
	}
	


}
