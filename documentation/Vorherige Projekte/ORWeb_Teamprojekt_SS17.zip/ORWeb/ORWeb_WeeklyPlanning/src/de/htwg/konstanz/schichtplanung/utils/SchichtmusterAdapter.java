package de.htwg.konstanz.schichtplanung.utils;

public class SchichtmusterAdapter {
	
	int textFieldValue;
	
	public SchichtmusterAdapter(int textFieldValue){
		//Standard Wochentage
		this.textFieldValue = textFieldValue;
	}

	public int getTextFieldValue() {
		return textFieldValue;
	}

	public void setTextFieldValue(int textFieldValue) {
		this.textFieldValue = textFieldValue;
	}
	
	

}
