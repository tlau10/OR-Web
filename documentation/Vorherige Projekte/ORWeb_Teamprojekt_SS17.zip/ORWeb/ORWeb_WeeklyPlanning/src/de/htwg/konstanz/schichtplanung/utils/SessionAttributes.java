package de.htwg.konstanz.schichtplanung.utils;

/**
 * Diese Klasse beinhaltet die Strings, Keys die verwendet werden um Daten im SessionContext abzulegen
 * 
 * @author drossman
 *
 */public class SessionAttributes {
	private SessionAttributes() {

	}

	public static final String BEDARF = "bedarf";
	public static final String SCHICHTMUSTER = "schichtmuster";
	public static final String SCHICHTPLAN = "schichtplan";
	
	public static final String GOAL_UEBER_SCHREITUNG = "gewichtueberschreitung";
	public static final String GOAL_UNTER_SCHREITUNG = "gewichtunterschreitung";

}
