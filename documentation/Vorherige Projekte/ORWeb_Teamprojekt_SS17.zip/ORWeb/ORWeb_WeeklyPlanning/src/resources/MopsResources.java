package resources;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Die Ressourcen Utility Klasse für den MopsSolver. Diese Klasse kümmert sich
 * um das Vorbereiten des Arbeitsverzeichnisses. Das Arbeitsverzeichnis stellt
 * sich zusammen aus "tmpDir"\"projectName"\"sessionId".
 * 
 * @author Fabio Filippelli (fafilipp)
 */
public class MopsResources {

	/**
	 * Keine Instanzierung dieser Klasse erlaubt, nur statische Methoden
	 * vorhanden.
	 * 
	 * @throws Exception
	 *             Keine Instanzierung von MopsResources erlaubt
	 */
	private MopsResources() throws Exception {
		throw new Exception("Keine Instanzierung von MopsResources erlaubt");
	}

	/**
	 * Diese Methode ist eine Hilfsmethode um das Kopieren der mops.exe in den
	 * eingegebenen Pfad zu ermöglichen.
	 * 
	 * @param currentDir
	 *            Der temporäre Arbeitsverzeichnis wohin die mops.exe kopiert
	 *            werden muss
	 * @throws IOException
	 *             Falls dieses Programm in den Verzeichnis keine Schreibrechte
	 *             besitzt oder Schreibfehler auftauchen.
	 */
	public static void copyMopsExeTo(File currentDir) throws IOException {
		// Checkt ob es den Verzeichnis schon gibt und prüft -d und
		// Schreibrechte
		if (!currentDir.canWrite()) {
			throw new IOException("Keine Schreibrechte in " + currentDir.getAbsolutePath());
		}

		// Starte den Kopiervorgang der mops.exe
		InputStream is = MopsResources.class.getResourceAsStream("mops.exe");
		StringBuilder filePath = new StringBuilder(currentDir.getAbsolutePath());
		filePath.append("\\mops.exe");
		FileOutputStream fos = new FileOutputStream(filePath.toString());
		byte[] buffer = new byte[1024];
		int read = 0;
		while ((read = is.read(buffer)) != -1) {
			fos.write(buffer, 0, read);
			fos.flush();
		}
		is.close();
		fos.close();
	}

	/**
	 * Bereitet das Arbeitsverzeichnis für die Solverausführung vor. Diese
	 * Klasse prüft jeden Verzeichnis und erstellt ein Verzeichnis, falls dieser
	 * nicht vorhanden ist.
	 * 
	 * @param currentId
	 *            Die gesplittete SessionId (8 Zeichen)
	 * @return der vollständige Pfad zum Arbeitsverzeichniss.
	 * @throws IOException
	 *             falls Probleme auftauchen w�hrend dem Schreiben in das
	 *             Dateisystem.
	 */
	public static String prepareCurrentDir(String currentId) throws IOException {
		String workingDirPath = UtilityProperties.getInstance().getWorkingDir();
		String projectName = UtilityProperties.getInstance().getProjectName();

		// Pr�ft ob das Arbeitsverzeichnis vorhanden ist, wenn nicht wird dieser
		// erstellt.
		File workingDir = new File(workingDirPath);
		if (!workingDir.exists()) {
			workingDir.mkdir();
		}

		// Pr�ft ob das Projektverzeichnis vorhanden ist, wenn nicht wird dieser
		// erstellt.
		StringBuilder projectDirPath = new StringBuilder(workingDir.getAbsolutePath());
		projectDirPath.append("\\").append(projectName);
		File projectDir = new File(projectDirPath.toString());
		if (!projectDir.exists()) {
			projectDir.mkdir();
		}

		// Pr�ft ob das Tempor�re Verzeichnis bereits besteht, wenn nicht wird
		// dieser erstellt.
		StringBuilder currentDirPath = new StringBuilder(projectDir.getAbsolutePath());
		currentDirPath.append("\\").append(currentId);
		File currentDir = new File(currentDirPath.toString());
		if (!currentDir.exists()) {
			currentDir.mkdir();
		}

		copyMopsExeTo(currentDir);

		return currentDir.getAbsolutePath();
	}

	/**
	 * Löscht alle Daten, außer die MPS Datei aus dem aktuellen
	 * Arbeitsverzeichnis, nachdem die L�sung angezeigt worden ist. Grund:
	 * Festplattenplatz sparen, Fehler vermeiden.
	 * 
	 * @param currentDirPath
	 *            Der Pfad des aktuellen Arbeitsverzeichnis
	 */
	public static void cleanDirectory(String currentDirPath) {
		File currentDir = new File(currentDirPath);
		if (currentDir.exists()) {
			File[] files = currentDir.listFiles();
			try {
				for (File file : files) {
					if (!file.getName().endsWith(".mps")) {
						// alles löschen, bis auf das mps file... da dies für
						// die
						// generierung des LP-Ansatzes benötigt wird.
						file.delete();
					}
				}
			} catch (Exception e) {
				// wenn löschen nicht funktioniert, dann ignorieren
				e.printStackTrace();
			}
		}
	}

}
