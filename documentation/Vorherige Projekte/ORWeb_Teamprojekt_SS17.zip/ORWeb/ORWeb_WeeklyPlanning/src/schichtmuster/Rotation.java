/**
 * 
 */
package schichtmuster;

/**
 * <!-- begin-user-doc --> <!-- end-user-doc -->
 * 
 * @author drossman
 * 
 * @generated 
 *            "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public enum Rotation {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated 
	 *            "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	KEINE_ROTATION {
		@Override
		public String toString() {
			return "Keine Rotation";
		}
	},
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated 
	 *            "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	WOECHENTLICHE_ROTATION {
		@Override
		public String toString() {
			return "Wöchentliche Rotation";
		}
	},
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated 
	 *            "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	TAEGLICHE_ROTATION {
		@Override
		public String toString() {
			return "Tägliche Rotation";
		}
	};

	@Override
	public abstract String toString();

	public static Rotation get(String name) {
		if (name.equals("Tägliche Rotation")) {
			return TAEGLICHE_ROTATION;
		} else if (name.equals("Wöchentliche Rotation")) {
			return WOECHENTLICHE_ROTATION;
		} else {
			return KEINE_ROTATION;
		}
	}
}