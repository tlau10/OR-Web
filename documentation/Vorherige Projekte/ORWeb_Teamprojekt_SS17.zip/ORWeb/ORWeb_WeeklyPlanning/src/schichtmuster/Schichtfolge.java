/**
 * 
 */
package schichtmuster;

import java.util.ArrayList;

/**
 * <!-- begin-user-doc --> <!-- end-user-doc -->
 * 
 * @author drossman
 * 
 * @generated 
 *            "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */

public class Schichtfolge {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated 
	 *            "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private SchichtfolgenID schichtfolgenid;
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated 
	 *            "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private ArrayList<Schicht> schichten;

	public Schichtfolge() {
		schichten = new ArrayList<Schicht>();

	}

	public Schichtfolge(ArrayList<Schicht> o) {
		schichten = (ArrayList<Schicht>) o.clone();

	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return schichtfolgenid
	 * @generated 
	 *            "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public SchichtfolgenID getSchichtfolgenid() {
		// begin-user-code
		return schichtfolgenid;
		// end-user-code
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < schichten.size(); i++) {

			sb.append(schichten.get(i) + "\n");
		}

		return sb.toString();

	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param dededscihflei
	 *            Festzulegender schichtfolgenid
	 * @generated 
	 *            "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setSchichtfolgenid(SchichtfolgenID dededscihflei) {
		// begin-user-code
		schichtfolgenid = dededscihflei;
		// end-user-code
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return schichten
	 * @generated 
	 *            "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public ArrayList<Schicht> getSchichten() {
		// begin-user-code
		return schichten;
		// end-user-code
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param dededscihe
	 *            Festzulegender schichten
	 * @generated 
	 *            "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setSchichten(ArrayList<Schicht> dededscihe) {
		// begin-user-code
		schichten = (ArrayList<Schicht>) dededscihe.clone();
		// end-user-code
	}

	public void addSchichten(ArrayList<Schicht> input) {
		for (Schicht run : input) {
			schichten.add(run);
		}

	}
}