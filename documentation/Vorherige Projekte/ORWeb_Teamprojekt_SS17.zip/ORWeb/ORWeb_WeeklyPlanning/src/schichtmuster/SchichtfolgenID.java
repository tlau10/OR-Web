/**
 * 
 */
package schichtmuster;

/** 
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @author drossman
 * 
 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class SchichtfolgenID {
	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Integer id;

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return id
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Integer getId() {
		// begin-user-code
		return id;
		// end-user-code
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param dededsd Festzulegender id
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setId(Integer dededsd) {
		// begin-user-code
		id = dededsd;
		// end-user-code
	}
}