package solver;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 
 * @author Teamprojekt - Solvergruppe
 * @version 1.0
 * 
 *          Klasse ueberpr�ft, ob eine optimal Loesung erreicht wurde.
 * 
 */
public class CheckOptimal {
	private static final Properties properties = new Properties();
	static {

		try {
			properties.load(CheckOptimal.class.getResourceAsStream("Solver.properties"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Methode liest LP_Status und wirft, falls das Ergebnis nicht optimal ist
	 * eine entsprechende Exception
	 * 
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws UnboundedException
	 * @throws InfeasibleException
	 * @throws NichtOptimalException
	 */
	// Begin of Change fafilipp
	public void checkOptimalLoesung(String currentDir) throws FileNotFoundException, IOException, UnboundedException, InfeasibleException,
			NichtOptimalException {
		BufferedReader test = new BufferedReader(new FileReader(currentDir + "\\"
				+ properties.getProperty("LP_CheckOptimal_MopsdateiCheckOptimal")));
		// End of Change

		Pattern lpP = Pattern.compile("LP-status");
		String status = "";

		while (test.ready() != false) {
			String currentLine = test.readLine();
			Matcher lpMatcher = lpP.matcher(currentLine);

			if (lpMatcher.find()) {

				Pattern unboundedPattern = Pattern.compile("unbounded");
				Pattern infeasiblePattern = Pattern.compile("infeasible");
				Pattern noptimalPattern = Pattern.compile("nicht optimal");

				Matcher matcherUnbounded = unboundedPattern.matcher(currentLine);
				Matcher matcherInfeasible = infeasiblePattern.matcher(currentLine);
				Matcher matcherNOptimal = noptimalPattern.matcher(currentLine);

				if (matcherUnbounded.find()) {
					status = currentLine.substring(matcherUnbounded.start(), matcherUnbounded.end());
					// System.out.println(status);
				} else if (matcherInfeasible.find()) {
					status = currentLine.substring(matcherInfeasible.start(), matcherInfeasible.end());
					// System.out.println(status);
				} else if (matcherNOptimal.find()) {
					status = currentLine.substring(matcherNOptimal.start(), matcherNOptimal.end());
					// System.out.println(status);
				}
			}
		}

		if (status.equals("unbounded")) {
			throw new UnboundedException();
		}
		if (status.equals("infeasible")) {
			throw new InfeasibleException();
		}
		if (status.equals("nicht optimal")) {
			throw new NichtOptimalException();
		}
		test.close();
	}
}
