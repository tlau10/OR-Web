package solver;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import schichtmuster.Rotation;
import schichtmuster.Schicht;
import schichtmuster.Schichtfolge;
import schichtmuster.SchichtfolgenFactory;
import schichtmuster.Schichtmuster;
import schichtmuster.SchichtmusterFactory;

import bedarf.Bedarf;
import bedarf.BedarfFactory;
import bedarf.TagesBedarf;


/**
 * Die CreateLPMatrix
 * Eine Klasse die eine LP-Matrix zur Veranschaulichung des OR-Modells generiert.
 *
 * @author Solvergruppe (Mesut Deniz, Florian Moosmann, Lukas Lewandowski)
 * @version 1.0
 */

public class CreateLPMatrix {
	private static final String ZWEI_LEERZEICHEN = "  ";
    private boolean ausfuehren=true;
	
	/** 
     * Die Methode createLPMatrix erstellt aus dem Bedarf, sowie aus der Schichtfolge die LPMatrix zum visualisieren des LP Modells.
     * Diese Matrix wird im Tool selbst nicht weiterverwendet. Sie gilt lediglich zur Visualisierung des OR-Modells bzw der LP-Matrix.
     * Das Ergebnis kann in einer TXT-Datei gespeichert werden. Man kann diese Datei dann jederzeit mit einem EDITOR �ffnen und anschauen
     *
     * @param rotiertSchichtfolgen ArrayList mit Schichtfolgen welche �berwegen werden
     * @param bedarf2 Bedarf der �bergeben wird
     * @throws IOException Schmei�t eine Exception wenn die Eingabe der Properties fehlschl�gt
     * 
     */
	
	public  void createLPMatrix(ArrayList<Schichtfolge> rotiertSchichtfolgen, Bedarf bedarf2) throws IOException {
		int i = 0, j = 0, k = 0, m = 0;
		ArrayList<Schichtfolge> schichtFolgen = rotiertSchichtfolgen;
		if(schichtFolgen.size()<101){
		m = schichtFolgen.size();
		
		String[][] feld3;

		StringBuffer dataSet = new StringBuffer();

		List<TagesBedarf> list = new ArrayList<TagesBedarf>(bedarf2.getBedarf()
				.values());
		Collections.sort(list);

		dataSet
				.append("Das ist die Matrix des LP-Modells für das Projekt: Schichtplanung SS08 von D. Rossmann, F. Moosmann, P. Lang, M. Deniz, D. Benz und L. Lewandowski ");
		dataSet.append("\r\n");
		dataSet.append("\r\n");
		dataSet
				.append("Bemerkungen: Die X-Variablen stehen für die Schichtalternativen. Die Rn-Restriktionen stehen für die Wochentage (Mo-So Früh, Mo-So Spät, Mo-So Nacht)");
		dataSet.append("\r\n");
		dataSet.append("\r\n");
		StringBuffer norris = new StringBuffer("          ");
		for (int kick = 0; kick < m; kick++) {
			norris.append("X" + (kick + 1) + " ");
		}
		norris.append("\r\n");

	

		StringBuffer chuck = new StringBuffer("ZF        ");
		for (int kick = 0; kick < m; kick++) {
			chuck.append("1  ");
			if (kick > 8) {
				chuck.append(" ");
			}
			if (kick > 98) {
				chuck.append(" ");
			}
		}
		chuck.append("   -->min! \r\n");
	
		dataSet.append(norris);
		dataSet.append(chuck);

		feld3 = new String[schichtFolgen.size()][];
		int z = 0, x = 0, y = 0, v = 0;

		int anzahlRestrikitionen = 3 * ((Schichtfolge) schichtFolgen.get(0))
				.getSchichten().size();
		StringBuffer[] restriktionenArray = new StringBuffer[anzahlRestrikitionen];
		for (int laufvariable = 0; laufvariable < restriktionenArray.length; laufvariable++) {
			if (laufvariable < 9) {
				restriktionenArray[laufvariable] = new StringBuffer("R"
						+ (laufvariable + 1) + "      ");
			} else {
				if (laufvariable < 99) {
					restriktionenArray[laufvariable] = new StringBuffer("R"
							+ (laufvariable + 1) + "     ");
				} else {
					if (laufvariable < 999) {
						restriktionenArray[laufvariable] = new StringBuffer("R"
								+ (laufvariable + 1) + "    ");
					}
				}
			}

		}
		for (Schichtfolge run : schichtFolgen) {
			for (int laufvariable = 0; laufvariable < restriktionenArray.length / 3; laufvariable++) {
				Schicht currentSchicht = run.getSchichten().get(laufvariable);
				switch (currentSchicht) {
				case FRUEHSCHICHT:
					restriktionenArray[laufvariable]
							.append(ZWEI_LEERZEICHEN + 1);
					restriktionenArray[laufvariable
							+ (restriktionenArray.length) / 3]
							.append(ZWEI_LEERZEICHEN + 0);
					restriktionenArray[laufvariable + 2
							* (restriktionenArray.length) / 3]
							.append(ZWEI_LEERZEICHEN + 0);
					break;
				case SPAETSCHICHT:
					restriktionenArray[laufvariable]
							.append(ZWEI_LEERZEICHEN + 0);
					restriktionenArray[laufvariable
							+ (restriktionenArray.length) / 3]
							.append(ZWEI_LEERZEICHEN + 1);
					restriktionenArray[laufvariable + 2
							* (restriktionenArray.length) / 3]
							.append(ZWEI_LEERZEICHEN + 0);

					break;
				case NACHTSCHICHT:
					restriktionenArray[laufvariable]
							.append(ZWEI_LEERZEICHEN + 0);
					restriktionenArray[laufvariable
							+ (restriktionenArray.length) / 3]
							.append(ZWEI_LEERZEICHEN + 0);
					restriktionenArray[laufvariable + 2
							* (restriktionenArray.length) / 3]
							.append(ZWEI_LEERZEICHEN + 1);

					break;
				default:
					restriktionenArray[laufvariable]
							.append(ZWEI_LEERZEICHEN + 0);
					restriktionenArray[laufvariable
							+ (restriktionenArray.length) / 3]
							.append(ZWEI_LEERZEICHEN + 0);
					restriktionenArray[laufvariable + 2
							* (restriktionenArray.length) / 3]
							.append(ZWEI_LEERZEICHEN + 0);

				}

			}
		}
		for (TagesBedarf tagesBedarf : list) {
			i++;
			if (i < 10) {
				if (tagesBedarf.getBedarfFrueh().getAnzahlPersonen() != 0)
					restriktionenArray[i - 1].append("   >= "
							+ tagesBedarf.getBedarfFrueh().getAnzahlPersonen()
									.toString());
			} else if (i < 100) {
				if (tagesBedarf.getBedarfFrueh().getAnzahlPersonen() != 0)
					restriktionenArray[i - 1].append("   >= "
							+ tagesBedarf.getBedarfFrueh().getAnzahlPersonen()
									.toString());
			} else {
				if (tagesBedarf.getBedarfFrueh().getAnzahlPersonen() != 0)
					restriktionenArray[i - 1].append("   >= "
							+ tagesBedarf.getBedarfFrueh().getAnzahlPersonen()
									.toString());
			}

		}
		for (TagesBedarf tagesBedarf : list) {

			i++;
			if ((i) < 10) {
				if (tagesBedarf.getBedarfSpaet().getAnzahlPersonen() != 0)
					restriktionenArray[i - 1].append("   >= "
							+ tagesBedarf.getBedarfSpaet().getAnzahlPersonen()
									.toString());
			} else if ((i) < 100) {
				if (tagesBedarf.getBedarfSpaet().getAnzahlPersonen() != 0)
					restriktionenArray[i - 1].append("   >= "
							+ tagesBedarf.getBedarfSpaet().getAnzahlPersonen()
									.toString());
			} else {
				if (tagesBedarf.getBedarfSpaet().getAnzahlPersonen() != 0)
					restriktionenArray[i - 1].append("   >= "
							+ tagesBedarf.getBedarfSpaet().getAnzahlPersonen()
									.toString());
			}

		}
		for (TagesBedarf tagesBedarf : list) {

			i++;

			if ((i) < 10) {
				if (tagesBedarf.getBedarfNacht().getAnzahlPersonen() != 0)
					restriktionenArray[i - 1].append("   >= "
							+ tagesBedarf.getBedarfNacht().getAnzahlPersonen()
									.toString());
			} else if ((i) < 100) {
				if (tagesBedarf.getBedarfNacht().getAnzahlPersonen() != 0)
					restriktionenArray[i - 1].append("   >= "
							+ tagesBedarf.getBedarfNacht().getAnzahlPersonen()
									.toString());

			} else {
				if (tagesBedarf.getBedarfNacht().getAnzahlPersonen() != 0)
					restriktionenArray[i - 1].append("   >= "
							+ tagesBedarf.getBedarfNacht().getAnzahlPersonen()
									.toString());
			}

		}

		for (StringBuffer buffer : restriktionenArray) {
			dataSet.append(buffer.toString() + "\r\n");
		}

		dataSet.append("\r\n");

		try {
			Properties properties = new Properties();
			properties.load(CreateLPMatrix.class.getResourceAsStream("Solver.properties"));

			java.io.FileWriter fileWriter1 = new java.io.FileWriter(properties
					.getProperty("LP_Matrix"));
			java.io.PrintWriter printWriter1 = new java.io.PrintWriter(
					fileWriter1);
			printWriter1.println(dataSet);
			printWriter1.flush();
			printWriter1.close();
		} catch (IOException e) {
			e.printStackTrace();
			// _ERROR_MSG += "\nIO error: " + e;
			//myStringVector.add( 0, "error" );
			//myStringVector.add( 1, _ERROR_MSG );
		}
		return;
	}
	}
}
