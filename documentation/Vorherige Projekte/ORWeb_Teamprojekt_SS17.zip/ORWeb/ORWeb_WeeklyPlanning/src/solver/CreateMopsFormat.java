package solver;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import schichtmuster.Schicht;
import schichtmuster.Schichtfolge;
import bedarf.Bedarf;
import bedarf.TagesBedarf;

/**
 * Diese Klasse beinhaltet die Methode createMopsFile Dies ist ein
 * Javadoc-Kommentar.
 * 
 * Diese Methode erstellt die MPS-Datei in dem Format wie es der MOPS-Solver
 * ben�tigt
 * 
 * @author Teamprojekt - Solvergruppe
 * @version 1.0
 */
public class CreateMopsFormat {
	public static final String CRLF = "\r\n";
	private static final Object LEERZEICHEN = " ";
	private static final String LEERZEICHEN_5 = "     ";
	private static final String LEERZEICHEN_6 = "      ";
	private static final String LEERZEICHEN_7 = "       ";
	private static final String LEERZEICHEN_8 = "        ";
	private static final String PUFFER_HINTER_ZF = LEERZEICHEN_8;
	/**
	 * Properties werden hier geladen. D.h. die in der Properties
	 * festgeschriebenen Pfade werden hier aufgerufen
	 * 
	 * {@link Solver.properties}
	 * 
	 * @param name
	 *            Solver.properties Hier wird die Propertiesdatei eingelesen
	 * 
	 * @exception classname
	 *                CreateMopsFormat Die FileNotFoundException, wirft eine
	 *                Exception falls die gesuchte Datei nicht gefunden werden
	 *                kann
	 */
	private static final Properties properties = new Properties();
	static {
		try {
			properties.load(CreateMopsFormat.class.getResourceAsStream("Solver.properties"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Die ArrayList vom Typ Schichtfolge, liefert uns unserse rotierten
	 * Schichtfolgen Der bedarf vom Typ Bedarf, liefert uns einen vom Benutzer
	 * eingegebenen Bedarf für einen von Ihm ausgewählten Zeitraum
	 * 
	 * @param rotiertSchichtfolgen
	 * @param bedarf2
	 * @throws IOException
	 */
	// Begin of Change fafilipp
	public String createMopsFile(String currentDir, ArrayList<Schichtfolge> rotiertSchichtfolgen, Bedarf bedarf2) throws IOException {
		// End of Change
		StringBuffer dataSet = new StringBuffer();

		List<TagesBedarf> list = new ArrayList<TagesBedarf>(bedarf2.getBedarf().values());
		Collections.sort(list);
		dataSet.append("NAME          ModellWochenschichtplanung" + CRLF);
		createRows(dataSet, list.size());
		createColumns(rotiertSchichtfolgen, dataSet, list.size() * 3);

		// Hier wir der b-Vektor mit Werten der einzelnen Restriktionen
		// bef�llt

		createRHS(dataSet, list);
		createBounds(dataSet, rotiertSchichtfolgen.size());
		dataSet.append("ENDATA" + CRLF);

		// Hier wird aus der Solver.properties in den Pfad
		// LP_CreateMops_FileWriter geschrieben

		// Begin of Change fafilipp
		String mpsFilePath = currentDir + "\\" + properties.getProperty("LP_MopsOpt_MopsDatei");
		// End of Change

		FileWriter fileWriter1 = new FileWriter(mpsFilePath);
		PrintWriter printWriter1 = new PrintWriter(fileWriter1);
		printWriter1.println(dataSet);
		printWriter1.flush();
		printWriter1.close();
		return dataSet.toString();
	}

	public void createRows(StringBuffer dataSet, int anzahlTage) {
		createRows(dataSet, anzahlTage, "G");

	}

	/**
	 * 
	 * @param rotiertSchichtfolgen
	 * @param dataSet
	 * @param anzahlRestriktionen
	 * 
	 *            Die Methode createColumns erstellt in dem MPS-File die
	 *            Columns-Area (Hier bekommen die X-Werte ihre Werte den
	 *            Restriktionen zugeordnet)
	 */

	public void createColumns(ArrayList<Schichtfolge> rotiertSchichtfolgen, StringBuffer dataSet, int anzahlRestriktionen) {
		// Hier geben wir die Schichtfolgen ein
		dataSet.append("COLUMNS" + CRLF);
		dataSet.append("    IONW999   'MARKER'                 'INTORG'" + CRLF);

		ArrayList<Schichtfolge> sfolge = rotiertSchichtfolgen;
		int hilfe2 = 0;

		int zfwert = 1;

		for (Schichtfolge run : sfolge) {

			zfwert = getZFWert(run);

			ArrayList<Schicht> schichtArray = run.getSchichten();
			int hilfe = schichtArray.size() - 1;
			String wert = "";

			int restriktionsnr = 1;

			zfwertFuerSchichtfolge(dataSet, hilfe2, zfwert, schichtArray, hilfe);

			for (Schicht runSchicht : schichtArray) {

				// Diese if-Bedingung, bestimmt die Formatierung der
				// Fr�hschicht

				if (runSchicht == Schicht.FRUEHSCHICHT) {
					wert = "1.";

					// else wert="0.";
					dataSet.append("    X" + getZahlPlusLeerzeichen(schichtArray.size() - hilfe + hilfe2, 9) + "R"
							+ getZahlPlusLeerzeichen(restriktionsnr, 9) + wert + CRLF);
				}
				restriktionsnr++;

			}
			for (Schicht runSchicht : schichtArray) {

				// Diese if-Bedingung, bestimmt die Formatierung der
				// Sp�tschicht

				if (runSchicht == Schicht.SPAETSCHICHT) {
					wert = "1.";

					// else wert="0.";
					dataSet.append("    X" + getZahlPlusLeerzeichen(schichtArray.size() - hilfe + hilfe2, 9) + "R"
							+ getZahlPlusLeerzeichen(restriktionsnr, 9) + wert + CRLF);
				}
				restriktionsnr++;
			}
			for (Schicht runSchicht : schichtArray) {

				// Diese if-Bedingung, bestimmt die Formatierung der
				// Nachtschicht

				if (runSchicht == Schicht.NACHTSCHICHT) {
					wert = "1.";

					// else wert="0.";

					dataSet.append("    X" + getZahlPlusLeerzeichen(schichtArray.size() - hilfe + hilfe2, 9) + "R"
							+ getZahlPlusLeerzeichen(restriktionsnr, 9) + wert + CRLF);
				}
				restriktionsnr++;
			}

			hilfe2++;

		}
		dataSet.append("    IENW899   'MARKER'                 'INTEND'" + CRLF);
	}

	/**
	 * 
	 * @param dataSet
	 * @param hilfe2
	 * @param zfwert
	 * @param schichtArray
	 * @param hilfe
	 * 
	 *            In dieser Methode werden die Zielfunktionswerte �bergeben
	 * 
	 */
	public void zfwertFuerSchichtfolge(StringBuffer dataSet, int hilfe2, int zfwert, ArrayList<Schicht> schichtArray, int hilfe) {
		dataSet.append("    X" + getZahlPlusLeerzeichen((schichtArray.size() - hilfe + hilfe2), 9) + "ZF" + getPufferPlusZF(zfwert) + "."
				+ CRLF);
	}

	/**
	 * 
	 * @param dataSet
	 * @param list
	 * 
	 *            In dieser Methode wird RHS-Area erstellt, d.h. hier bekommen
	 *            die Restriktionen ihren B-Vektor zugeordnet
	 */
	public void createRHS(StringBuffer dataSet, List<TagesBedarf> list) {
		dataSet.append("RHS" + CRLF);
		int i = 0;
		for (TagesBedarf tagesBedarf : list) {
			i++;
			if (tagesBedarf.getBedarfFrueh().getAnzahlPersonen() != 0) {
				dataSet.append("    " + "MYRHS" + LEERZEICHEN_5 + "R" + getZahlPlusLeerzeichen(i, 9)
						+ tagesBedarf.getBedarfFrueh().getAnzahlPersonen().toString() + "." + CRLF);
			}
		}
		for (TagesBedarf tagesBedarf : list) {

			i++;
			if (tagesBedarf.getBedarfSpaet().getAnzahlPersonen() != 0) {
				dataSet.append("    " + "MYRHS" + LEERZEICHEN_5 + "R" + getZahlPlusLeerzeichen(i, 9)
						+ tagesBedarf.getBedarfSpaet().getAnzahlPersonen().toString() + "." + CRLF);
			}
		}
		for (TagesBedarf tagesBedarf : list) {

			i++;

			if (tagesBedarf.getBedarfNacht().getAnzahlPersonen() != 0) {
				dataSet.append("    " + "MYRHS" + LEERZEICHEN_5 + "R" + getZahlPlusLeerzeichen(i, 9)
						+ tagesBedarf.getBedarfNacht().getAnzahlPersonen().toString() + "." + CRLF);
			}

		}
	}

	/**
	 * 
	 * @param dataSet
	 * @param anzahlVariablen
	 * 
	 *            In dieser Methode wird die Bounds-Area gesetzt, d.h. die
	 *            Von-bis Bereiche einer Variable werden hier festgelegt
	 */
	public void createBounds(StringBuffer dataSet, int anzahlVariablen) {
		dataSet.append("BOUNDS" + CRLF);
		for (int i = 0; i < anzahlVariablen; i++) {
			dataSet.append(" UP MYBOUND   " + "X" + getZahlPlusLeerzeichen(i + 1, 9) + "32767" + CRLF);
		}
	}

	/**
	 * 
	 * @param zahl
	 * @param laengeMitLeerzeichen
	 * @return Das ist eine Methode die die Leerzeichen berechnet, die gebraucht
	 *         werden um das MPS-File in der richtigen Formatierung
	 *         darzustellen.
	 */
	public final String getZahlPlusLeerzeichen(int zahl, int laengeMitLeerzeichen) {
		StringBuffer buffer = new StringBuffer("" + zahl);
		int anfang = 1;
		for (int i = 1; i < laengeMitLeerzeichen; i++) {
			anfang = anfang * 10;
		}

		while (zahl < anfang) {
			// System.out.println("FUEGE LEERZEICHEN HINZU");
			buffer.append(LEERZEICHEN);
			anfang = anfang / 10;
		}
		return buffer.toString();
	}

	/**
	 * 
	 * @param dataSet
	 * @param anzahlTage
	 * @param operator
	 * 
	 *            Diese Methode erstellt die Rows, d.h. der Teil des MPS Formats
	 *            welcher verantwortlich ist den Restriktionen den Operator
	 *            zuzuweisen (<=,>=,=)
	 */
	public void createRows(StringBuffer dataSet, int anzahlTage, String operator) {
		dataSet.append("ROWS" + CRLF);
		dataSet.append(" N  ZF" + CRLF);

		int anzahlSchichten = anzahlTage * 3;

		for (int i = 0; i < anzahlSchichten; i++) {
			dataSet.append(" " + operator + "  R" + (i + 1) + CRLF);
		}
	}

	/**
	 * 
	 * @param zfwert
	 * @return Hier wird der Puffer(Leerzeichen) f�r den Zielfunktionswert
	 *         berechnet (Formatierung f�r das MPS-Format)
	 */

	public final String getPufferPlusZF(int zfwert) {
		if (zfwert < 10) {
			return LEERZEICHEN_8 + zfwert;
		}
		if (zfwert < 100) {
			return LEERZEICHEN_7 + zfwert;
		}
		if (zfwert < 1000) {
			return LEERZEICHEN_6 + zfwert;
		} else {
			return LEERZEICHEN_5 + zfwert;
		}

	}

	/**
	 * 
	 * @param run
	 * @return Diese Methode liefert den Zielfunktionswert f�r eine �bergebene
	 *         Schichtfolge
	 * 
	 */
	public int getZFWert(Schichtfolge run) {
		int roundhouse = 0;
		for (Schicht ch : run.getSchichten()) {
			if (ch == Schicht.FRUEHSCHICHT || ch == Schicht.NACHTSCHICHT || ch == Schicht.SPAETSCHICHT) {
				roundhouse++;
			}
		}
		// System.out.println("Roundhouse" + roundhouse);
		return roundhouse;
	}
}