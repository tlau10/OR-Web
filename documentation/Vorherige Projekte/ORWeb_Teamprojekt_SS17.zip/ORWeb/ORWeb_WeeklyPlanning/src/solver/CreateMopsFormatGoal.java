package solver;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

import schichtmuster.Schicht;
import schichtmuster.Schichtfolge;
import bedarf.Bedarf;

/**
 * Diese Klasse beinhaltet die Methode createMopsFile Dies ist ein
 * Javadoc-Kommentar.
 * 
 * Diese Methode erstellt die MPS-Datei in dem Format wie es der MOPS-Solver
 * ben�tigt
 * 
 * @author Teamprojekt - Solvergruppe
 * @version 1.0
 */
public class CreateMopsFormatGoal extends CreateMopsFormat {

	private static final String LEERZEICHEN_8 = "        ";

	/**
	 * Properties werden hier geladen. D.h. die in der Properties
	 * festgeschriebenen Pfade werden hier aufgerufen
	 * 
	 * {@link Solver.properties}
	 * 
	 * @param name
	 *            Solver.properties Hier wird die Propertiesdatei eingelesen
	 * 
	 * @exception classname
	 *                CreateMopsFormat Die FileNotFoundException, wirft eine
	 *                Exception falls die gesuchte Datei nicht gefunden werden
	 *                kann
	 */
	private static final Properties properties = new Properties();
	static {
		try {
			properties.load(CreateMopsFormat.class.getResourceAsStream("Solver.properties"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private int anzahlRestriktionen;

	/**
	 * Die ArrayList vom Typ Schichtfolge, liefert uns unserse rotierten
	 * Schichtfolgen Der bedarf vom Typ Bedarf, liefert uns einen vom Benutzer
	 * eingegebenen Bedarf für einen von Ihm ausgewählten Zeitraum
	 * 
	 * @param rotiertSchichtfolgen
	 * @param bedarf2
	 * @return 
	 * @throws IOException
	 */
	@Override
	// Begin of Change fafilipp
	public String createMopsFile(String currentDir, ArrayList<Schichtfolge> rotiertSchichtfolgen, Bedarf bedarf2) throws IOException {
		// End of Change

		anzahlRestriktionen = bedarf2.getBedarf().values().size() * 3;

		// Begin of Change fafilipp
		return super.createMopsFile(currentDir, rotiertSchichtfolgen, bedarf2);
		// End of Change
	}

	@Override
	public void createBounds(StringBuffer dataSet, int anzahlVariablen) {
		// TODO Auto-generated method stub
		super.createBounds(dataSet, anzahlVariablen + anzahlRestriktionen * 2);
	}

	/**
	 * 
	 * @param dataSet
	 * @param anzahlRestriktionen
	 * @param anzahlXWerte
	 *            Diese Methode erstellt den Bereich der verantwortlich ist f�r
	 *            den Goalansatz, d.h. die X-Werte werden mit Werten und
	 *            Zuweisungen(Restriktionen) gesetzt
	 */
	private void createColumnsForGoal(StringBuffer dataSet, int anzahlRestriktionen, int anzahlXWerte) {
		int goalRestriktion = 1;
		for (int itvar = 1; itvar <= anzahlRestriktionen * 2; itvar++) {

			// ZF-Wert f�r �berschreitungsvariablen
			dataSet.append("    X" + getZahlPlusLeerzeichen(anzahlXWerte + itvar, 9) + "ZF" + LEERZEICHEN_8
					+ getZFUnterschreitungsvariable() + "." + "\r\n");

			dataSet.append("    X" + getZahlPlusLeerzeichen(anzahlXWerte + itvar, 9) + "R" + getZahlPlusLeerzeichen(goalRestriktion, 9)
					+ "1." + "\r\n");

			// ZF-Wert f�r Unterschreitungsvariable
			dataSet.append("    X" + getZahlPlusLeerzeichen(anzahlXWerte + itvar + 1, 9) + "ZF" + LEERZEICHEN_8
					+ getZFUeberschreitungsvariable() + "." + "\r\n");

			dataSet.append("    X" + getZahlPlusLeerzeichen(anzahlXWerte + itvar + 1, 9) + "R" + getZahlPlusLeerzeichen(goalRestriktion, 9)
					+ "-1." + "\r\n");
			itvar++;
			goalRestriktion++;

		}
	}

	public String getZFUeberschreitungsvariable() {
		// TODO Auto-generated method stub
		return "1";
	}

	public String getZFUnterschreitungsvariable() {
		// TODO Auto-generated method stub
		return "1";
	}

	@Override
	public void createColumns(ArrayList<Schichtfolge> rotiertSchichtfolgen, StringBuffer dataSet, int anzahlRestriktionen) {
		// TODO Auto-generated method stub
		super.createColumns(rotiertSchichtfolgen, dataSet, anzahlRestriktionen);
		createColumnsForGoal(dataSet, anzahlRestriktionen, rotiertSchichtfolgen.size());

	}

	@Override
	public void zfwertFuerSchichtfolge(StringBuffer dataSet, int hilfe2, int zfwert, ArrayList<Schicht> schichtArray, int hilfe) {
		// Do Nothing while here it should be 0
	}

	@Override
	public void createRows(StringBuffer dataSet, int anzahlTage) {
		// TODO Auto-generated method stub
		super.createRows(dataSet, anzahlTage, "E");
	}
}