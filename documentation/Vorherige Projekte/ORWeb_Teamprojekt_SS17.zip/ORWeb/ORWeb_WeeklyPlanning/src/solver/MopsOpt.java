package solver;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

/**
 * Die Klasse MopsOpt Eine Klasse die dem MOPS-Solver seine PROFIL-Datei
 * erstellt und die Optimierung bzw das ausf�hren des Solvers einleitet.
 * 
 * @author Solvergruppe (Mesut Deniz, Florian Moosmann, Lukas Lewandowski)
 * @version 1.0
 */

public class MopsOpt {

	private static final Properties properties = new Properties();
	static {
		try {
			properties.load(MopsOpt.class.getResourceAsStream("Solver.properties"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * In dieser Methode werden die Profildatei für den MOPS-Solver, sowie die
	 * start.cmd erstellt. Die Profildatei beinhaltet Profilinformationen wie
	 * zum Beispiel die Informationen über den Verbleib der MPS-Datei die der
	 * Solver benötigt. Die start.cmd startet den Mops und dieser sucht sich im
	 * Verzeichnis seine Profildatei und berechnet die Lösung.
	 * 
	 * @throws IOException
	 *             Schmeißt eine Exception wenn die Eingabe der Properties
	 *             fehlschlägt
	 * 
	 */
	// Begin of Change by fafilipp
	public void createMopsProp(String currentDir, boolean isGoal) throws IOException {
		String pfad = currentDir + "\\" + properties.getProperty("LP_MopsOpt_Mops_PRO");
		String pfad2 = currentDir + "\\" + properties.getProperty("LP_MopsOpt_Start_CMD");
		// End of Change

		BufferedWriter bw = new BufferedWriter(new FileWriter(pfad));
		bw.write("xoutsl = 1");
		bw.newLine();

		// Beginn of Change (magerhar)
		// Solver max disk size can be different
		bw.write("xmxdsk = 120");
		bw.newLine();
		// End of Change

		bw.write("xlptyp = 0");
		bw.newLine();
		bw.write("xmxmin = 15.0");
		bw.newLine();
		bw.write("xfnmps = '" + properties.getProperty("LP_MopsOpt_MopsDatei") + "'");
		bw.newLine();
		bw.write("xminmx = min");
		bw.flush();
		bw.close();
		BufferedWriter bw2 = new BufferedWriter(new FileWriter(pfad2));
		bw2.write("c:");
		bw2.newLine();

		// Change Begin by fafilipp
		bw2.write("cd " + "\"" + currentDir + "\"");
		// End of Change

		bw2.newLine();

		// Change Begin by fafilipp
		bw2.write("\"" + currentDir + "\\mops.exe\"");
		// End of Change

		bw2.newLine();
		bw2.write("exit");
		bw2.flush();
		bw2.close();
	}

}
