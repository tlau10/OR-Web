package solver;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

import ausgabe.Ausgabe;
import ausgabe.Schichtplan;
import bedarf.Bedarf;
import de.htwg.orweb.common.result.Result;
import de.htwg.orweb.common.result.VariableResult;
import de.htwg.orweb.common.shared.Model;
import de.htwg.orweb.common.task.Meta;
import de.htwg.orweb.common.task.Objective;
import de.htwg.orweb.common.task.Task;
import de.htwg.orweb.common.task.Variable;
import de.htwg.orweb.lps.prod.ILPSolver;
import de.htwg.orweb.lps.prod.LPSProduction;
import schichtmuster.Schichtfolge;
import schichtmuster.Schichtmuster;
import schichtmuster.SchichtmusterFactory;

/**
 * Diese Methode erstellt die MPS-Datei in dem Format wie es der MOPS-Solver
 * benötigt
 * 
 * @author Teamprojekt - Solvergruppe
 * @version 1.0
 */
public class MopsSolver {
	
	
	private ILPSolver solver;
	/**
	 * 
	 */
	public MopsSolver() {
		this.solver = new LPSProduction();
	}

	/**
	 * JavaDoc by fafilipp: Diese Methode optimiert den Eingegebenen Bedarf und
	 * die Schichtmuster. Dafür werden folgende Eingabedateien erstellt: Mops
	 * Property Datei, Start CMD, Mops Modelleingabedatei. Daraufhin ruft es den
	 * MopsSolver im entsprechenden Verzeichnis auf und erstellt eine lps (nicht
	 * ganzzahlige optimallösung) sowie ips (ganzzahlige optimallösung). Die IPS
	 * wird eingelesen, es wird mittels der *.msg Datei überprüft ob das Modell
	 * Optimal gelöst wurde oder gar nicht Lösbar ist und gibt daraufhin den
	 * erstellten Schichtplan zurück. Bei Fehler wird die jeweilige Exception
	 * geworfen.
	 * 
	 * @param schichtmuster
	 *            die Schichtmuster des Benutzers.
	 * @param bedarf
	 *            die Bedarfseingaben des Benutzers
	 * @return gibt den Schichtplan zurück
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws NichtOptimalException
	 * @throws InfeasibleException
	 * @throws UnboundedException
	 * @throws InterruptedException
	 */
	// Begin of Change by fafilipp
	public Schichtplan optimiere(String currentDir, Schichtmuster schichtmuster, Bedarf bedarf) throws FileNotFoundException, IOException,
			UnboundedException, InfeasibleException, NichtOptimalException, InterruptedException {
		// End of Change

		ArrayList<Schichtfolge> schichtfolgenArray = SchichtmusterFactory.getAlleSchichtfolgenfuerBedarf(bedarf.getBedarf().size(),
				schichtmuster);

		CreateMopsFormat cmf = getMopsFormatImpl();

		// Begin of Change by fafilipp
		String mpsData = cmf.createMopsFile(currentDir, schichtfolgenArray, bedarf);
		// End of Change

		// Hier wird die Solver.propertiesdatei geladen
		Properties properties = new Properties();
		properties.load(MopsSolver.class.getResourceAsStream("Solver.properties"));

		MopsOpt mo = new MopsOpt();
		// Change Begin by fafilipp
		mo.createMopsProp(currentDir, this.getClass().equals(MopsSolverGoal.class) ? true : false);
		// End of Change

		Task task = new Task();
		Model model = new Model();
		Meta meta = new Meta();
		meta.setConvert(false);
		//Solves mps instance
		meta.setSolveFromModel(true);
		meta.setSolver("cbc");
		model.setMpsModel(mpsData);
		task.setMeta(meta);
		task.setModel(model);
		Objective obj = new Objective();
		obj.setType("min");
		task.setObjective(obj);
		Result res = solver.solve(task);
		if (!res.isFeasible()) {
			throw new InfeasibleException();
		}
		return readStringSource(res,schichtfolgenArray);
	}
	
	private Schichtplan readStringSource(Result res,  ArrayList<Schichtfolge> schichtfolge){
		ArrayList<Ausgabe> mopsloesung = new ArrayList<Ausgabe>();
		int index = 0;
		for (VariableResult v : res.getVariables()) {
			if (index < schichtfolge.size()) {
				mopsloesung.add(new Ausgabe((int) v.getValue(), schichtfolge.get(index)));
			}
			index++;
		}
		Schichtplan tempSchichtplan = new Schichtplan();
		tempSchichtplan.setAusgabe(mopsloesung);
		return tempSchichtplan;
	}

	public CreateMopsFormat getMopsFormatImpl() {
		return new CreateMopsFormat();
	}

}
