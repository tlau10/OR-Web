package solver;

public class NichtOptimalException extends Exception {
	public NichtOptimalException(String s) {
		super(s);
	}

	public NichtOptimalException() {
		super("Nicht optimale Lösung");
	}

}
