package solver;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Solverloesung {

	public Solverloesung(String schichtFolgeMops, int schichtFolgeAnzahl) {
		super();
		this.schichtFolgeMops = schichtFolgeMops;
		this.schichtFolgeAnzahl = schichtFolgeAnzahl;
	}

	private String schichtFolgeMops;

	private int schichtFolgeAnzahl;

	public String getSchichtFolgeMops() {
		return schichtFolgeMops;
	}

	public void setSchichtFolgeMops(String schichtFolgeMops) {
		this.schichtFolgeMops = schichtFolgeMops;
	}

	public int getSchichtFolgeAnzahl() {
		return schichtFolgeAnzahl;
	}

	public void setSchichtFolgeAnzahl(int schichtFolgeAnzahl) {
		this.schichtFolgeAnzahl = schichtFolgeAnzahl;
	}

}
