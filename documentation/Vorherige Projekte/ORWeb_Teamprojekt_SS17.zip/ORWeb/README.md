# WebOR

[ORWeb_Frontend README.md](https://github.com/aTTraX/WebOR/blob/master/ORWeb_Frontend/README.md)


Teamprojekt SS17 (Bastian Schöttle, Mirko Bay, Stephen Beck, Michael Bernhardt, Marco Kloft, Markus Jäckle)
