#!/bin/bash

###################################
# 
# This Script adds the Application
# to the /var folder and starts
# it as a system service (systemd)
# 
###################################

# Argument: The jar file to deploy
APPSRCPATH=$1
APPNAME=$2
APPUSER=$3
PROPERTIES_FILE=$4
APPFILENAME=$(basename $APPSRCPATH)
APPFOLDER=/opt/$APPNAME
APPDESTPATH=$APPFOLDER/$APPFILENAME

#########
# Usage #
#########
USAGE="
Usage: sudo $0 <jar-file> <app-name> <runtime-user> <properties-file>
If an app with the name <app-name> already exist, it will be stopped and deleted.
If the <runtime-user> does not already exist, it will be created.
"

# Check that we are root
if [ ! "root" = "$(whoami)" ]; then
    echo "Must be root. Please use e.g. sudo"
    echo "$USAGE"
    exit
fi

# Check arguments
if [ "$#" -ne 3 -o ${#APPSRCPATH} = 0 -o ${#APPNAME} = 0 -o ${#APPUSER} = 0 -o ${#PROPERTIES_FILE} = 0]; then
    echo "Incorrect number of parameters."
    echo "$USAGE"
    exit
fi

if [ ! -f $APPSRCPATH ]; then
    echo "Can't find jar file $APPSRCPATH"
    echo "$USAGE"
    exit
fi

# Stop the service if it already exist and is running
systemctl stop $APPNAME >/dev/null 2>&1

# Create the user if it does not exist
if id "$APPUSER" >/dev/null 2>&1; then
    echo "Using existing user $APPUSER"
else
    adduser --disabled-password --gecos "" $APPUSER
    echo "Created user $APPUSER"
fi

# Create the .service file used by systemd
echo "
[Unit]
Description=$APPNAME
After=syslog.target
[Service]
User=$APPUSER
WorkingDirectory=/opt/$APPNAME
ExecStart=/usr/bin/java -jar $APPDESTPATH $PROPERTIES_FILE
SuccessExitStatus=143
[Install]
WantedBy=multi-user.target
" > /etc/systemd/system/$APPNAME.service
echo "Created the /etc/systemd/system/$APPNAME.service file"

# Reload the daemon
systemctl daemon-reload

# Start the deployed app
systemctl start $APPNAME
systemctl status $APPNAME
