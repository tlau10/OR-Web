#!/bin/bash

# Configuration
NODE=1

cd "ORWeb_Common/"
mvn clean install
cd ..

cd "ORWeb_LPS/"
mvn clean install
cd ..

cd "ORWeb_Frontend/"
if [ $NODE = 1 ]
then
  npm install
fi
gulp
mvn clean install
