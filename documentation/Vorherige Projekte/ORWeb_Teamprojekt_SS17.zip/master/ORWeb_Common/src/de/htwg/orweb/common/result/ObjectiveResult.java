/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.common.result;

import javax.xml.bind.annotation.XmlElement;

public class ObjectiveResult {
	
	private double value;
	/**
	 * 
	 */
	public ObjectiveResult() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * 
	 */
	public ObjectiveResult(double value) {
		this.value = value;
	}
	
	
	@XmlElement
	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}

}
