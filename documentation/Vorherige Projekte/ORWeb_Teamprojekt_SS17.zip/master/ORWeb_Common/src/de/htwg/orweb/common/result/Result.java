/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.common.result;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import de.htwg.orweb.common.shared.Model;
import de.htwg.orweb.common.task.Task;

@XmlRootElement
public class Result {

	private ObjectiveResult objective;
	private List<VariableResult> variables;
	private Model model;
	private boolean isFeasible;
	private long processingTime;

	private Task task;
	
	@XmlElement(name="objectiveResult")
	public ObjectiveResult getObjective() {
		return objective;
	}

	public void setObjective(ObjectiveResult objective) {
		this.objective = objective;
	}
	
	@XmlElementWrapper(name = "variableResults")
	@XmlElement(name= "variableResult")
	public List<VariableResult> getVariables() {
		return variables;
	}

	public void setVariables(List<VariableResult> variables) {
		this.variables = variables;
	}
	
	@XmlElement
	public Model getModel() {
		return model;
	}

	public void setModel(Model model) {
		this.model = model;
	}
	
	@XmlElement
	public boolean isFeasible() {
		return isFeasible;
	}

	public void setFeasible(boolean isFeasible) {
		this.isFeasible = isFeasible;
	}

	@XmlElement
	public Task getTask() {
		return task;
	}

	public void setTask(Task task) {
		this.task = task;
	}
	@XmlElement
	public long getProcessingTime() {
		return processingTime;
	}

	public void setProcessingTime(long processingTime) {
		this.processingTime = processingTime;
	}

}
