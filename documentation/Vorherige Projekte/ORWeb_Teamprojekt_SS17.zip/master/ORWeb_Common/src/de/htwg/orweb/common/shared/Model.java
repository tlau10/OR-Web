/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.common.shared;

public class Model {
	
	/**
	 * 
	 */
	public Model() {
		// TODO Auto-generated constructor stub
	}
	
	public Model(String mpsModel){
		this.mpsModel = mpsModel;
	}
	
	private String mpsModel;

	public String getMpsModel() {
		return mpsModel;
	}

	public void setMpsModel(String mpsModel) {
		this.mpsModel = mpsModel;
	}

}
