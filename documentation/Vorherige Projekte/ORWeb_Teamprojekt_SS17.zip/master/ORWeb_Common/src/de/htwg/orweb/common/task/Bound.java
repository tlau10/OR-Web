/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.common.task;

import javax.xml.bind.annotation.XmlElement;

public class Bound {

    	
	private String variableName;

	private double lowerBound;

	private double upperBound;
	
	private boolean isInteger;
	
	@XmlElement
	public String getVariableName() {
		return variableName;
	}

	public void setVariableName(String variableName) {
		this.variableName = variableName;
	}

	@XmlElement
	public double getLowerBound() {
		return lowerBound;
	}

	public void setLowerBound(double lowerBound) {
		this.lowerBound = lowerBound;
	}

	@XmlElement
	public double getUpperBound() {
		return upperBound;
	}

	public void setUpperBound(double upperBound) {
		this.upperBound = upperBound;
	}

	public boolean isInteger() {
		return isInteger;
	}

	public void setInteger(boolean isInteger) {
		this.isInteger = isInteger;
	}

	@Override
	public String toString() {
		return "Bound " + variableName + " | lower = " + lowerBound + " | upper = " + upperBound + " | integer = " + isInteger;
	}
}
