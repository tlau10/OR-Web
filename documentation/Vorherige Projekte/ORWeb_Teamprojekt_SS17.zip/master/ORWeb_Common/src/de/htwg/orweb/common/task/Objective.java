
/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.common.task;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

public class Objective {

    private String type;

    private List<Variable> variables;

    @XmlElement
    public String getType() {
	return type;
    }

    public void setType(String type) {
	this.type = type;
    }

    @XmlElementWrapper(name = "variables")
    @XmlElement(name = "variable")
    public List<Variable> getVariables() {
	return variables;
    }

    public void setVariables(List<Variable> variables) {
	this.variables = variables;
    }

    @Override
    public String toString() {
	return "Objective [type=" + type + ", variables=" + variables.toString() + "]";
    }
    
    

}
