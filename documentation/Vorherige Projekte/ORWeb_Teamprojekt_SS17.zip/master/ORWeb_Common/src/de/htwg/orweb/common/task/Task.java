/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.common.task;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import de.htwg.orweb.common.shared.Model;

@XmlRootElement
public class Task {
	
	private Meta meta;
	
	private Model model;
	
	private Objective objective;
	
	private List<Constraint> constraints; 
	
	private List<Bound> bounds;
	
	@XmlElement
	public Meta getMeta() {
		return meta;
	}

	public void setMeta(Meta meta) {
		this.meta = meta;
	}
	@XmlElement
	public Objective getObjective() {
		return objective;
	}

	public void setObjective(Objective objective) {
		this.objective = objective;
	}
	@XmlElementWrapper(name = "constraints")
	@XmlElement(name= "constraint")
	public List<Constraint> getConstraints() {
		return constraints;
	}

	public void setConstraints(List<Constraint> constraints) {
		this.constraints = constraints;
	}
	@XmlElementWrapper(name = "bounds")
	@XmlElement(name= "bound")
	public List<Bound> getBounds() {
		return bounds;
	}

	public void setBounds(List<Bound> bounds) {
		this.bounds = bounds;
	}
	
	@XmlElement
	public Model getModel() {
		return model;
	}

	public void setModel(Model model) {
		this.model = model;
	}
	
}
