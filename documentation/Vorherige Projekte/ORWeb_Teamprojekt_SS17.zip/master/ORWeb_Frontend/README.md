# How to run on linux

* in de.htwg.orweb.controller.SolverController, Zeile 36, den Pfad zur Config-Datei angeben
* Directory "ORWeb_LPS" irgendwo anlegen
* darin einen Unterordner "lib" anlegen
* in diesen die Datei "cbc" aus ORWeb_LPS/resources/linux kopieren
* in der verschobenen Config-Datei, Zeile 20, den Pfad zu dem erstellten ORWeb_LPS Ordner angeben

### Design
* green: #009b91
* lightgray: #d9e5ec
* darkblue: #334152
* font:

### User
* admin@orweb.de : .h7;KE!3d6*+RVzb

### Server
* IP: 141.37.122.49
* User:
    * orweb : (4t44K6@8Ka/
    * root : 37j36g=fo)4)
* Tomcat (v.8.0.44):
    * Port: 8081
    * Location: /opt/tomcat8
    * Start/Stop: /etc/init.d/tomcat8 start/stop
* ORWeb Application:
    * Location (Server): /opt/orweb
    * Port: 8080 (Redirected to Port 80 by iptables on the server)
    * Start/Stop: 
* Installed Software:
    * Tomcat 8.0.44
    * MariaDB 10.2
        Installations Password: !MariaDB
        Database User:
        * root : 3N473pP=t8cM
        * orweb : 4dpGn9wH4M98
    * 
    
### Git-Repository
* Name: ORWeb_Teamprojekt_SS17
* URL: http://141.37.122.27/Git/Repository/ORWeb_Teamprojekt_SS17
* Login
    * Username: fhkn\USERNAME
    * Password: RZ-PASSWORD

## Spring Framework
## Frontend
#### 1. Install node_modules:
```
   $ npm install
```
#### 2. Load assets:  
```
   $ gulp
```
#### 3. While developing synchronize assets:  
```
   $ gulp watch
```
### Backend
#### i18n
* example: <https://g00glen00b.be/spring-internationalization-i18n/>
* with configuration in _application.properties_ it works "out of the box" with the message files in [src/main/resources/messages](src/main/resources/messages)
* default language is described in the [messages.properties](src/main/resources/messages/irgendwas.properties)
* additional languages are defined with underscore and the international code, e.g. *messages_en.properties*
* Spring checks the language settings of the browser and delivers the correct language
* usage in thymeleaf: `<p th:text="#{label.helloworld}"></p>`    

#### database access
* while developing a embedded h2 in-memory db is used
* DB Tables are user, method, solver, downloads, chart_visited
* the schema is automatically created by hibernate when the application starts
* the necessary initial data for the db is loaded from the [import.sql]((src/main/resources/import.sql) file
* you can connect a console for the db at <http://localhost:8080/console>
* credentials for the console login: **user: "sa"** / **password: "<blank>"** / **jdbc url: "jdbc:h2:mem:testdb"**

#### security
* the pages, which are restricted, are configured in the SecurityConfiguration in the configuration package
* all pages are permitted, except */admin* and all pages following (/admin/*)
* the default superuser is: **email: "admin@orweb.de"** / **password: ".h7;KE!3d6\*+RVzb"**
* the delevelop password is "passwort"

