/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.controller;


import java.lang.reflect.Array;
import java.util.List;
import java.util.Locale;

import de.htwg.orweb.form.UserForm;
import de.htwg.orweb.model.*;
import de.htwg.orweb.service.*;
import de.htwg.orweb.validator.UserValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
public class AdminController {

    @Autowired
    private IMethodService methodService;
    @Autowired
    private ISolverService solverService;
    @Autowired
    private IDownloadService downloadService;
    @Autowired
    private IUserService userService;
    @Autowired
    private IChartVisitedService chartVisitedService;
    @Autowired
    private UserValidator userValidator;
    @Autowired
    private MessageSource messageSource;

    @GetMapping("/admin/methods")
    public ModelAndView methodAction() {

        ModelAndView modelAndView = new ModelAndView();

        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true, "method");
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true, "solver");
        List<Method> data = methodService.findAllMethods();

        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);
        modelAndView.addObject("data", data);

        modelAndView.setViewName("admin/methods");
        return modelAndView;
    }

    @PostMapping("/admin/methods")
    public ResponseEntity<?> methodUpdateActiveAction(@ModelAttribute Method method, @RequestParam(name = "active", required = false, defaultValue = "false") Boolean bool, @RequestParam("id") int id) {

        method = methodService.findMethodById(id);
        method.setActive(bool);
        methodService.saveMethod(method);

        String[] data = new String[7];
        data[0] = "Daten wurden erfolgreich aktualisiert";
        data[1] = "" + method.getId();
        data[2] = "method";
        data[3] = "false";
        data[4] = "-";
        data[5] = "false";
        data[6] = "-";

        if (methodService.findMethodByActive(true).isEmpty()) {
            data[3] = "true";
        }
        if (method.isActive()) {
            data[5] = "true";
        }

        return new ResponseEntity(data, HttpStatus.OK);
    }

    @RequestMapping("/admin/solvers")
    public ModelAndView solverAction() {

        ModelAndView modelAndView = new ModelAndView();

        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true, "method");
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true, "solver");
        List<Solver> data = solverService.findAllSolvers();

        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);
        modelAndView.addObject("data", data);

        modelAndView.setViewName("admin/solvers");
        return modelAndView;
    }

    @PostMapping("/admin/solvers")
    public ResponseEntity<?> solverUpdateActiveAction(@ModelAttribute Solver solver, @RequestParam(name = "active", required = false, defaultValue = "false") Boolean bool, @RequestParam("id") int id) {

        solver = solverService.findMethodById(id);
        solver.setActive(bool);
        solverService.saveSolver(solver);

        String[] data = new String[7];
        data[0] = "Daten wurden erfolgreich aktualisiert";
        data[1] = "" + solver.getId();
        data[2] = "solver";
        data[3] = "false";
        data[4] = "-";
        data[5] = "false";
        data[6] = "-";

        if (solverService.findSolverByActive(true).isEmpty()) {
            data[3] = "true";
        }
        if (solver.isActive()) {
            data[5] = "true";
        }

        return new ResponseEntity(data, HttpStatus.OK);
    }

    @GetMapping("/admin/downloads")
    public ModelAndView downloadAction() {

        ModelAndView modelAndView = new ModelAndView();

        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true, "method");
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true, "solver");
        List<Download> downloadActive = downloadService.findAllDownloadByActive(true);
        List<Download> dataMethod = downloadService.findAllDownloadByType("method");
        List<Download> dataSolver = downloadService.findAllDownloadByType("solver");

        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadActive", downloadActive);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);
        modelAndView.addObject("dataMethod", dataMethod);
        modelAndView.addObject("dataSolver", dataSolver);

        modelAndView.setViewName("admin/downloads");
        return modelAndView;
    }

    @PostMapping("/admin/downloads")
    public ResponseEntity<?> downloadUpdateActiveAction(@ModelAttribute Download download, @RequestParam(name = "active", required = false, defaultValue = "false") Boolean bool, @RequestParam("id") int id) {

        if (id == 0) {

            List<Download> items = downloadService.findAllDownloads();

            for (Download downloads : items) {
                downloads.setActive(bool);
                downloadService.saveDownload(downloads);
            }

        } else {
            download = downloadService.findDownloadById(id);
            download.setActive(bool);
            downloadService.saveDownload(download);

        }
        String[] data = new String[7];
        data[0] = "Daten wurden erfolgreich aktualisiert";
        data[1] = "" + id;
        data[2] = "download";
        data[3] = "false";
        data[4] = "-";
        data[5] = "false";
        data[6] = "false";

        if (id != 0) {
            if (download.getType().equals("solver")) {
                data[4] = "solver";
                if (downloadService.findAllDownloadByActiveAndType(true, data[4]).isEmpty()) {
                    data[3] = "true";
                }
            } else if (download.getType().equals("method")) {
                data[4] = "method";
                if (downloadService.findAllDownloadByActiveAndType(true, data[4]).isEmpty()) {
                    data[3] = "true";
                }
            }
            if (download.isActive()) {
                data[5] = "true";
            }
        }
        if (downloadService.findAllDownloadByActive(true).isEmpty()) {
            data[6] = "true";
        }

        return new ResponseEntity(data, HttpStatus.OK);
    }

    @GetMapping("/admin/users/registration")
    public ModelAndView registration(UserForm userForm) {

        ModelAndView modelAndView = new ModelAndView();

        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true, "method");
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true, "solver");

        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);

        modelAndView.setViewName("admin/registration");
        return modelAndView;
    }

    @PostMapping("/admin/users/registration")
    public ModelAndView createNewUser(@Valid UserForm userForm, BindingResult bindingResult, RedirectAttributes redirectAttributes, Locale locale) {
        ModelAndView modelAndView = new ModelAndView();

        List<User> users = userService.findAll();
        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true, "method");
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true, "solver");

        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);
        modelAndView.addObject("users", users);

        userValidator.validate(userForm, bindingResult);

        if (bindingResult.hasErrors()) {
            modelAndView.setViewName("admin/registration");
        } else {
            User user = new User();
            user.setFirstName(userForm.getFirstName());
            user.setLastName(userForm.getLastName());
            user.setEmail(userForm.getEmail());
            user.setPassword(userForm.getPassword());
            user.setActive(true);
            userService.saveUser(user);
            redirectAttributes.addFlashAttribute("message", messageSource.getMessage("user.add.success.message", new String[]{}, locale));
            modelAndView.setViewName("redirect:/admin/users");
        }
        return modelAndView;
    }

    @GetMapping("/admin/users/edit/{id}")
    public ModelAndView getEditUser(@PathVariable("id") int id, UserForm userEditForm) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String loggedInUser = auth.getName();
        User user = userService.findUserById(id);
        ModelAndView modelAndView = new ModelAndView();

        List<User> users = userService.findAll();
        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true, "method");
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true, "solver");

        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);
        modelAndView.addObject("users", users);

        if (!loggedInUser.equals("admin@orweb.de")) {
            if (!loggedInUser.equals(user.getEmail())) {
                System.err.println("Darfst hier nicht rein!");
                modelAndView.setViewName("redirect:/admin/users");
                return modelAndView;
            }
        }

        modelAndView.addObject("userId", id);
        modelAndView.addObject("username", user.getFirstName() + " " + user.getLastName());
        modelAndView.addObject("firstName", user.getFirstName());
        modelAndView.addObject("lastName", user.getLastName());
        modelAndView.addObject("email", user.getEmail());

        modelAndView.setViewName("admin/editUser");
        return modelAndView;
    }

    @PostMapping("/admin/users/edit")
    public ModelAndView postEditUser(@Valid UserForm userForm, BindingResult bindingResult, RedirectAttributes redirectAttributes, Locale locale) {

        ModelAndView modelAndView = new ModelAndView();

        List<User> users = userService.findAll();
        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true, "method");
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true, "solver");

        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);
        modelAndView.addObject("users", users);

        userValidator.validateEdit(userForm, bindingResult);
        User user = userService.findUserById(userForm.getId());

        if (bindingResult.hasErrors()) {

            modelAndView.addObject("userId", userForm.getId());
            modelAndView.addObject("username", user.getFirstName() + " " + user.getLastName());
            modelAndView.addObject("firstName", userForm.getFirstName());
            modelAndView.addObject("lastName", userForm.getLastName());
            modelAndView.addObject("email", userForm.getEmail());

            modelAndView.setViewName("admin/editUser");
        } else {

            user.setFirstName(userForm.getFirstName());
            user.setLastName(userForm.getLastName());
            user.setEmail(userForm.getEmail());
            user.setPassword(userForm.getPassword());
            user.setActive(true);
            userService.saveUser(user);

            redirectAttributes.addFlashAttribute("message", messageSource.getMessage("user.edit.success.message", new String[]{}, locale));
            modelAndView.setViewName("redirect:/admin/users");
        }
        return modelAndView;
    }


    @GetMapping("/admin/users/delete/{id}")
    public ModelAndView deleteUser(@PathVariable("id") int id, RedirectAttributes redirectAttributes, Locale locale) {

        ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String loggedInUser = auth.getName();
        User user = userService.findUserById(id);

        List<User> users = userService.findAll();
        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true, "method");
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true, "solver");

        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);
        modelAndView.addObject("users", users);

        if (!loggedInUser.equals("admin@orweb.de")) {

            System.err.println("Darfst hier nicht rein!");
            modelAndView.setViewName("redirect:/admin/users");
            return modelAndView;

        }
        if (!user.getEmail().equals("admin@orweb.de")) {
            userService.deleteUser(user);
        }


        redirectAttributes.addFlashAttribute("message", messageSource.getMessage("user.delete.success.message", new String[]{}, locale));
        modelAndView.setViewName("redirect:/admin/users");
        return modelAndView;
    }

    @RequestMapping("/admin/users")
    public ModelAndView userAction() {

        ModelAndView modelAndView = new ModelAndView();

        List<User> users = userService.findAll();
        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true, "method");
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true, "solver");

        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);
        modelAndView.addObject("users", users);

        modelAndView.setViewName("admin/user");
        return modelAndView;
    }

    @RequestMapping("/admin/statistic")
    public ModelAndView statisticAction() {

        ModelAndView modelAndView = new ModelAndView();

        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true, "method");
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true, "solver");
        ChartVisited chartVisited = chartVisitedService.findChartVisitedById(1);

        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);

        modelAndView.addObject("de", chartVisited.getDe());
        modelAndView.addObject("en", chartVisited.getEn());
        modelAndView.addObject("it", chartVisited.getIt());
        modelAndView.addObject("fr", chartVisited.getFr());
        modelAndView.addObject("es", chartVisited.getEs());
        modelAndView.addObject("tr", chartVisited.getTr());
        modelAndView.addObject("ru", chartVisited.getRu());
        modelAndView.addObject("other", chartVisited.getOther());

        modelAndView.setViewName("admin/statistic");
        return modelAndView;
    }

}
