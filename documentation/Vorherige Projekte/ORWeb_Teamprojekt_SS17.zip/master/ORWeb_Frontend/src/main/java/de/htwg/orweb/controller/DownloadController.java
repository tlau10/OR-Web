/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.controller;


import de.htwg.orweb.model.Download;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import de.htwg.orweb.service.IDownloadService;
import de.htwg.orweb.service.IMethodService;
import de.htwg.orweb.service.ISolverService;
import de.htwg.orweb.model.Method;
import de.htwg.orweb.model.Solver;

import java.util.List;

@Controller
public class DownloadController {

    @Autowired
    private IMethodService methodService;
    @Autowired
    private IDownloadService downloadService;
    @Autowired
    private ISolverService solverService;

    @RequestMapping("/download/{id}")
    public ModelAndView downloadIndexAction(@PathVariable("id") int id) {

        ModelAndView modelAndView = new ModelAndView();

        // **This checks if solver is online
        Download download = downloadService.findDownloadById(id);
        System.out.println(download);

        modelAndView.setViewName("redirect:/404");
        if (download == null) {
            return modelAndView;
        }
        if (!download.isActive()) {
            return modelAndView;
        }
        // **END

        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true, "method");
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true, "solver");

        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);
        modelAndView.addObject("downloadName", download.getName());
        modelAndView.addObject("downloadDescription", download.getDesc());
        modelAndView.addObject("downloadImage", download.getPathImage());
        modelAndView.addObject("downloadPath", download.getPath());

        modelAndView.setViewName("download");

        return modelAndView;
    }
}
