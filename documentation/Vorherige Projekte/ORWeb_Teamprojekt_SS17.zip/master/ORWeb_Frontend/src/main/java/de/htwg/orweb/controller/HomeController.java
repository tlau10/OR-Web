/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.controller;

import java.util.List;
import java.util.Locale;

import de.htwg.orweb.model.ChartVisited;
import de.htwg.orweb.model.Download;
import de.htwg.orweb.service.IChartVisitedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.servlet.ModelAndView;

import de.htwg.orweb.service.IDownloadService;
import de.htwg.orweb.service.IMethodService;
import de.htwg.orweb.service.ISolverService;
import de.htwg.orweb.model.Method;
import de.htwg.orweb.model.Solver;
import org.thymeleaf.util.StringUtils;

import javax.servlet.http.HttpServletRequest;

@Controller
public class HomeController {

	@Autowired
	private IMethodService methodService;
	@Autowired
	private ISolverService solverService;
	@Autowired
	private IDownloadService downloadService;
	@Autowired
	private IChartVisitedService chartVisitedService;

	@RequestMapping("/")
	public ModelAndView homeAction(Locale locale, HttpServletRequest request) {
		ModelAndView modelAndView = new ModelAndView();

		// Statistic saving cookies and read the locale and persist to database.
		if(request.getSession().getAttribute("visited") == null){
			request.getSession().setAttribute("visited", false);
		}

		boolean visited = (boolean) request.getSession().getAttribute("visited");

		if(!visited){
			request.getSession().setAttribute("visited", true);
			ChartVisited chartVisited = chartVisitedService.findChartVisitedById(1);
			String firstTwoCharacters = locale.toString();
			firstTwoCharacters = StringUtils.substring(firstTwoCharacters, 0, 2);

			int counter;

			switch (firstTwoCharacters){
				case "de":
					counter = chartVisited.getDe(); counter++;
					chartVisited.setDe(counter);
					break;
				case "en":
					counter = chartVisited.getEn(); counter++;
					chartVisited.setEn(counter);
					break;
				case "it":
					counter = chartVisited.getIt(); counter++;
					chartVisited.setIt(counter);
					break;
				case "fr":
					counter = chartVisited.getFr(); counter++;
					chartVisited.setFr(counter);
					break;
				case "es":
					counter = chartVisited.getEs(); counter++;
					chartVisited.setEs(counter);
					break;
				case "tr":
					counter = chartVisited.getTr(); counter++;
					chartVisited.setTr(counter);
					break;
				case "ru":
					counter = chartVisited.getRu(); counter++;
					chartVisited.setRu(counter);
					break;
				default:
					counter = chartVisited.getOther(); counter++;
					chartVisited.setOther(counter);
					break;
			}

			chartVisitedService.saveChartVisited(chartVisited);

		}


		// end statistic

		List<Method> onlineMethod = methodService.findMethodByActive(true);
		List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true,"method");
		List<Solver> onlineSolver = solverService.findSolverByActive(true);
		List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true,"solver");
		
		modelAndView.addObject("onlineMethods", onlineMethod);
		modelAndView.addObject("downloadMethods", downloadMethod);
		modelAndView.addObject("onlineSolvers", onlineSolver);
		modelAndView.addObject("downloadSolvers", downloadSolver);
		
		modelAndView.setViewName("home");
		return modelAndView;
	}
	
}
