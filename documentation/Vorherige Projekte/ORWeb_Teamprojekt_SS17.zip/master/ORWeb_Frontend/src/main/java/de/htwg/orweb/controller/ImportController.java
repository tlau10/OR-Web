/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.controller;

import de.htwg.orweb.OrwebApplication;
import de.htwg.orweb.common.result.Result;
import de.htwg.orweb.common.shared.Model;
import de.htwg.orweb.common.task.*;
import de.htwg.orweb.lps.common.TaskFactory;
import de.htwg.orweb.lps.prod.ILPSolver;
import de.htwg.orweb.lps.prod.LPSProduction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

/**
 * @author mirko bay
 *         <p>
 *         controller for parsing a mps file, delivered with the
 *         task object from the web application
 *         <p>
 *         returns a result object that we can process in the frontend
 */
@Controller
public class ImportController {

    @PostMapping("/import")
    @ResponseBody
    public ResponseEntity<Task> importTask(@RequestBody String mps) {
        System.out.println(mps);
        Task convertedTask = TaskFactory.createTransform(mps, TaskFactory.ObjectiveSense.MIN);
        ILPSolver solver = new LPSProduction(OrwebApplication.SOLVER_CFG_PATH);
        Result result = solver.solve(convertedTask);
        // todo: replace the example task with the converted task / getExampleTask(mps, false)
        return new ResponseEntity<Task>(result.getTask(), HttpStatus.OK);
    }

    private Task getExampleTask(String mps, boolean taskForIterator) {

        // create task
        Task dummyTask = new Task();

        // create meta
        Meta dummyMeta = new Meta();
        dummyMeta.setSolver("lp_solve");
        // set meta
        dummyTask.setMeta(dummyMeta);

        // create Model
        Model dummyModel = new Model();
        dummyModel.setMpsModel(mps);

        // create objective
        Objective dummyObjective = new Objective();
        dummyObjective.setType("max");
        List<Variable> dummyObjectiveVariables = new ArrayList<>();

        // create variable 1 for objective
        Variable var1 = new Variable();
        var1.setCoefficient(1);
        var1.setName("x1");
        dummyObjectiveVariables.add(var1);

        // create variable 2 for objective
        Variable var2 = new Variable();
        var2.setCoefficient(2);
        var2.setName("x2");
        dummyObjectiveVariables.add(var2);

        if (taskForIterator) {
            // create variable 3 for objective
            Variable var3 = new Variable();
            var3.setCoefficient(0);
            var3.setName("x3");
            dummyObjectiveVariables.add(var3);

            // create variable 4 for objective
            Variable var4 = new Variable();
            var4.setCoefficient(0);
            var4.setName("x4");
            dummyObjectiveVariables.add(var4);
        }
        dummyObjective.setVariables(dummyObjectiveVariables);
        // set objective
        dummyTask.setObjective(dummyObjective);

        // create constraints
        List<Constraint> dummyConstraints = new ArrayList<>();

        Constraint cons1 = new Constraint();
        cons1.setName("R1");
        cons1.setRhs(12);
        cons1.setType("L");
        List<Variable> dummyCons1Variables = new ArrayList<>();

        Variable var1Cons1 = new Variable();
        var1Cons1.setCoefficient(3);
        var1Cons1.setName("x1");
        dummyCons1Variables.add(var1Cons1);

        Variable var2Cons1  = new Variable();
        var2Cons1.setCoefficient(2);
        var2Cons1.setName("x2");
        dummyCons1Variables.add(var2Cons1);

        if (taskForIterator) {

            Variable var3Cons1 = new Variable();
            var3Cons1.setCoefficient(1);
            var3Cons1.setName("x3");
            dummyCons1Variables.add(var3Cons1);

            Variable var4Cons1 = new Variable();
            var4Cons1.setCoefficient(0);
            var4Cons1.setName("x4");
            dummyCons1Variables.add(var4Cons1);
        }
        cons1.setVariables(dummyCons1Variables);


        // #######################################

        Constraint cons2 = new Constraint();
        cons2.setName("R2");
        cons2.setRhs(9);
        cons2.setType("L");
        List<Variable> dummyCons2Variables = new ArrayList<>();

        Variable var1Cons2 = new Variable();
        var1Cons2.setCoefficient(1);
        var1Cons2.setName("x1");
        dummyCons2Variables.add(var1Cons2);

        Variable var2Cons2  = new Variable();
        var2Cons2.setCoefficient(3);
        var2Cons2.setName("x2");
        dummyCons2Variables.add(var2Cons2);

        if (taskForIterator) {
            Variable var2Cons3 = new Variable();
            var2Cons3.setCoefficient(0);
            var2Cons3.setName("x3");
            dummyCons2Variables.add(var2Cons3);

            Variable var2Cons4 = new Variable();
            var2Cons4.setCoefficient(1);
            var2Cons4.setName("x4");
            dummyCons2Variables.add(var2Cons4);
        }
        cons2.setVariables(dummyCons2Variables);

        // set constraint 1 to constraints list
        dummyConstraints.add(cons1);
        // set constraint 2 to constraints list
        dummyConstraints.add(cons2);

        dummyTask.setConstraints(dummyConstraints);
        dummyTask.setBounds(new ArrayList<>());

        return dummyTask;
    }
}
