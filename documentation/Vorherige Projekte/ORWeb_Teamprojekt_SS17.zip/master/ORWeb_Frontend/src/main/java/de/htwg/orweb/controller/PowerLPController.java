/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.controller;

import java.util.List;

import de.htwg.orweb.model.Download;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.ModelAndView;
import de.htwg.orweb.model.Method;
import de.htwg.orweb.model.Solver;
import de.htwg.orweb.service.IDownloadService;
import de.htwg.orweb.service.IMethodService;
import de.htwg.orweb.service.ISolverService;

import javax.servlet.http.HttpServletRequest;

@Controller
public class PowerLPController {

    @Autowired
    private IMethodService methodService;
    @Autowired
    private IDownloadService downloadService;
    @Autowired
    private ISolverService solverService;

    @RequestMapping("/powerlp")
    public ModelAndView powerLPAction(HttpServletRequest request) {

        // **This  checks if solver is online
        String restOfTheUrl = (String) request.getAttribute(
                HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE);
        Solver solver = solverService.findSolverByPath(restOfTheUrl);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("redirect:/404");
        if (solver == null) {
            return modelAndView;
        }
        if (!solver.isActive()) {
            return modelAndView;
        }
        // **END

        List<Method> onlineMethod = methodService.findMethodByActive(true);
        List<Solver> onlineSolver = solverService.findSolverByActive(true);
        List<Download> downloadMethod = downloadService.findAllDownloadByActiveAndType(true, "method");
        List<Download> downloadSolver = downloadService.findAllDownloadByActiveAndType(true, "solver");
        modelAndView.addObject("onlineMethods", onlineMethod);
        modelAndView.addObject("downloadMethods", downloadMethod);
        modelAndView.addObject("onlineSolvers", onlineSolver);
        modelAndView.addObject("downloadSolvers", downloadSolver);
        modelAndView.setViewName("solver/powerlp");


        return modelAndView;
    }
}
