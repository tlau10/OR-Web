/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.controller;

import java.util.ArrayList;
import java.util.List;

import de.htwg.orweb.common.result.ObjectiveResult;
import de.htwg.orweb.common.result.VariableResult;
import de.htwg.orweb.common.task.Bound;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import de.htwg.orweb.OrwebApplication;
import de.htwg.orweb.common.result.Result;
import de.htwg.orweb.common.task.Task;
import de.htwg.orweb.lps.prod.ILPSolver;
import de.htwg.orweb.lps.prod.LPSProduction;

/**
 * Solves the requests from the web userinterface for the different solver. The
 * incoming JSON string is automatically parsed to the Task Model
 *
 * @author Mirko Bay, 2017-05-14
 */
@Controller
public class SolverController {

    @PostMapping("/solve")
    @ResponseBody
    public ResponseEntity<Result> solveTask(@RequestBody Task task) {

        for (Bound b: task.getBounds()) {
            System.err.println(b.toString());
        }

        ILPSolver solver = new LPSProduction(OrwebApplication.SOLVER_CFG_PATH);
        return new ResponseEntity<Result>(solver.solve(task), HttpStatus.OK);
    }

    /**
     * Creates and returns the result from the grütz default example
     *
     * @return A result from the example task
     */
    private Result createExampleResult() {
        Result result = new Result();

        ObjectiveResult objective = new ObjectiveResult();
        objective.setValue(6.85714286);
        result.setObjective(objective);

        VariableResult variableX = new VariableResult();
        variableX.setName("x1");
        variableX.setValue(2.57142857);
        variableX.setReducedCosts(0);

        VariableResult variableY = new VariableResult();
        variableY.setName("x2");
        variableY.setValue(2.14285714);
        variableY.setReducedCosts(0);

        List<VariableResult> variables = new ArrayList<>();
        variables.add(variableX);
        variables.add(variableY);

        result.setVariables(variables);

        result.setFeasible(true);

        return result;
    }

}
