/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import de.htwg.orweb.model.Method;

@Repository("methodRepository")
public interface MethodRepository extends JpaRepository<Method, Long> {
    List<Method> findAll();
    List<Method> findByActive(boolean bool);
    Method findById(int id);
    Method findByName(String name);
    Method findByPath(String path);
}