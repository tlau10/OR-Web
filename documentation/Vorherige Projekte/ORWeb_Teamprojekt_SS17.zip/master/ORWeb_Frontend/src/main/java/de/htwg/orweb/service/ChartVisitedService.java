/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.service;

import de.htwg.orweb.model.ChartVisited;
import de.htwg.orweb.repository.ChartVisitedRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("chartVisitedService")
public class ChartVisitedService implements IChartVisitedService {

    @Autowired
    private ChartVisitedRepository chartVisitedRepository;

    @Override
    public ChartVisited findChartVisitedById(int id) {
        return chartVisitedRepository.findById(id);
    }

    @Override
    public void saveChartVisited(ChartVisited chartVisited) {
        chartVisitedRepository.save(chartVisited);
    }


}
