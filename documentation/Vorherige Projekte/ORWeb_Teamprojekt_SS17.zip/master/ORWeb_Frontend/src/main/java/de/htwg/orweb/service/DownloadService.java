/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.service;

import java.util.List;

import de.htwg.orweb.model.Download;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import de.htwg.orweb.repository.DownloadRepository;

@Service("downloadService")
public class DownloadService implements IDownloadService {

    @Autowired
    private DownloadRepository downloadRepository;


	@Override
	public List<Download> findAllDownloads() {
		return downloadRepository.findAll();
	}

	@Override
	public Download findDownloadByName(String name) {
		return downloadRepository.findByName(name);
	}

	@Override
	public Download findDownloadByPathImage(String pathImage) {
		return downloadRepository.findByPathImage(pathImage);
	}

	@Override
	public Download findDownloadByPath(String path) {
		return downloadRepository.findByPath(path);
	}

	@Override
	public void deleteDownload(Download download) {
		downloadRepository.delete(download);
	}

	@Override
	public List<Download> findAllDownloadByType(String type) {
		return downloadRepository.findByType(type);
	}

	@Override
	public List<Download> findAllDownloadByActiveAndType(boolean bool, String type) {
		return downloadRepository.findByActiveAndType(bool, type);
	}

	@Override
	public List<Download> findAllDownloadByActive(boolean bool) {
		return downloadRepository.findByActive(bool);
	}


	@Override
	public Download findDownloadById(int id) {
		return downloadRepository.findById(id);
	}

	@Override
	public Download saveDownload(Download methodDownload) {
		return downloadRepository.save(methodDownload);
	}
}
