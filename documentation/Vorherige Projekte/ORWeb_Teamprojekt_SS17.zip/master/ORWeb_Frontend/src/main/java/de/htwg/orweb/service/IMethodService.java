/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.service;

import java.util.List;

import de.htwg.orweb.model.Method;

public interface IMethodService {
	public List<Method>  findMethodByActive(boolean bool);
	public List<Method> findAllMethods();
	public Method  findMethodById(int id);
	public Method findMethodByPath(String path);
	public Method  findMethodByName(String name);
	public void saveMethod(Method method);
}
