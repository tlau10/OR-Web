/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.service;

import java.util.List;

import de.htwg.orweb.model.Solver;

public interface ISolverService {
	public List<Solver> findAllSolvers();
	public List<Solver>  findSolverByActive(boolean bool);
	public Solver  findMethodById(int id);
	public Solver findSolverByPath(String path);
	public Solver  findSolverByName(String name);
	public void saveSolver(Solver solver);
}
