/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.service;

import de.htwg.orweb.model.User;

import java.util.List;

public interface IUserService {

    public User findUserByEmail(String email);
    public User findUserById(int id);
    public List<User> findAll();
    public void saveUser(User user);
    public void deleteUser(User user);

}
