/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.validator;

import de.htwg.orweb.form.UploadForm;
import de.htwg.orweb.service.DownloadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class UploadValidator implements Validator {
    @Autowired
    private DownloadService downloadService;

    private final int MAX_FILE_SIZE = 52428800; //50 MB

    @Override
    public boolean supports(Class<?> aClass) {
        return UploadForm.class.equals(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
        UploadForm upload = (UploadForm) o;

        if (downloadService.findDownloadByPath(upload.getPath().getOriginalFilename()) != null) {
            errors.rejectValue("path", "Duplicate.uploadForm.path");
        }
        if (downloadService.findDownloadByPathImage(upload.getPathImage().getOriginalFilename()) != null) {
            errors.rejectValue("pathImage", "Duplicate.uploadForm.pathImage");
        }
        System.err.println(upload.getPath().getSize());
        if (upload.getPath().getSize() > MAX_FILE_SIZE) {
            errors.rejectValue("path", "Size.uploadForm.file");
        }
        if (upload.getPathImage().getSize() > MAX_FILE_SIZE && upload.getPathImage().getSize() == 0 ) {
            errors.rejectValue("pathImage", "Size.uploadForm.file");
        }
        if (upload.getPath().isEmpty()){
            errors.rejectValue("path", "Size.uploadForm.file.empty");
        }

        ValidationUtils.rejectIfEmpty(errors, "name", "NotEmpty");
        ValidationUtils.rejectIfEmpty(errors, "desc", "NotEmpty");
        ValidationUtils.rejectIfEmpty(errors, "type", "NotEmpty");
        ValidationUtils.rejectIfEmpty(errors, "active", "NotEmpty");

    }

    public void validateEdit(Object o, Errors errors) {
        UploadForm upload = (UploadForm) o;

        if (downloadService.findDownloadByPath(upload.getPath().getOriginalFilename()) != null) {
            errors.rejectValue("path", "Duplicate.uploadForm.path");
        }
        if (downloadService.findDownloadByPathImage(upload.getPathImage().getOriginalFilename()) != null) {
            errors.rejectValue("pathImage", "Duplicate.uploadForm.pathImage");
        }

        ValidationUtils.rejectIfEmpty(errors, "name", "NotEmpty");
        ValidationUtils.rejectIfEmpty(errors, "desc", "NotEmpty");
        ValidationUtils.rejectIfEmpty(errors, "type", "NotEmpty");
        ValidationUtils.rejectIfEmpty(errors, "active", "NotEmpty");

    }
}