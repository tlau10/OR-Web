/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

function ajaxUpdateActive(id) {
    // Get form
    var form = $('#fileUploadForm' + id)[0];
    var data = new FormData(form);
    var dest;
    data.append("CustomField", "This is some extra data, testing");
    $("#btnSubmit" + id).prop("disabled", true);
    if (window.location.href.indexOf("solvers") > -1) {
        dest = "solvers";
    } else if (window.location.href.indexOf("methods") > -1) {
        dest = "methods";
    } else {
        dest = "downloads"
    }
    $.ajax({
        type: "POST",
        enctype: 'multipart/form-data',
        url: "/admin/" + dest,
        data: data,
        //http://api.jquery.com/jQuery.ajax/
        //https://developer.mozilla.org/en-US/docs/Web/API/FormData/Using_FormData_Objects
        processData: false, //prevent jQuery from automatically transforming the data into a query string
        contentType: false,
        cache: false,
        timeout: 600000,
        success: function (data) {
            //$("#result" + id).text(data[0]);
            $("#btnSubmit+id").prop("disabled", false);
            displayAction(data[1], data[2], data[3], data[4], data[5], data[6]);
        },
        error: function (e) {
            //$("#result" + id).text(e.responseText);
            console.log("ERROR : ", e);
            $("#btnSubmit" + id).prop("disabled", false);
        }
    });
}
// Show or hide panel menu items
function displayAction(id, name, statusAll, download, status, statusWholeDownloads) {

    if ("method" === name) {
        if ("true" === statusAll) {
            $("#showMethods").addClass('hidden');
        }
        if ("false" == statusAll) {
            $("#showMethods").removeClass('hidden');
        }
        if ("true" == status) {
            $("#method" + id).removeClass('hidden');
            $("#result" + id).text("Online");
        }
        if ("false" == status) {
            $("#method" + id).addClass('hidden');
            $("#result" + id).text("Offline");
        }
    }

    if ("solver" === name) {
        if ("true" === statusAll) {
            $("#showSolvers").addClass('hidden');
        }
        if ("false" == statusAll) {
            $("#showSolvers").removeClass('hidden');
        }
        if ("true" == status) {
            $("#solver" + id).removeClass('hidden');
            $("#result" + id).text("Online");
        }
        if ("false" == status) {
            $("#solver" + id).addClass('hidden');
            $("#result" + id).text("Offline");
        }
    }

    if ("download" === name) {
        if ("true" === statusWholeDownloads && "0" === id) {
            console.log("whole downloads are Offline");
            $("#downloads").addClass('hidden');
            $("#showDownloads").addClass('hidden');
            $("#showMethodDownloads").addClass('hidden');
            $("#showSolverDownloads").addClass('hidden');
            $("input").prop('checked', false);
            $('span').text("Offline");
            $('*[id*=showDownload]').each(function () {
                $(this).addClass('hidden');
            });
        }
        if ("false" === statusWholeDownloads && "0" === id) {
            $("#showDownloads").removeClass('hidden');
            $("#showMethodDownloads").removeClass('hidden');
            $("#showSolverDownloads").removeClass('hidden');
            $("input").prop('checked', true);
            $('span').text("Online");
            $('*[id*=showDownload]').each(function () {
                $(this).removeClass('hidden');
            });
        }
        if ("true" === status && "0" !== id) {
            console.log("active is true");
            $("#showDownload" + id).removeClass('hidden');
            $("#result" + id).text("Online");
            if("false" === statusAll && "method" === download){
                $("#showMethodDownloads").removeClass('hidden');
            }
            if("false" === statusAll && "solver" === download){
                console.log("min one is online and its a solver");
                $("#showSolverDownloads").removeClass('hidden');
            }
            if("false" === statusWholeDownloads) {
                $("#fileUploadForm0 input").prop('checked', true);
                $("#showDownloads").removeClass('hidden');
                $("#result0").text("Online");
            }
        }
        if ("false" === status && "0" !== id) {
            $("#showDownload" + id).addClass('hidden');
            $("#result" + id).text("Offline");
            if("true" === statusAll && "method" === download){
                $("#showMethodDownloads").addClass('hidden');
            }
            if("true" === statusAll && "solver" === download){
                $("#showSolverDownloads").addClass('hidden');
            }
            if("true" === statusWholeDownloads) {
                $("input").prop('checked', false);
                $("#showDownloads").addClass('hidden');
                $("#downloads").addClass('hidden');
                $("#result0").text("Offline");
            }
        }
    }

}