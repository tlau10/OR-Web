/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

$(document).ready(function () {
    if ($("#sidebar div ul").children("li").hasClass('active')) {
        var selected = $(".active").closest("div").prop("id");
        $('#' + selected).toggleClass('hidden');
    }
});
function togglePanel(id) {

    // proofs if element is available or is not rendered
    if (id !== "method" && $(".active").closest("div").prop("id") !== "method") {
        var methodElement = $("#method");
        methodElement.addClass('hidden');
    }
    if (id !== "solver" && $(".active").closest("div").prop("id") !== "solver") {
        $("#solver").addClass('hidden');
    }
    if (id !== "downloads" && $(".active").closest("div").prop("id") !== "downloads") {
        $("#downloads").addClass('hidden');
    }
    if (id !== "feedback" && $(".active").closest("div").prop("id") !== "feedback") {
        $("#feedback").addClass('hidden');
    }
    if (id !== "admin" && $(".active").closest("div").prop("id") !== "admin") {
        $("#admin").addClass('hidden');
    }


    $("#" + id).toggleClass('hidden');
    $("#" + id).toggleClass('minusSign');
}