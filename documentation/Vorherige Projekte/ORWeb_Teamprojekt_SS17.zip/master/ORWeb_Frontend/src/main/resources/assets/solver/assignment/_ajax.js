/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

var AjaxHandler = (function () {

    var exampleTask = {
        "meta": {
            "solver": "lp_solve"
        },
        "objective": {
            "type": "max",
            "variables": [{
                "name": "x1",
                "coefficient": "1"
            }, {
                "name": "x2",
                "coefficient": "1"
            }]

        },
        "constraints": [{
            "type": "L",
            "name": "R1",
            "rhs": "12",
            "variables": [{
                "name": "x1",
                "coefficient": "3"
            }, {
                "name": "x2",
                "coefficient": "2"
            }]
        }, {
            "type": "L",
            "name": "R2",
            "rhs": "9",
            "variables": [{
                "name": "x1",
                "coefficient": "1"
            }, {
                "name": "x2",
                "coefficient": "3"
            }]

        }],
        "bounds": []
    };

    //
    var matrix;
    var rhsVariables = [];

    // the amout of the variables (columns)
    var amountOfVariables = 0;

    // the number of Fields
    var amountOfFields = 0;

    // the summ of all Variables
    var sumOfAllVariableValues = 0;

    function getValuesFromTableToMatrix() {

        var rows = matrixTable.rows;
        var tmpArray = [];

        // start with 1, so we ignore the row in the thead element
        for (var i = 1; i < rows.length; i++) {
            var item = rows[i];
            var constraintCells = item.cells;
            var tmpConstraint = [];

            // iterate over the cells of the row
            for (var j = 1; j < (constraintCells.length); j++) {
                var valueOfCell = constraintCells.item(j).firstElementChild.value;
                tmpConstraint.push(parseInt(valueOfCell));
            }

            tmpArray.push(tmpConstraint);
        }
        matrix = tmpArray;
    }


    /**
     * @returns
     */
    function collectTaskData() {

        // proofs if both tables are valid
        if (!checkIfTableIsValid()) {
            console.log("table is not valid");
            return;
        }

        // Reset all Variables
        matrix = [];
        rhsVariables = [];
        amountOfVariables = 0;
        amountOfFields = 0;
        sumOfAllVariableValues = 0;

        // the sum of all values of all cells
        getValuesFromTableToMatrix();
        //var objType = document.getElementById("assignment-minMaxSelector").value;

        var task = {};
        // add the meta attributes
        task.meta = {};
        task.meta.solver = document.getElementById("solverSelection").value;
        task.meta.forcePositive=true;
        // add the objective
        task.objective = {};
        task.objective.type = "max";
        task.objective.variables = [];
        // Create bounds for task object
        task.bounds = [];

        var varCount = 1;
        // Create objective function and bounds
        for (var i = 0; i < matrix.length; i++) {
            for (var j = 0; j < matrix[i].length; j++) {
                var tmpVariable = {};
                tmpVariable.name = "x" + (varCount);
                tmpVariable.coefficient = matrix[i][j];
                task.objective.variables.push(tmpVariable);
                var tmpBound = {};
                tmpBound.variableName = "x" + (varCount);
                tmpBound.integer = true;
                task.bounds.push(tmpBound);
                varCount++;
            }
        }

        task.constraints = [];
        varCount = 1;
        var constCount = 1;
        // Create row constraints
        for (var i = 0; i < matrix.length; i++) {
            var tmpConstraint = {};
            tmpConstraint.name = "R" + constCount;
            tmpConstraint.type = "L";
            tmpConstraint.rhs = 1.0;
            tmpConstraint.variables = [];
            for (var j = 0; j < matrix[i].length; j++) {
                var tmpVariable = {};
                tmpVariable.name = "x" + (varCount);
                tmpVariable.coefficient = 1.0;
                tmpConstraint.variables.push(tmpVariable);
                varCount++;
            }
            task.constraints.push(tmpConstraint);
            constCount++;
        }

        var cols = matrix[0].length;
        var rows = matrix.length;
        amountOfVariables = cols * rows;

        for (var i = 0; i < cols; i++) {
            var tmpConstraint = {};
            tmpConstraint.name = "R" + constCount;
            tmpConstraint.type = "L";
            tmpConstraint.rhs = 1.0;
            tmpConstraint.variables = [];
            for (var j = 0; j < rows; j++) {
                var tmpVariable = {};
                tmpVariable.name = "x" + ((j * cols) + (i + 1));
                tmpVariable.coefficient = 1.0;
                tmpConstraint.variables.push(tmpVariable);
            }
            task.constraints.push(tmpConstraint);
            constCount++;
        }
        return task;
    }

    /**
     *
     * @param task:
     *            the task as a javascript object, specified in the example at top
     * @returns
     */
    function sendTask(task, showResponseToUser) {

        // make ajax call to solve the task
        var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject(
            'Microsoft.XMLHTTP');
        xhr.open("POST", "solve");

        xhr.onreadystatechange = function () {

            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    // 'This is the returned text.'
                    console.log("Response ok, ");
                    result = JSON.parse(xhr.responseText);
                    if (showResponseToUser) {
                        processResponse(result);
                    } else {
                        // the call comes from the solveForExport function
                        var nowDate = new Date();
                        download(result.model.mpsModel, "assignmentplanning_" + nowDate.getFullYear() + (nowDate.getMonth() + 1) + nowDate.getUTCDate() + nowDate.getHours() + nowDate.getMinutes() + ".mps", "application/x-mps");  // reset the result object
                    }

                } else {
                    // An error occurred during the request.
                    console.log("AJAX ERROR (" + xhr.status + ")");
                }
            }
        };
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(JSON.stringify(task));
    }


    function processResponse(resultObject) {
        var responseBlock = document.getElementById("response");
        responseBlock.innerHTML = "";

        if (!resultObject.feasible) {
            responseBlock.innerHTML = "<h4>" + titleResult + "</h4>";
            responseBlock.innerHTML += "<p>" + titleNotFeasible + "</p>";
            scrollToResult();
            return;
        }

        var processingTime = document.createElement("p");
        processingTime.id = "processingTime";
        processingTime.innerHTML = solverProcessingTime + ":&nbsp;";
        processingTime.innerHTML += resultObject.processingTime;
        processingTime.innerHTML += "&nbsp;ms";
        responseBlock.appendChild(processingTime);

        var header = document.createElement("h4");
        header.innerHTML = "<h4>" + titleResult + "</h4>";
        responseBlock.appendChild(header);

        var resultVariables = [];
        var k = 0;
        for (var i = 0; i < amountOfVariables; i++) {
            if (k < result.variables.length) {
                var variable = result.variables[k];
                var nameInt = parseInt(variable.name.slice(1));
                if (nameInt == (i + 1)) {
                    resultVariables.push(variable.value);
                    k++;
                } else {
                    resultVariables.push(0);
                }
            } else {
                resultVariables.push(0);
            }
        }

        var assignmentTable = [];
        var counterTable = 0;
        for (var i = 0; i < matrix.length; i++) {
            assignmentTable.push([]);
            for (var j = 0; j < matrix[i].length; j++) {
                assignmentTable[i].push(resultVariables[counterTable]);
                counterTable++
            }
        }

        var assTable = document.createElement("table");


        for (var i = 0; i < assignmentTable.length; i++) {
            var row = document.createElement("tr");
            assTable.appendChild(row);
            var data = document.createElement("td");
            row.appendChild(data);
            // &nbsp; means non breaking space
            data.innerHTML = headerTableauRow + " " + (i + 1);
            for (var j = 0; j < assignmentTable[i].length; j++) {
                if (assignmentTable[i][j] >= 1) {
                    var data = document.createElement("td");
                    row.appendChild(data);
                    data.innerHTML = headerTableauColumn + " " + (j + 1);
                    break;
                }
            }
        }
        responseBlock.appendChild(assTable);
        responseBlock.appendChild(document.createElement("br"));

        var collapseInit = document.createElement("button");
        collapseInit.setAttribute("data-toggle", "collapse");
        collapseInit.setAttribute("data-target", "#resultVariableBlock");
        collapseInit.innerHTML = collapseText;
        responseBlock.appendChild(collapseInit);

        var collapseBlock = document.createElement("div");
        collapseBlock.setAttribute("class", "collapse");
        collapseBlock.setAttribute("id", "resultVariableBlock");


        var objective = document.createElement("p");
        objective.innerHTML = objectiveFunctionText + " = " + result.objective.value;
        collapseBlock.appendChild(document.createElement("br"));
        collapseBlock.appendChild(objective);

        for (var i = 0; i < resultVariables.length; i++) {
            var variableElement = document.createElement("p");
            variableElement.innerHTML = variableText + " x" + (i + 1) + " = " + resultVariables[i];
            collapseBlock.appendChild(variableElement);
        }

        responseBlock.appendChild(collapseBlock);
        responseBlock.appendChild(document.createElement("br"));

        scrollToResult();
    }


    /**
     * scrolls the view smoothly
     * to the result block
     */
    function scrollToResult() {
        document.getElementById("responseWrapper").classList.remove("hidden");

        // http://iamdustan.com/smoothscroll/
        document.getElementById("response").scrollIntoView({
            behavior: 'smooth'
        });

    }

    function solveTask() {
        var task = collectTaskData();
        if (task != undefined) {
            sendTask(task, true);
        }
    }

    function solveForExport() {
        var task = collectTaskData();
        if (task != undefined) {
            sendTask(task, false);
        }
    }

    function exportMPS() {
        solveForExport();
    }


    return {
        solveTask: solveTask,
        exportMPS: exportMPS
    };

})
();