/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

var ImportUtil = (function () {

    // https://developer.mozilla.org/en-US/docs/Using_files_from_web_applications
    function sendFileToImport(files) {
        if (!files.length) {
            // shouldn't happen
            toastr.info(importMessageNoFileSelected);
            return;
            // on windows the uploaded file got no type!
            //} else if (!files[0].type.match('application/x-mps')) {
        } else if (files[0].name.indexOf(".mps") === -1) {
            toastr.info(importMessageJustMPS);
        } else {
            // send file as file to server, import controller
            var xhr = window.XMLHttpRequest ? new XMLHttpRequest()
                : new ActiveXObject('Microsoft.XMLHTTP');
            xhr.open("POST", "import");

            xhr.onreadystatechange = function () {

                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {

                        showImportedDataInTable(xhr.responseText);

                    } else {
                        // now called in the /js/spinner/ajaxSpinner.js
                        //toastr.info("Error " + xhr.status);
                    }
                }
            };

            xhr.setRequestHeader('Content-Type', 'application/x-mps');
            xhr.send(files[0]);
        }
    }

    function showImportedDataInTable(responseData) {

        var task = JSON.parse(responseData);
        var objectiveVariables = task.objective.variables;
        var constraints = task.constraints;

        console.log(task);


        // amount of columns
        var cols = objectiveVariables.length;
        // amount of columns (without objective)
        var rows = constraints.length;

        var tmpMatrix = [];

        for (var i = 0; i < rows; i++) {

            tmpMatrix[i] = [];

            var constraint = constraints[i];
            var constraintVariables = constraint.variables;
            for (var k = 0; k < cols; k++) {
                tmpMatrix[i][k] = new Fraction(constraintVariables[k].coefficient);
            }

            tmpMatrix[i][cols] = new Fraction(constraint.rhs);
        }

        // objective function
        tmpMatrix[rows] = [];

        // objective function, at bottom
        for (var j = 0; j < cols; j++) {
            tmpMatrix[rows][j] = new Fraction(objectiveVariables[j].coefficient);
        }

        // todo: check if its ever 0
        tmpMatrix[rows][cols] = new Fraction(0);

        // todo: when do we need negate the objective function?
        if (task.objective.type === "max") {
            for (var l = 0; l < tmpMatrix[rows].length; l++) {
                tmpMatrix[rows][l] = (tmpMatrix[rows][l]).mul(-1);
            }
        }

        matrix = tmpMatrix;
        pivotElementIsSet = false;
        // numbOfVariables = cols;
        // numbOfConstraints = rows;

        correctVariables(cols);
        correctConstraints(rows);

        console.log(cols);
        console.log(rows);
        console.log(matrix);

        copyMatrixToTable();
    }

    /**
     * manipulates the html table, so the data can be imported
     *
     * @param newValue
     */
    function correctVariables(newValue) {
        var diffVariables = newValue - numbOfVariables;

        if (diffVariables > 0) {
            for (var i = 0; i < diffVariables; i++) {
                numbOfVariables++;
                TableManipulator.addVariable();
            }
        } else if (diffVariables < 0) {
            for (var j = diffVariables; j < 0; j++) {
                if (numbOfVariables < 2) {
                    break;
                }
                numbOfVariables--;
                TableManipulator.removeVariable();
            }
        }

        document.getElementById("numbOfVariables").value = numbOfVariables;

    }

    /**
     * manipulates the html table, so the data can be imported
     *
     * @param newValue
     */
    function correctConstraints(newValue) {
        var diffVariables = newValue - numbOfConstraints;

        if (diffVariables > 0) {
            for (var i = 0; i < diffVariables; i++) {
                numbOfConstraints++;
                TableManipulator.addConstraint(numbOfConstraints);
            }
        } else if (diffVariables < 0) {
            for (var j = diffVariables; j !== 0; j++) {
                if (numbOfConstraints < 1) {
                    break;
                }
                numbOfConstraints--;
                TableManipulator.removeConstraint();
            }
        }

        document.getElementById("numbOfConstraints").value = numbOfConstraints;

    }

    return {
        sendFileToImport: sendFileToImport
    };

})();