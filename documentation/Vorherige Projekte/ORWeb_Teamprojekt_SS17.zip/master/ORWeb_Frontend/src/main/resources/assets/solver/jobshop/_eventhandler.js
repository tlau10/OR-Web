/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */
var EventHandler = (function () {

    var minNumbVariables = 2;
    var minNumbConstraints = 2;

    function processUserInputVariables(event) {
        var timeoutVariablesInput = null;
        clearTimeout(timeoutVariablesInput);
        timeoutVariablesInput = setTimeout(function () {
            // get diff from old value / new value
            var newValue = document.getElementById("numbOfVariables").value;
            var form = document.getElementById("numbOfVariables");

            if (newValue === "") {
                // nothing to do, waiting for user input
                // return;
            } else if (newValue > 1 && newValue <= 100) {

                var diffVariables = newValue - numbOfVariables;

                if (diffVariables > 0) {
                    for (var i = 0; i < diffVariables; i++) {
                        numbOfVariables++;
                        TableManipulator.addVariable();
                    }
                } else if (diffVariables < 0) {
                    for (var j = diffVariables; j < 0; j++) {
                        if (numbOfVariables < minNumbVariables) {
                            break;
                        }
                        numbOfVariables--;
                        TableManipulator.removeVariable();
                    }
                }
            } else {
                document.getElementById("numbOfVariables").value = numbOfVariables;
                toastr.info(inputSolverError);
            }

        }, 500);

    }

    /**
     *
     * validates the user input for the constrain input field. Minimum number of
     * constraints is 1. Triggers the creation of the constraint rows
     *
     * @param event
     * @returns
     */
    function processUserInputConstraints(event) {
        var timeoutConstraintInput = null;
        clearTimeout(timeoutConstraintInput);
        timeoutConstraintInput = setTimeout(
            function () {

                var newValue = document.getElementById("numbOfConstraints").value;

                if (newValue === "") {
                    // nothing to do, waiting for user input
                } else if (newValue > 1 && newValue <= 100) {
                    var diffVariables = newValue - numbOfConstraints;

                    if (diffVariables > 0) {
                        for (var i = 0; i < diffVariables; i++) {
                            numbOfConstraints++;
                            TableManipulator.addConstraint(numbOfConstraints);
                        }
                    } else if (diffVariables < 0) {
                        for (var j = diffVariables; j !== 0; j++) {
                            if (numbOfConstraints < minNumbConstraints) {
                                break;
                            }
                            numbOfConstraints--;
                            TableManipulator.removeConstraint();
                        }
                    }
                } else {
                    document.getElementById("numbOfConstraints").value = numbOfConstraints;
                    toastr.info(inputSolverError);
                }
            }, 500);
    }


    /**
     *
     * @returns
     */
    function initEventHandler() {

        // disable the scrolling on the number inputs
        document.getElementById("numbOfVariables").addEventListener("mousewheel",
            function (event) {
                event.preventDefault();
            });

        document.getElementById("numbOfConstraints").addEventListener("mousewheel",
            function (event) {
                event.preventDefault();
            });

        document
            .getElementById("incrementNumberOfVariables")
            .addEventListener(
                "click",
                function () {
                    numbOfVariables++;
                    document.getElementById("numbOfVariables").value = numbOfVariables;
                    TableManipulator.addVariable();
                });
        document
            .getElementById("decrementNumberOfVariables")
            .addEventListener(
                "click",
                function () {
                    if (numbOfVariables > minNumbVariables) {
                        numbOfVariables--;
                        document.getElementById("numbOfVariables").value = numbOfVariables;
                        TableManipulator.removeVariable();
                    }
                });

        document
            .getElementById("incrementNumberOfConstraints")
            .addEventListener(
                "click",
                function () {
                    numbOfConstraints++;
                    document.getElementById("numbOfConstraints").value = numbOfConstraints;
                    TableManipulator.addConstraint(numbOfConstraints);
                });
        document
            .getElementById("decrementNumberOfConstraints")
            .addEventListener(
                "click",
                function () {
                    if (numbOfConstraints > minNumbConstraints) {
                        numbOfConstraints--;
                        document.getElementById("numbOfConstraints").value = numbOfConstraints;
                        TableManipulator.removeConstraint();
                    }
                });

        document.getElementById("numbOfVariables").addEventListener("keyup",
            processUserInputVariables);

        document.getElementById("numbOfConstraints").addEventListener("keyup",
            processUserInputConstraints);

        // add the event listener for the reset button
        document.getElementById("reset").addEventListener("click", TableManipulator.reset);

        // add the event listener for the solve button
        document.getElementById("solve").addEventListener("click", AjaxHandler.solveTask);

        //add the event listener for the export button
        document.getElementById("export").addEventListener("click", AjaxHandler.exportMPS);

        // load a example task
        document.getElementById("loadExample").addEventListener("click", loadExample);

    }

    return {
        initEventHandler: initEventHandler
    };

})();