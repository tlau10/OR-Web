/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

// HTMLTableElement: holds the reference to the html table
var matrixTable;
// number: the current amount of constraints (=rows)
var numbOfConstraints;

var stateLastColumn = false;


function init() {

    toastr.info(msgAutoFill, 'Info', { timeOut: 15000, closeButton: true });

    matrixTable = document.getElementById("matrix");
    numbOfConstraints = document.getElementById("numbOfPeriods").value;

    EventHandler.initEventHandler();

    TableManipulator.createMatrixHeader();


    // create rows for the constraints
    for (var i = 0; i < numbOfConstraints; i++) {
        TableManipulator.addConstraint(i + 1);
    }
}
/**
 * checks the validity of the matrix (with the native html5 form validation
 *
 * @return {boolean}
 */
function checkIfTableIsValid() {

    // check the tableau table
    var tableauForm = document.getElementById("matrixForm");
    if (!tableauForm.checkValidity()) {
        //alert("Ungültige Werte in Matrix!");
        // triggers the native html5 form validation
        var submitButtonTableau = document.getElementById("submitButton");
        submitButtonTableau.click();
        return false;
    } else {
        return true;
    }
}

/**
 * checks the user input live against the pattern for a rational number so the
 * user can just type following number types: > integer, e.g. "1" > float, e.g.
 * "3/4" > mixed float, e.g. "3,2/4" or "3/4,2" > input with both comma and dot
 *
 * @returns
 */
function checkUserNumberInput(event) {

    var input = event.target.value;
    var regex = new RegExp("^[0-9]+$", "g");
    // if invalid input
    if (input.length === 0) {
        return;
    }

    // TODO : 	bisher wird pauschal immer der Click durchgeführt für die Validation-Message
    //			besser wäre, wenn das nur passiert wenn die Regex nicht erfüllt wird

    // triggers the native html5 form validation
    var submitButton;

    submitButton = document.getElementById("submitButton");

    submitButton.click();
}
function checkUserNumberInputWithComma(event) {

    var input = event.target.value;
    var regex = new RegExp("^[\\-]{0,1}[0-9]{1,}((,|\.)[0-9]{1,}){0,1}((/0(,|\.)([1-9]{1,}[0-9]{0,}|[0-9]{1,}[1-9]))|(/[1-9]{1,}((,|\.)[0-9]{1,}){0,1})){0,1}$", "g");
    // if invalid input
    if (input.length === 0) {
        return;
    }

    // TODO : 	bisher wird pauschal immer der Click durchgeführt für die Validation-Message
    //			besser wäre, wenn das nur passiert wenn die Regex nicht erfüllt wird

    // triggers the native html5 form validation
    var submitButton;

    submitButton = document.getElementById("submitButton");

    submitButton.click();
}

/**
 * load a example task
 */
function loadExample() {
    // reset the size of the table
    TableManipulator.reset();
    var rows = matrixTable.rows;
    // row[0] is the header
    rows[1].childNodes[1].firstElementChild.value = 1;
    rows[1].childNodes[2].firstElementChild.value = 2;
    rows[1].childNodes[3].firstElementChild.value = 3;

    rows[2].childNodes[1].firstElementChild.value = 1;
    rows[2].childNodes[2].firstElementChild.value = 2;
    rows[2].childNodes[3].firstElementChild.value = 3;
}
