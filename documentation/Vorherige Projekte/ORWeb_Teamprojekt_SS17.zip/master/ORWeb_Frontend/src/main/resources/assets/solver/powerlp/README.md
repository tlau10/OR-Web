# Used Librarys

#### Fraction.js

#### [Download.js](https://github.com/rndme/download)
MIT License, Copyright (c) 2016 dandavis

npm install downloadjs