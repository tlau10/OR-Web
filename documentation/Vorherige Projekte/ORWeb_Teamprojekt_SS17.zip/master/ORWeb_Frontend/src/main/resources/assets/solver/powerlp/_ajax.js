/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */
var AjaxHandler = (function () {

    var exampleTask = {
        "meta": {
            "solver": "lp_solve"
        },
        "objective": {
            "type": "max",
            "variables": [{
                "name": "x1",
                "coefficient": "1"
            }, {
                "name": "x2",
                "coefficient": "1"
            }]

        },
        "constraints": [{
            "type": "L",
            "name": "R1",
            "rhs": "12",
            "variables": [{
                "name": "x1",
                "coefficient": "3"
            }, {
                "name": "x2",
                "coefficient": "2"
            }]
        }, {
            "type": "L",
            "name": "R2",
            "rhs": "9",
            "variables": [{
                "name": "x1",
                "coefficient": "1"
            }, {
                "name": "x2",
                "coefficient": "3"
            }]

        }],
        "bounds": []
    };

    function collectConstraintsData() {
        var tmpArray = [];
        var constraintRows = document.getElementsByClassName("constraint");
        for (var i = 0; i < constraintRows.length; i++) {
            var item = constraintRows[i];
            var constraintCells = item.cells;
            // create a constraint object
            var tmpConstraint = {};
            tmpConstraint.name = "R" + (i + 1);
            tmpConstraint.variables = [];
            // iterate over the cells of the row
            for (var j = 1; j < (constraintCells.length - 2); j++) {
                var tmpVariable = {};
                tmpVariable.name = "x" + (j);
                var coeff = new Fraction(convertValueFromInputToFraction(constraintCells.item(j).firstElementChild.value));
                tmpVariable.coefficient = coeff.round(5).toString();
                tmpConstraint.variables.push(tmpVariable);
            }

            tmpConstraint.type = constraintCells
                .item(constraintCells.length - 2).firstElementChild.value;
            tmpConstraint.rhs = constraintCells
                .item(constraintCells.length - 1).firstElementChild.value;
            tmpArray.push(tmpConstraint);
        }
        return tmpArray;
    }

    function collectBoundsData() {
        var tmpArray = [];
        for (var i = 1; i < bounds.rows.length; i++) {
            var cells = bounds.rows.item(i).cells;
            var tmpBound = {};

            tmpBound.variableName = "x" + i;

            var lowerInput = cells.item(1).firstElementChild.value;
            if (lowerInput !== "") {
                var lower = new Fraction(convertValueFromInputToFraction(lowerInput));
                tmpBound.lowerBound = lower.round(5).toString();
            }
            var upperInput = cells.item(2).firstElementChild.value;
            if (upperInput !== "") {
                var upper = new Fraction(convertValueFromInputToFraction(upperInput));
                tmpBound.upperBound = upper.round(5).toString();
            }
            tmpBound.integer = cells.item(3).firstElementChild.checked;

            tmpArray.push(tmpBound);

        }
        return tmpArray;
    }

    /**
     *
     * @returns
     */
    function collectTaskData() {

        // proofs if both tables are valid
        if (!checkIfTableIsValid()) {
            console.log("table is not valid");
            return;
        }


        // create task object
        var task = {};

        // add the meta attributes
        task.meta = {};
        // todo: static value because we got no other solver
        task.meta.solver = document.getElementById("solverSelection").value;
        task.meta.forcePositive = "true";

        // add the objective
        task.objective = {};
        task.objective.type = document.getElementById("minMaxSelector").value;
        task.objective.variables = [];

        // collect all data from the objective function
        var targetFunctionRow = document.getElementById("targetFunction");
        var targetFunctionCells = targetFunctionRow.cells;
        for (var i = 1; i < (targetFunctionCells.length - 2); i++) {
            var tmp = {};
            tmp.name = "x" + (i);
            var coeff = new Fraction(convertValueFromInputToFraction(targetFunctionCells.item(i).firstElementChild.value));
            tmp.coefficient = coeff.round(5).toString();
            task.objective.variables.push(tmp);
        }

        // collect all data from the constraints
        task.constraints = collectConstraintsData();

        // bounds
        task.bounds = collectBoundsData();

        return task;
    }


    /**
     *
     * @param task: the task as a javascript object, specified in the example at top
     * @param showResponseToUser: show the response to the user or not
     * @returns
     */
    function sendTaskToServer(task, showResponseToUser) {

        // remove the previously created event listener,
        // workaround with a copy of the button
        var old_element = document.getElementById("spinner-cancelRequest");
        var new_element = old_element.cloneNode(true);
        old_element.parentNode.replaceChild(new_element, old_element);

        // make ajax call to solve the task
        var xhr = window.XMLHttpRequest ? new XMLHttpRequest()
            : new ActiveXObject('Microsoft.XMLHTTP');
        xhr.open("POST", "solve");

        xhr.onreadystatechange = function () {

            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    // 'This is the returned text.'
                    resultObject = JSON.parse(xhr.responseText);
                    if (showResponseToUser) {
                        Util.showResponse(resultObject);
                    } else {
                        // the call comes from the solveForExport function
                        var now = new Date();
                        download(resultObject.model.mpsModel, "powerlp_"
                            + now.getFullYear()
                            + (now.getMonth() + 1)
                            + now.getUTCDate()
                            + now.getHours()
                            + now.getMinutes()
                            + ".mps", "application/x-mps");
                    }
                } else {
                    console.log("AJAX ERROR " + xhr.status);
                    // now called in the /js/spinner/ajaxSpinner.js
                    //toastr.info("Error " + xhr.status);
                }
            }

        };

        // set eventlistener
        document.getElementById("spinner-cancelRequest").addEventListener("click", function() {
            xhr.abort();
        });

        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(JSON.stringify(task));
    }

    function solveTask() {
        var task = collectTaskData();
        if (task != undefined) {
            sendTaskToServer(task, true);
        }
    }


    function solveForExport() {
        var task = collectTaskData();
        if (task != undefined) {
            sendTaskToServer(task, false);
        }
    }


    /**
     *
     *
     * @param value
     */
    function convertValueFromInputToFraction(value) {
        var res = value.replace(",", ".");
        return new Fraction(res);
    }

    return {
        collectTaskData: collectTaskData,
        solveTask: solveTask,
        solveForExport: solveForExport
    };

})();
