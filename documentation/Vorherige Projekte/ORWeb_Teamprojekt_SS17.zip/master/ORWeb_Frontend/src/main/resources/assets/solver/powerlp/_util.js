/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */
var Util = (function () {

    // if no bound is set, this value is deliverd from the solver
    var thisValueEqualsNoBoundIsSet = 100000000000000000000;

    function showResponse(response) {

        var responseBlock = document.getElementById("response");
        responseBlock.innerHTML = "";

        if (!response.feasible) {
            responseBlock.innerHTML = "<h4>" + titleResult + "</h4>";
            //responseBlock.innerHTML += "<h5>" + whichSolver.options[whichSolver.selectedIndex].innerText + "</h5>";
            responseBlock.innerHTML += "<p>" + titleNotFeasible + "</p>";
            scrollToResult();
            return;
        }

        var processingTime = document.createElement("p");
        processingTime.id = "processingTime";
        processingTime.innerHTML = solverProcessingTime + ":&nbsp;";
        processingTime.innerHTML += response.processingTime;
        processingTime.innerHTML += "&nbsp;ms";
        responseBlock.appendChild(processingTime);

        var header = document.createElement("h4");
        header.innerHTML = "<h4>" + titleResult + "</h4>";
        header.innerHTML += "<h5>" + whichSolver.options[whichSolver.selectedIndex].innerText + "</h5>";
        responseBlock.appendChild(header);

        var objective = document.createElement("p");
        objective.innerHTML = labelObjectiveValue + " = " + resultObject.objective.value;
        responseBlock.appendChild(objective);

        for (var i = 0; i < resultObject.variables.length; i++) {
            var variableElement = document.createElement("p");
            var variable = resultObject.variables[i];
            variableElement.innerHTML = labelVariable + " " + variable.name + " = " + variable.value;
            variableElement.appendChild(document.createElement("br"));
            variableElement.innerHTML += labelReducedCosts + " = " + variable.reducedCosts;
            responseBlock.appendChild(variableElement);
            responseBlock.appendChild(document.createElement("br"));
        }

        scrollToResult();
    }

    /**
     * scrolls the view smoothly
     * to the result block
     */
    function scrollToResult() {
        document.getElementById("responseWrapper").classList.remove("hidden");
        // http://iamdustan.com/smoothscroll/
        document.getElementById("response").scrollIntoView({
            behavior: 'smooth'
        });

    }

    /**
     * triggers the export of the mps file;
     * if the solution is not yet available, the ajax call for retrieving  the result object is called
     *
     */
    function exportMPS() {
        AjaxHandler.solveForExport();
        resultObject = null;
    }


    // https://developer.mozilla.org/en-US/docs/Using_files_from_web_applications
    function sendFileToImport(files) {
        if (!files.length) {
            // shouldn't happen
            toastr.info(importMessageNoFileSelected);
            return;
            // on windows the uploaded file got no type!
            //} else if (!files[0].type.match('application/x-mps')) {
        } else if (files[0].name.indexOf(".mps") === -1) {
            // todo: style the alert
            toastr.info(importMessageJustMPS);
        } else {
            // send file as file to server, import controller
            var xhr = window.XMLHttpRequest ? new XMLHttpRequest()
                : new ActiveXObject('Microsoft.XMLHTTP');
            xhr.open("POST", "import");

            xhr.onreadystatechange = function () {

                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {

                        showImportedDataInTable(xhr.responseText);

                    } else {

                        // now called in the /js/spinner/ajaxSpinner.js
                        // toastr.info("Error " + xhr.status);
                    }
                }
            }
            ;

            xhr.setRequestHeader('Content-Type', 'application/x-mps');
            xhr.send(files[0]);
        }
    }

    function showImportedDataInTable(responseData) {
        var task = JSON.parse(responseData);
        var objectiveVariables = task.objective.variables;
        var constraints = task.constraints;
        // amount of columns
        var cols = constraints[0].variables.length;
        // amount of columns (without objective)
        var rows = constraints.length;
        // resize the html table
        correctVariables(cols);
        correctConstraints(rows);
        // set the values from the task object to the html table
        importDataToTable(task);
    }

    /**
     * manipulates the html table, so the data can be imported
     *
     * @param newValue
     */
    function correctVariables(newValue) {
        var diffVariables = newValue - numbOfVariables;

        if (diffVariables > 0) {
            for (var i = 0; i < diffVariables; i++) {
                numbOfVariables++;
                TableManipulator.addVariable();
            }
        } else if (diffVariables < 0) {
            for (var j = diffVariables; j < 0; j++) {
                if (numbOfVariables < 2) {
                    break;
                }
                numbOfVariables--;
                TableManipulator.removeVariable();
            }
        }

        document.getElementById("numbOfVariables").value = numbOfVariables;

    }

    /**
     * manipulates the html table, so the data can be imported
     *
     * @param newValue
     */
    function correctConstraints(newValue) {
        var diffVariables = newValue - numbOfConstraints;

        if (diffVariables > 0) {
            for (var i = 0; i < diffVariables; i++) {
                numbOfConstraints++;
                TableManipulator.addConstraint(numbOfConstraints);
            }
        } else if (diffVariables < 0) {
            for (var j = diffVariables; j !== 0; j++) {
                if (numbOfConstraints < 1) {
                    break;
                }
                numbOfConstraints--;
                TableManipulator.removeConstraint();
            }
        }

        document.getElementById("numbOfConstraints").value = numbOfConstraints;

    }

    /**
     *
     * @param task JSON-Object with the received task
     */
    function importDataToTable(task) {

        var rows = tableau.rows;

        // row[0] is the header

        // row[1] is the objective
        var objectiveVariables = task.objective.variables;
        for (var i = 0; i < objectiveVariables.length; i++) {
            rows[1].childNodes[i + 1].firstElementChild.value = objectiveVariables[i].coefficient;
        }

        // min max selector
        rows[1].childNodes[i + 2].firstElementChild.value = task.objective.type;

        // row >= 2 are the constraints
        var amountOfConstraints = task.constraints.length;
        // fill the value in the constraints
        for (var j = 0; j < amountOfConstraints; j++) {
            var constrainObj = task.constraints[j];
            var amountOfVariables = constrainObj.variables.length;
            for (var k = 0; k < amountOfVariables; k++) {
                // node k=0 is the row header
                rows[j + 2].childNodes[k + 1].firstElementChild.value = constrainObj.variables[k].coefficient;
            }

            // node k+1 = type of constraint
            rows[j + 2].childNodes[k + 1].firstElementChild.value = constrainObj.type;
            rows[j + 2].childNodes[k + 2].firstElementChild.value = constrainObj.rhs;
        }

        // todo: set bounds to table
        if (task.bounds.length > 0) {
            importBoundsToTable(task.bounds);
        }
    }

    function importBoundsToTable(boundsData) {

        // the boundsData in the object are sorted by number

        for (var j = 0; j < boundsData.length; j++) {
            var boundRowCells = bounds.rows[j + 1].cells;

            if (boundsData[j].lowerBound != thisValueEqualsNoBoundIsSet) {
                boundRowCells.item(1).firstElementChild.value = boundsData[j].lowerBound;
            }
            if (boundsData[j].upperBound != thisValueEqualsNoBoundIsSet) {
                boundRowCells.item(2).firstElementChild.value = boundsData[j].upperBound;
            }
            if (boundsData[j].integer) {
                boundRowCells.item(3).firstElementChild.checked = true;
            }
        }
    }

    function normalizeResult() {
        var k = 0;
        for (var i = 0; i < amountOfVariables; i++) {
            if (k < result.variables.length) {
                var variable = result.variables[k];
                var nameInt = parseInt(variable.name.slice(1));
                if (nameInt == (i + 1)) {
                    resultVariables.push(variable.value);
                    k++;
                } else {
                    resultVariables.push(0);
                }
            } else {
                resultVariables.push(0);
            }
        }
        var result = JSON.parse(resultObj);
        var resultVariables = [];
    }

    return {
        showResponse: showResponse,
        exportMPS: exportMPS,
        sendFileToImport: sendFileToImport,
        correctVariables: correctVariables,
        correctConstraints: correctConstraints
    };

})();

