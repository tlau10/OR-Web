/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

// ###############################################################
// #
// #	REVISED SIMPLEX WEB ITERATOR (PURE JAVASCRIPT)
// #
// #	Michael Bernhardt, 24.06.2017
// #
// #
// ###############################################################


var Iterator = (function () {

  /**
   * iterate over the matrix while it is not optimum
   * @returns
   */
  function optimize() {
    while(!iterate());
  }

    /**
     * one iteration with the revised simplex algorithm
     * @returns true if there is a optimal or no solution
     * @returns false if the iteration is done and no solution found
     * */

  function iterate() {
      checkIfMatrixIsValid();
      //get all Values from the both matrices into the arrays
      getValuesFromTableToMatrix();
      getValuesFromUnitTableToUnitMatrix();
      //get the b Column and the Objective Function
      getBColumn();
      getObjectiveFunction();
      //take the unitMatrix and make the inverse of it
      inverseMatrix = math.inv(unitMatrix);

      getMatrixWithoutb();

      //get objective Function of inverseMatrix
      var tmpObjFun = getObjectiveFunctionOfInverseMatrix();
      //multiply the objective function of the inverse Matrix
      var tmpArray = math.multiply(math.fraction(tmpObjFun),math.fraction(matrixWithoutb));
      var pivotColumnIndex = 0;
      var afterMult = Number.MAX_VALUE;
      for(var i = 0; i < tmpArray.length; i++) {
          if(afterMult >= tmpArray[i]) {
              afterMult = tmpArray[i];
              pivotColumnIndex = i;
          }
      }
      if(tmpArray[pivotColumnIndex] >= 0) {
          showAlertMessage(msgOptimalSolutionFound);
          var sol = math.multiply(inverseMatrix, math.fraction(bColumn));
          TableManipulator.createSolutionMatrix();
          writeToSolutionTable(sol);
          return true;
      }
      //get the new matrix with pivotcolumn and b column
      var pivotColumn = getColumnValueFromMatrix(matrixTable, pivotColumnIndex + 1);
      var ab = [];
      for(var i = 0; i < numbOfConstraints+1; i++) {
          ab.push( [ math.fraction(pivotColumn[i]), math.fraction(bColumn[i]) ] );
      }
      //multiply this ab matrix with the inverse matrix
      ab = math.multiply(inverseMatrix, math.fraction(ab));
      //get smallest value of the multiplication
      var noOptimalSolution = true;
      var pivotRowIndex = 0;

      var smallestVal = Number.MAX_VALUE;
      var smallestIndex = -1;

        for(var i = 0; i < ab.length; i++) {
            if(ab[i][0].compare(math.fraction(0)) !== 1) {
                continue;
            }
            if(ab[i][1].div(ab[i][0]).compare(smallestVal) < 1 ) {
                smallestIndex = i;
                smallestVal = ab[i][1].div(ab[i][0]);
            }
        }

      if(smallestIndex === -1) {
          showAlertMessage(msgNoOptimalSolution);
          return true;
      }

      var tmpA = getColumnValueFromMatrix(matrixTable,pivotColumnIndex + 1);
      var tmpB = getColumnValueFromMatrix(unitMatrixTable, smallestIndex);
      replaceColumn(matrix, tmpB, pivotColumnIndex);
      replaceColumn(unitMatrix, tmpA, smallestIndex);
      writeToTable(matrix, matrixTable);
      writeToUnitTable(unitMatrix, unitMatrixTable);
      matrixTable.rows[pivotRowIndex + 1].childNodes[pivotColumnIndex + 1].firstElementChild.style.backgroundColor = "";
      matrixTable.rows[pivotRowIndex + 1].childNodes[pivotColumnIndex + 1].firstElementChild.style.color = "";
      return false;
  }

  /**
   * get the column with index from any Matrix
   * @param anyMatrix : array , holds the matrix that contains the wanted column
   * @param index : number , is the index of the given matrix column
   * @returns an Array with the specified column
   * */
  function getColumnValueFromMatrix(anyMatrix, index) {
      var rows = anyMatrix.rows;
      var tmpArray = [];
      for(var i = 1; i < rows.length; i++) {
          var item = rows[i];
          var bCells = item.cells;
          var valueOfCell = bCells.item(index).firstElementChild.value;
          tmpArray.push(valueOfCell);
      }
    return tmpArray;
  }

  /**
   * replaces one given column at specified index in matrix
   * @param any
   * @param anyMatrix : array , holds the matrix we want to change
   * @param column : array , holds the new column
   * @param index : number , is the index where we want to change the column
   * @returns the given matrix with the new column
   * */
  function replaceColumn(anyMatrix, column, index) {
      var tmpMatrix = anyMatrix;
      for(var i = 0; i < anyMatrix.length; i++) {
          tmpMatrix[i][index] = column[i];
      }
      return tmpMatrix;
  }
  /**
   * writing the solution into its column
   * @param solution : array , holds the solution as an Array
   * @returns
   * */
    function writeToSolutionTable(solution) {
        var rows = solutionMatrixTable.rows;
        for(var i = 1; i < rows.length; i++) {
            rows[i].childNodes[0].firstElementChild.value = math.format(solution[i-1]);
        }
    }

  return {
    optimize: optimize,
    iterate: iterate,
    getColumnValueFromMatrix : getColumnValueFromMatrix
    };
})();
