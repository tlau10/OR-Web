/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps;

import de.htwg.orweb.common.result.Result;
import de.htwg.orweb.common.task.Task;

public abstract class ITaskProcessor {
	
	/**
	 * 
	 */
	protected Result result;
	
	/**
	 * @param task
	 */
	public abstract void processTask(Task task);

	/**
	 * @return
	 */
	public Result getResult(){
		return result;
	}
}
