/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps.builder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.htwg.orweb.common.result.Result;
import de.htwg.orweb.common.shared.Model;
import de.htwg.orweb.common.task.Bound;
import de.htwg.orweb.common.task.Constraint;
import de.htwg.orweb.common.task.Meta;
import de.htwg.orweb.common.task.Objective;
import de.htwg.orweb.common.task.Task;
import de.htwg.orweb.common.task.Variable;
import de.htwg.orweb.lps.common.TaskFactory.ObjectiveSense;

public class ConvertMpsResultBuilder {

	/**
	 * 
	 */
	private static final Pattern ROW_PATTERN = Pattern.compile("\\s+(\\w)\\s+(\\w+)(\\s+)?");
	/**
	 * 
	 */
	private static final Pattern REST_PATTERN = Pattern.compile("\\s+(\\w+)\\s+(\\w+)\\s+(-?\\d+\\.\\d+)(\\s+)?");
	/**
	 * 
	 */
	private static final Pattern BOUND_PATTERN = Pattern
			.compile("\\s+(\\w+)\\s+(\\w+)\\s+(\\w+)\\s+(-?\\d+(\\.\\d+)?)\\s+");
	/**
	 * 
	 */
	private String mps;
	/**
	 * 
	 */
	private ObjectiveSense sense;

	/**
	 * 
	 */
	private Map<String, Constraint> constraintMap;
	/**
	 * 
	 */
	private Objective objective;

	/**
	 * 
	 */
	private Map<String, Bound> bounds;

	/**
	 * 
	 */
	public ConvertMpsResultBuilder(Task t) {
		this.mps = t.getModel().getMpsModel();
		this.sense = ObjectiveSense.MIN;
		if (t.getObjective().getType().equals("max")) {
			this.sense = ObjectiveSense.MAX;
		}
		constraintMap = new HashMap<String, Constraint>();
		objective = new Objective();
		bounds = new HashMap<>();
	}

	/**
	 * @return
	 */
	public Result createResultTask() {
		String[] lines = mps.split("\r\n");
		if (lines.length == 1) {
			lines = mps.split("\n");
		}
		System.out.println(this.getClass().toString() + "> DEBUG: Input size: " + lines.length);
		for (int i = 0; i < lines.length; i++) {
			System.out.println(this.getClass().toString() + "> DEBUG: Input line: " + lines[i]);
			if (lines[i].contains("ROWS")) {
				System.out.println(this.getClass().toString() + "> DEBUG: Line matches ROWS: " + lines[i]);
				i = processRows(lines, i + 1);
			} else if (lines[i].contains("COLUMNS")) {
				System.out.println(this.getClass().toString() + "> DEBUG: Line matches COLUMNS: " + lines[i]);
				i = processColumns(lines, i + 1);
			} else if (lines[i].contains("RHS")) {
				System.out.println(this.getClass().toString() + "> DEBUG: Line matches RHS: " + lines[i]);
				i = processRhs(lines, i + 1);
			} else if (lines[i].contains("BOUNDS")) {
				System.out.println(this.getClass().toString() + "> DEBUG: Line matches BOUNDS: " + lines[i]);
				i = processBounds(lines, i + 1);
			}
		}
		return buildResult();
	}

	/**
	 * @return
	 */
	private Result buildResult() {
		Task task = new Task();
		task.setMeta(new Meta());
		Model model = new Model();
		model.setMpsModel(mps);
		task.setModel(model);
		task.setObjective(objective);
		List<Constraint> cons = new ArrayList<Constraint>();
		for (Entry<String, Constraint> e : constraintMap.entrySet()) {
			cons.add(e.getValue());
		}
		List<Bound> boundList = new ArrayList<>();
		for (Entry<String, Bound> e : bounds.entrySet()) {
			boundList.add(e.getValue());
		}
		task.setBounds(boundList);
		task.setConstraints(cons);
		Result res = new Result();
		res.setModel(model);
		res.setObjective(new de.htwg.orweb.common.result.ObjectiveResult());
		res.setVariables(new ArrayList<de.htwg.orweb.common.result.VariableResult>());
		res.setTask(task);
		return res;
	}

	/**
	 * @param lines
	 * @param start
	 * @return
	 */
	private int processMarkers(String[] lines, int start) {
		Matcher m;
		for (int i = start; i < lines.length; i++) {
			if (lines[i].contains("MARK0001")) {
				return i - 1;
			}
			m = REST_PATTERN.matcher(lines[i]);
			if (m.matches()) {
				System.out.println(this.getClass().toString() + "> DEBUG: Pattern "
						+ "\\s+(\\w+)\\s+(\\w+)\\s+(\\d+\\.\\d+)(\\s+)?" + " matches line: " + lines[i]);
				if (m.group(2).trim().equals("OBJ")) {
					System.out.println(
							this.getClass().toString() + "> DEBUG: Objective variable found at line: " + lines[i]);
					Variable var = new Variable();
					var.setName(m.group(1).trim());
					var.setCoefficient(Double.parseDouble(m.group(3).trim()));
					if (!isVariableExisting(var, objective)) {
						objective.getVariables().add(var);
					}
					
				} else {
					Constraint con = constraintMap.get(m.group(2).trim());
					Variable var = new Variable();
					var.setName(m.group(1).trim());
					var.setCoefficient(Double.parseDouble(m.group(3).trim()));
					if (!isVariableExisting(var, con)) {
						con.getVariables().add(var);
					}
				}
				if (bounds.get(m.group(1).trim()) == null) {
					Bound bound = new Bound();
					bound.setInteger(true);
					bound.setLowerBound(0);
					bound.setUpperBound(1.0000000E20);
					bound.setVariableName(m.group(1).trim());
					bounds.put(m.group(1).trim(), bound);
				}
			}
		}
		return 0;
	}

	/**
	 * @param lines
	 * @param start
	 * @return
	 */
	private int processRhs(String[] lines, int start) {
		Matcher m;
		for (int i = start; i < lines.length; i++) {
			if (lines[i].contains("BOUNDS")) {
				return i - 1;
			} else if (lines[i].contains("ENDATA")) {
				return i - 1;
			}
			m = REST_PATTERN.matcher(lines[i]);
			if (m.matches()) {
				System.out.println(this.getClass().toString() + "> DEBUG: Pattern "
						+ "\\s+(\\w+)\\s+(\\w+)\\s+(\\d+\\.\\d+)(\\s+)?" + " matches line: " + lines[i]);
				Constraint con = constraintMap.get(m.group(2).trim());
				con.setName(m.group(2).trim());
				con.setRhs(Double.parseDouble(m.group(3).trim()));
				
			}
		}
		return 0;
	}

	/**
	 * @param lines
	 * @param start
	 * @return
	 */
	private int processColumns(String[] lines, int start) {
		Matcher m;
		for (int i = start; i < lines.length; i++) {
			if (lines[i].contains("MARK0000")) {
				i = processMarkers(lines, i + 1);
			}
			if (lines[i].contains("RHS")) {
				return i - 1;
			}
			m = REST_PATTERN.matcher(lines[i]);
			if (m.matches()) {
				System.out.println(this.getClass().toString() + "> DEBUG: Pattern "
						+ "\\s+(\\w+)\\s+(\\w+)\\s+(\\d+\\.\\d+)(\\s+)?" + " matches line: " + lines[i]);
				if (m.group(2).trim().equals("OBJ")) {
					System.out.println(
							this.getClass().toString() + "> DEBUG: Objective variable found at line: " + lines[i]);
					Variable var = new Variable();
					var.setName(m.group(1).trim());
					var.setCoefficient(Double.parseDouble(m.group(3).trim()));
					if (!isVariableExisting(var,objective)) {
						objective.getVariables().add(var);
					}
				} else {
					Constraint con = constraintMap.get(m.group(2).trim());
					Variable var = new Variable();
					var.setName(m.group(1).trim());
					var.setCoefficient(Double.parseDouble(m.group(3).trim()));
					if (!isVariableExisting(var, con)) {
						con.getVariables().add(var);
					}
				}
			}
		}
		return 0;
	}
	
	private boolean isVariableExisting(Variable variable, Constraint cons){
		List<Variable> list = cons.getVariables();
		for (Variable var : list) {
			if (var.getName().equals(variable.getName())) {
				return true;
			}
		}
		return false;
	}
	
	private boolean isVariableExisting(Variable variable, Objective obj){
		List<Variable> list = obj.getVariables();
		for (Variable var : list) {
			if (var.getName().equals(variable.getName())) {
				return true;
			}
		}
		return false;
	}

	private int processBounds(String[] lines, int start) {
		Matcher m;
		for (int i = start; i < lines.length; i++) {
			if (lines[i].contains("ENDATA")) {
				return i - 1;
			}
			m = BOUND_PATTERN.matcher(lines[i]);
			if (m.matches()) {
				System.out.println(this.getClass().toString() + "> DEBUG: Pattern "
						+ "\\s+(\\w+)\\s+(\\w+)\\s+(\\w+)\\s+(\\d+(\\.\\d+)?)\\s+" + " matches line: " + lines[i]);
				if (bounds.get(m.group(3).trim()) == null) {
					Bound bound = new Bound();
					bound.setVariableName(m.group(3).trim());
					bounds.put(m.group(3).trim(), bound);
				}
				Bound bound = bounds.get(m.group(3).trim());
				String identifier = m.group(1).trim();
				if (identifier.equals("LO")) {
					bound.setLowerBound(Double.parseDouble(m.group(4)));
				} else if (identifier.equals("UP")) {
					bound.setUpperBound(Double.parseDouble(m.group(4)));
				} else if (identifier.equals("PL")) {
					bound.setLowerBound(0);
					bound.setUpperBound(1.0000000E20);
				}
			}
		}
		return 0;
	}

	/**
	 * @param lines
	 * @param start
	 * @return
	 */
	private int processRows(String[] lines, int start) {
		Matcher m;
		for (int i = start; i < lines.length; i++) {
			if (lines[i].contains("COLUMNS")) {
				return i - 1;
			}
			m = ROW_PATTERN.matcher(lines[i]);
			if (m.matches()) {
				System.out.println(this.getClass().toString() + "> DEBUG: Pattern " + "\\s+(\\w)\\s+(\\w+)(\\s+)?"
						+ " matches line: " + lines[i]);
				if (m.group(2).trim().equals("OBJ")) {
					System.out.println(this.getClass().toString() + "> DEBUG: Objective found at line: " + lines[i]);
					objective.setType(sense.toString().toLowerCase());
					objective.setVariables(new ArrayList<Variable>());
				} else {
					Constraint con = new Constraint();
					con.setVariables(new ArrayList<Variable>());
					con.setType(m.group(1).trim());
					constraintMap.put(m.group(2).trim(), con);
				}
			}
		}
		return 0;
	}

}
