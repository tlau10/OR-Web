/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps.builder;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.htwg.orweb.common.result.ObjectiveResult;
import de.htwg.orweb.common.result.Result;
import de.htwg.orweb.common.result.VariableResult;

public class DynamicResultBuilder implements IResultBuilder {

	private static final Pattern VAR_SOLUTION = Pattern
			.compile("(.+)_var;(.+);(.+)");
	private static final Pattern OBJ_VAL = Pattern.compile("obj;(.+);-");
	private static final Pattern OBJ_FEAS_VAL = Pattern.compile("feas;(.+);-");

	private String[] rawData;

	public DynamicResultBuilder(String[] result) {
		rawData = result;
	}

	public Result build(long processingTime) {
		Result res = new Result();
		List<VariableResult> variables = new ArrayList<>();
		Matcher m;
		for (int i = 0; i < rawData.length; i++) {
			m = VAR_SOLUTION.matcher(rawData[i]);
			if (m.matches()) {
				variables.add(new VariableResult(m.group(1), Double.parseDouble(m
						.group(2)), Double.parseDouble(m.group(3))));
				continue;
			}
			m = OBJ_FEAS_VAL.matcher(rawData[i]);
			if (m.matches()) {
				int val = Integer.parseInt(m.group(1));
				res.setFeasible((val != 1));
				continue;
			}
			m = OBJ_VAL.matcher(rawData[i]);
			if (m.matches()) {
				double val = Double.parseDouble(m.group(1));
				res.setObjective(new ObjectiveResult(val));
				continue;
			}
		}
		res.setProcessingTime(processingTime);
		res.setVariables(variables);
		return res;
	}
}
