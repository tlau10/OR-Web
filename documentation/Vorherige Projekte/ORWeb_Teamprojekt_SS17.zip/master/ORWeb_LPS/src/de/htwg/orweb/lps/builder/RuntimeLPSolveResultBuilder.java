/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps.builder;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.htwg.orweb.common.result.ObjectiveResult;
import de.htwg.orweb.common.result.Result;
import de.htwg.orweb.common.result.VariableResult;

public class RuntimeLPSolveResultBuilder implements IResultBuilder {
	
    private static final Pattern OBJ_VAL= Pattern.compile("Value of objective function:\\s(.+)");
    private static final Pattern OBJ_INF_VAL= Pattern.compile("This problem is infeasible(.+)");
    //private static final Pattern VAR_VAL =  Pattern.compile("\\s+(\\d+)\\s(\\w+)\\s+(\\d+)\\s+(\\d+)");
    private static final Pattern VAR_VAL = Pattern.compile("(\\w+)\\s+(\\d+(\\.\\d+)?)");
	
	private String buffer;
	/**
	 * 
	 */
	public RuntimeLPSolveResultBuilder(String buffer) {
		this.buffer = buffer;
	}
	
	/* (non-Javadoc)
	 * @see com.htwg.orweb.lps.builder.IResultBuilder#build()
	 */
	@Override
	public Result build(long processingTime) {
		Result res = new Result();
		String[] lines = buffer.split("\r\n");
		ArrayList<VariableResult> varList = new ArrayList<VariableResult>();
		Matcher m;
		for (int i = 0; i < lines.length; i++) {
			System.out.println(lines[i]);
			 m = OBJ_INF_VAL.matcher(lines[i]);
			if (m.matches()) {
				double d = Double.parseDouble(m.group(1));
				res.setObjective(new ObjectiveResult(d));
				res.setFeasible(false);
				continue;
			}
			 m = OBJ_VAL.matcher(lines[i]);
			if (m.matches()) {
				System.out.println("OBJ_MATCH for " + lines[i]);
				double d = Double.parseDouble(m.group(1));
				res.setObjective(new ObjectiveResult(d));
				res.setFeasible(true);
				continue;
			}
			m = VAR_VAL.matcher(lines[i]);
			if (m.matches()) {
				System.out.println("VAR_MATCH for " + lines[i]);
				varList.add(new VariableResult(m.group(1), Double.parseDouble(m.group(2)),0));
				continue;
			}
		}
		res.setProcessingTime(processingTime);
		res.setVariables(varList);
		return res;
	}
}
