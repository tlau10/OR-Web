/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps.common;

public enum SupportedEnv {
	
	WIN_ENV("win", ".exe"), LINUX_ENV("linux", "");
	
	private String env;
	private String natExtension;
	
	/**
	 * 
	 */
	private SupportedEnv(String env, String natExtension) {
		this.env = env;
		this.natExtension = natExtension;
	}

	public String getEnv() {
		return env;
	}
	
	public String getNativeExtension(){
		return natExtension;
	}
	
	

}
