/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */
package de.htwg.orweb.lps.common;

import de.htwg.orweb.common.shared.Model;
import de.htwg.orweb.common.task.Meta;
import de.htwg.orweb.common.task.Objective;
import de.htwg.orweb.common.task.Task;

public class TaskFactory {
	
	private static final String CBC_SOLVER = "cbc";
	
	public enum ObjectiveSense{
		MIN,MAX;
	}
	
	/**
	 * 
	 */
	private TaskFactory() {
	
	}
	
	public static Task createConvertTask(String model){
		Task task = new Task();
		Meta meta = new Meta();
		meta.setConvert(true);
		meta.setSolveFromModel(false);
		meta.setSolver(CBC_SOLVER);
		task.setMeta(meta);
		Objective obj = new Objective();
		obj.setType(ObjectiveSense.MIN.toString().toLowerCase());
		task.setObjective(obj);
		Model m = new Model();
		m.setMpsModel(model);
		task.setModel(m);
		return task;
	}
	
	public static Task createSolveFromModelTask(String model, ObjectiveSense objSense){
		
		Task task = new Task();
		Meta meta = new Meta();
		meta.setConvert(false);
		meta.setSolveFromModel(true);
		meta.setSolver(CBC_SOLVER);
		task.setMeta(meta);
		Objective obj = new Objective();
		obj.setType(objSense.toString().toLowerCase());
		task.setObjective(obj);
		Model m = new Model();
		m.setMpsModel(model);
		task.setModel(m);
		return task;
	}
	
	public static Task createTransform(String model, ObjectiveSense objSense){
		Task task = new Task();
		Meta meta = new Meta();
		meta.setConvert(false);
		meta.setSolveFromModel(false);
		meta.setTransform(true);
		meta.setSolver(CBC_SOLVER);
		task.setMeta(meta);
		Objective obj = new Objective();
		obj.setType(objSense.toString().toLowerCase());
		task.setObjective(obj);
		Model m = new Model();
		m.setMpsModel(model);
		task.setModel(m);
		return task;
	}

}
