/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps.common;
public class Validator {
	
	public static String encrypt(String in, int base) throws Exception {	
		return new java.math.BigInteger(in).toString(base);
	}
	public static String decrypt(String in, int base) throws Exception {	
		return new java.math.BigInteger(in,base).toString();
	}
	
	public static boolean isValidKey(String s, int base) throws NumberFormatException, Exception{
		long ts = System.currentTimeMillis() / 1000L;
		if (ts > Long.parseLong(decrypt(s, base))) {
			return false;
		}
		return true;
	}

}
