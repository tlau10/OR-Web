/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps.debug;

import java.io.File;

import de.htwg.orweb.common.task.Task;
import de.htwg.orweb.lps.AbstractTaskProcessor;
import de.htwg.orweb.lps.common.Configurator;

public class DebugProcessor extends AbstractTaskProcessor{
	
	
	/**
	 * @param conf
	 */
	public DebugProcessor(Configurator conf) {
		super(conf);
		File targetOutput= new File(conf.getDebugOutDir());
		if (!targetOutput.exists()) {
			targetOutput.mkdir();
			System.out.println(this.getClass() + "> DEBUG:: Created directory " + targetOutput.getAbsolutePath());
		}
	}

	/* (non-Javadoc)
	 * @see de.htwg.orweb.lps.ITaskProcessor#processTask(de.htwg.orweb.common.transfer.Task)
	 */
	@Override
	public void processTask(Task task) {
		TaskProcessor processor = new TaskProcessor(task);
		processor.start();
	}
}
