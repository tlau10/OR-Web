/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps.debug;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;

import javax.xml.bind.JAXBException;

import de.htwg.orweb.common.task.Task;
import de.htwg.orweb.common.xml.JAXBUtil;
import de.htwg.orweb.lps.AbstractDataSource;
import de.htwg.orweb.lps.ITaskProcessor;

public class FileSystemDataSource extends AbstractDataSource {

	
	private static final String INCLUDE_FORMAT = ".xml";

	private File observePath;
	private WatchService watcher;

	
	/**
	 * @param processor
	 */
	public FileSystemDataSource(String path, ITaskProcessor processor) {
		super(processor); 
		File targetInput = new File(path);
		if (!targetInput.exists()) {
			targetInput.mkdir();
			System.out.println(this.getClass() + "> DEBUG:: Created directory " + targetInput.getAbsolutePath());
		}
		this.observePath = new File(path);
		try {
			watcher = FileSystems.getDefault().newWatchService();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	public void run() {
		System.out.println(this.getClass() + "> DEBUG:: Started listening to " + observePath + "...");
		Path dir = observePath.toPath();
		try {
			dir.register(watcher, StandardWatchEventKinds.ENTRY_CREATE);
		} catch (IOException x) {
			System.err.println(x);
		}
		while (true) {
			WatchKey key;
			try {
				key = watcher.take();
				for (WatchEvent<?> event : key.pollEvents()) {
					File processingFile = dir.resolve((Path) event.context())
							.toFile();
					if (processingFile.getName().toLowerCase()
							.endsWith(INCLUDE_FORMAT)) {
						long init = System.currentTimeMillis();
						System.out.println(this.getClass() + "> DEBUG:: Received file " + processingFile.getName());
						System.out.println(this.getClass() + "> DEBUG:: Printing xml content:");
						Task task = JAXBUtil.toObject(processingFile);
						JAXBUtil.toConsole(task);
						this.processor.processTask(task);
						System.out.println(this.getClass() + "> DEBUG:: Processing file " +processingFile.getName() + " took " + (System.currentTimeMillis() - init) + "ms");
					}
					processingFile.delete();
				}
			} catch (InterruptedException | JAXBException x) {
				return;
			}
			key.reset();
		}

	}

	/* (non-Javadoc)
	 * @see de.htwg.orweb.lps.AbstractDataSource#retrive()
	 */
	@Override
	public void startRetrival() {
		if (retrivalThread == null) {
			this.retrivalThread = new Thread(this);
			this.retrivalThread.start();
		}
	}
	
	/* (non-Javadoc)
	 * @see de.htwg.orweb.lps.AbstractDataSource#retrive()
	 */
	@Override
	public void stopRetrival() {
		if (retrivalThread.isAlive()) {
			try {
				retrivalThread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
