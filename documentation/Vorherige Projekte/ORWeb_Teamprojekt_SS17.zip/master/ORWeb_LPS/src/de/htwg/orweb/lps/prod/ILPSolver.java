/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */
package de.htwg.orweb.lps.prod;

import de.htwg.orweb.common.result.Result;
import de.htwg.orweb.common.task.Task;

public interface ILPSolver {

	/**
	 * @param task
	 * @return
	 */
	public abstract Result solve(Task task);
	
}
