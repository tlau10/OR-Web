/*
 * Copyright (c) 2017
 * Authors: Bastian Schoettle, Mirko Bay, Marco Kloft, Michael Bernhardt, Stephen Beck, Markus Jaeckle
 * All rights reserved.
 *
 */

package de.htwg.orweb.lps.solver;

import de.htwg.orweb.common.result.Result;
import de.htwg.orweb.common.task.Task;
import de.htwg.orweb.lps.common.Configurator;
import de.htwg.orweb.lps.common.SupportedArch;
import de.htwg.orweb.lps.common.SupportedEnv;

public class SolverWrapper implements ISolver {

	
	private enum SolverInstance{
		LP_SOLVE("lp_solve"), CBC("cbc"), SCIP("scip"), GLPK("glpk"), MIPCL("MIPCL");
		private String instance;
		/**
		 * 
		 */
		private SolverInstance(String instance) {
			this.instance = instance;
		}
		
		public String getInstance(){
			return instance;
		}
	}
	/**
	 * 
	 */
	private ISolver solver;

	/**
	 * @param task
	 * @return
	 */
	private SolverInstance getSolverInstance(Task task){
		String inst = task.getMeta().getSolver();
		if (inst.toLowerCase().equals(SolverInstance.LP_SOLVE.getInstance())) {
			return SolverInstance.LP_SOLVE;
		} else if (inst.toLowerCase().equals(SolverInstance.SCIP.getInstance())) {
			return SolverInstance.SCIP;
		} else if (inst.toLowerCase().equals(SolverInstance.GLPK.getInstance())) {
			return SolverInstance.GLPK;
		} else if (inst.toLowerCase().equals(SolverInstance.MIPCL.getInstance())) {
			return SolverInstance.MIPCL;
		}
		return SolverInstance.CBC;
	}
	
	/**
	 * 
	 */
	public SolverWrapper(Configurator config, Task task) {
		if (getSolverInstance(task) == SolverInstance.CBC) {
			System.out.println(this.getClass().toString() + "> DEBUG: Selected CBC solver for processing");
			if (config.isDynamicSolverEnabled()) {
				if (config.getTargetEnv() == SupportedEnv.WIN_ENV) {
					if (config.getArchitecture() == SupportedArch.X86_ARCH) {
						System.out.println(this.getClass() + "> DEBUG:: Selected shared library/dynamic link library for task processing");
						solver = new CBCSolverImpl(config);
					} else {
						System.out.println(this.getClass() + "> DEBUG:: Switched to runtime process instance because target env (x64) on windows is not supported");
						solver = new RuntimeCBCSolverImpl(config);
					}
				} else {
					System.out.println(this.getClass() + "> DEBUG:: Switched to runtime process instance because shared library on linux is not supported");
					solver = new RuntimeCBCSolverImpl(config);
				}
			} else {
				System.out.println(this.getClass() + "> DEBUG:: Selected runtime process instance for task processing");
				solver = new RuntimeCBCSolverImpl(config);
			}
		} else if(getSolverInstance(task) == SolverInstance.LP_SOLVE) {
			System.out.println(this.getClass().toString() + "> DEBUG: Selected lp_solve runtime process instance for processing ");
			solver = new RuntimeLPSolveImpl(config);
		} else if (getSolverInstance(task) == SolverInstance.SCIP) {
			System.out.println(this.getClass().toString() + "> DEBUG: Selected scip runtime process instance for processing ");
			solver = new RuntimeSCIPSolverImpl(config);
		} else if (getSolverInstance(task) == SolverInstance.GLPK) {
			System.out.println(this.getClass().toString() + "> DEBUG: Selected glpk runtime process instance for processing ");
			solver = new RuntimeGlpkSolverImpl(config);
		}else if (getSolverInstance(task) == SolverInstance.MIPCL) {
			System.out.println(this.getClass().toString() + "> DEBUG: Selected mipcl runtime process instance for processing ");
			solver = new RuntimeMIPCLSolverImpl(config);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.htwg.orweb.lps.solver.ISolver#solve(java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public Result solve(String mps, String sense) {
		return solver.solve(mps, sense);
	}

}
