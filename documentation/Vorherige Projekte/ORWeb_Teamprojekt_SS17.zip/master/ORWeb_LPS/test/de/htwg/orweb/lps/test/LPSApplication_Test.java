package de.htwg.orweb.lps.test;
import de.htwg.orweb.common.task.Task;
import de.htwg.orweb.lps.common.TaskFactory;
import de.htwg.orweb.lps.prod.ILPSolver;
import de.htwg.orweb.lps.prod.LPSProduction;

/**
 * @author schobast
 *
 */
public class LPSApplication_Test {

	private static final String MODEL = "ROWS\r\n L  R2\r\n N  OBJ\r\n L  R1\r\nCOLUMNS\r\n x1        OBJ       1.0      \r\n x1        R1        3.0      \r\n x1        R2        1.0      \r\n x2        OBJ       2.0      \r\n x2        R1        2.0      \r\n x2        R2        3.0      \r\nRHS\r\n RH1      R2        9.0      \r\n RH1      R1        12.0     \r\nENDATA";

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ILPSolver solver = new LPSProduction();
		Task t = TaskFactory.createTransform(MODEL, TaskFactory.ObjectiveSense.MAX);
		solver.solve(t);
	}

}
