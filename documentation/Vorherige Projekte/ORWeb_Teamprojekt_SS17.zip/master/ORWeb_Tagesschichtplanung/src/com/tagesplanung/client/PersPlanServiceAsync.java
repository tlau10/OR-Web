package com.tagesplanung.client;

import java.util.List;
import java.util.Map;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.tagesplanung.shared.Bedarf;
import com.tagesplanung.shared.Result;
import com.tagesplanung.shared.ResultBaseModel;
import com.tagesplanung.shared.ShiftBaseModel;

/**
 * The Interface PersPlanServiceAsync defines which methods are available and
 * can be called on the server. It is needed in addition to the PersPlanService
 * interface to provide asynchronous requests.
 */
public interface PersPlanServiceAsync {

	/**
	 * The solve method contains all the logic to solve the LP problem which was
	 * specified in the GUI and compute a result which can be displayed in the
	 * GUI again.
	 * 
	 * @param bList
	 *            the demand list
	 * @param sList
	 *            the shift list
	 * @return the result list
	 */
	public void solve(List<Bedarf> bList, List<ShiftBaseModel> sList, AsyncCallback<List<Result>> callback);

	/**
	 * The saveDemandData method create the wrapper class SaveLoadDemand and set
	 * the bedarf list as value. Then marshall the SaveLoadDemand object in a
	 * xml document.
	 * 
	 * @param bList
	 *            the demand list
	 * @param callback
	 *            the callback
	 */
	public void saveDemandData(List<Bedarf> bList, AsyncCallback<String> callback);

	/**
	 * The saveShiftData method create the wrapper class SaveLoadShift and set
	 * the ShiftBaseModel list as value. Then marshall the SaveLoadShift object
	 * in a xml document.
	 * 
	 * @param sList
	 *            the shift list
	 * @param callback
	 *            the callback
	 */
	public void saveShiftData(List<ShiftBaseModel> sList, AsyncCallback<String> callback);

	/**
	 * The loadDemandData method unmarshall the LoadFile.xml in a SaveLoadDemand
	 * object and delete afterwards the file.
	 * 
	 * @param callback
	 *            the callback
	 */
	public void loadDemandData(AsyncCallback<List<Bedarf>> callback);

	/**
	 * The loadShiftData method unmarshall the LoadFile.xml in a SaveLoadShift
	 * object and delete afterwards the file.
	 * 
	 * @param callback
	 *            the callback
	 */
	public void loadShiftData(AsyncCallback<List<ShiftBaseModel>> callback);

	/**
	 * The method deleteFile delete a file if it exists.
	 * 
	 * @param file
	 *            the file
	 * @param callback
	 *            the callback
	 */
	public void deleteFile(String file, AsyncCallback<String> callback);

	/**
	 * Gets the result base model.
	 * 
	 * @param result
	 *            the result
	 * @param callback
	 *            the callback
	 * @return the result base model
	 */
	public void getResultBaseModel(List<Result> result, AsyncCallback<List<ResultBaseModel>> callback);

	/**
	 * Gets the graphic visualization of the result.
	 * 
	 * @param result
	 *            the result
	 * @param bList
	 *            the b list
	 * @param callback
	 *            the callback
	 * @return the graphic visualization of the result
	 */
	public void getGraficVisualOfResult(List<Result> result, List<Bedarf> bList, AsyncCallback<int[][]> callback);

	/**
	 * Gets the URL of the HTML file with the LP model.
	 * 
	 * @param callback
	 *            the callback
	 * @return the URL of LP model file
	 */
	public void getLPURL(AsyncCallback<String> callback);

	// Begin of Change by fafilipp
	/**
	 * Gets the Properties for the Start and End allowness for Night Breaks
	 * 
	 * @param callback
	 *            the callback
	 */
	public void getNightBreakAllowness(AsyncCallback<Map<Integer, String>> callback);
	// End of Change

}
