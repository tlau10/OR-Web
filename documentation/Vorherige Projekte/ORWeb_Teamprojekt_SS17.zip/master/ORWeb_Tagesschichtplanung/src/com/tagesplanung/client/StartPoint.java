package com.tagesplanung.client;

import com.extjs.gxt.themes.client.Slate;
import com.extjs.gxt.ui.client.GXT;
import com.extjs.gxt.ui.client.mvc.Dispatcher;
import com.extjs.gxt.ui.client.util.ThemeManager;
import com.google.gwt.core.client.EntryPoint;
import com.tagesplanung.client.widgets.AppController;

// TODO: Auto-generated Javadoc
/**
 * The Class StartPoint.
 *
 * @author Steffen Kollosche
 * 
 * This class is the start point of the whole application
 */

public class StartPoint implements EntryPoint{
	
	/* (non-Javadoc)
	 * @see com.google.gwt.core.client.EntryPoint#onModuleLoad()
	 */
	@Override
	public void onModuleLoad() {
		ThemeManager.register(Slate.SLATE);
		GXT.setDefaultTheme(Slate.SLATE, true);
		Dispatcher dispatcher = Dispatcher.get();
	    dispatcher.addController(new AppController());
	    dispatcher.dispatch(AppEvents.Init);
	    GXT.hideLoadingPanel("loading");
	}
}