package com.tagesplanung.client.widgets;

import com.extjs.gxt.ui.client.event.EventType;
import com.extjs.gxt.ui.client.mvc.AppEvent;
import com.extjs.gxt.ui.client.mvc.Controller;
import com.tagesplanung.client.AppEvents;

// TODO: Auto-generated Javadoc
/**
 * The Class AppController.
 */
public class AppController extends Controller { 
	
	/** The app view. */
	private AppView appView;

	/**
	 * Instantiates a new app controller.
	 */
	public AppController() {
		registerEventTypes(AppEvents.Init);
	}
	
	/* (non-Javadoc)
	 * @see com.extjs.gxt.ui.client.mvc.Controller#initialize()
	 */
	public void initialize() {
		appView = new AppView(this);
	}
	
	/* (non-Javadoc)
	 * @see com.extjs.gxt.ui.client.mvc.Controller#handleEvent(com.extjs.gxt.ui.client.mvc.AppEvent)
	 */
	@Override
	public void handleEvent(AppEvent event) {
		EventType type = event.getType();
		if (type == AppEvents.Init) {
			onInit(event);
		}
	}
	
	/**
	 * On init.
	 *
	 * @param event the event
	 */
	private void onInit(AppEvent event) {
		forwardToView(appView, event);	
	}
}
