package com.tagesplanung.client.widgets;

import java.util.List;

import com.extjs.gxt.ui.client.Style.HorizontalAlignment;
import com.extjs.gxt.ui.client.event.ButtonEvent;
import com.extjs.gxt.ui.client.event.SelectionListener;
import com.extjs.gxt.ui.client.event.WindowEvent;
import com.extjs.gxt.ui.client.event.WindowListener;
import com.extjs.gxt.ui.client.widget.Label;
import com.extjs.gxt.ui.client.widget.Window;
import com.extjs.gxt.ui.client.widget.button.Button;
import com.extjs.gxt.ui.client.widget.form.FileUploadField;
import com.extjs.gxt.ui.client.widget.form.FormPanel;
import com.extjs.gxt.ui.client.widget.layout.FitData;
import com.extjs.gxt.ui.client.widget.layout.FitLayout;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.tagesplanung.client.PersPlanService;
import com.tagesplanung.client.PersPlanServiceAsync;
import com.tagesplanung.shared.Bedarf;
import com.tagesplanung.shared.ShiftBaseModel;
import com.tagesplanung.shared.resources.Resources;

// TODO: Auto-generated Javadoc
/**
 * The Class FileUploadView is a window which pops up as soon the user hits the
 * Open Demand or Open Shift in the menubar.
 */
public class FileUploadView extends Window {

	/**
	 * The constants. With this variable we can reach all constant strings in
	 * different languages.
	 */
	private PersPlanConstants constants;

	/** The panel contains all Control Elements and call the FileUploadServlet */
	private final FormPanel panel;

	/** The file open the FileUploadField dialog. */
	private FileUploadField file;

	/** The open. Call the Button Handler */
	private Label open;

	/** The submit. Call the Button Handler */
	private Button submit;

	/** The apply. Call the Button Handler */
	private Button apply;

	/** The close. Call the Button Handler */
	private Button close;

	/**
	 * The type is used for the heading of the window and panel also it affects
	 * the file extension
	 */
	private String type;

	/** The file path contains the String of the directory and the filename */
	private String filePath;

	/**
	 * The file extension is set by the type parameter of the constructor. If
	 * type is demandPlaning --> .dep If type is shiftPlaning --> .shp*
	 */
	private String fileExtension;

	/**
	 * The slv. The ShiftlistView method setShiftList is called to set values
	 * and repaint the chart diagram
	 */
	private ShiftlistView slv;

	/**
	 * Instantiates a new file upload view.
	 * 
	 * @param type
	 *            is used for the heading of the window and panel also it
	 *            affects the file extension.
	 * @param slv
	 *            the ShiftlistView method setShiftList is called to set values
	 *            and repaint the chart diagram
	 */
	public FileUploadView(final String type, ShiftlistView slv) {
		constants = (PersPlanConstants) GWT.create(PersPlanConstants.class);
		this.type = type;
		this.slv = slv;

		this.setSize(500, 200);
		this.setPlain(true);
		this.setModal(true);
		this.setBlinkModal(true);
		this.setHeading(type);
		this.setLayout(new FitLayout());
		this.setIcon(Resources.ICONS.info());

		panel = new FormPanel();
		panel.setHeading(type + " " + constants.open() + constants.dots());
		panel.setFrame(true);
		panel.setEncoding(FormPanel.Encoding.MULTIPART);
		panel.setMethod(FormPanel.Method.POST);
		panel.setButtonAlign(HorizontalAlignment.CENTER);

		file = new FileUploadField();
		file.setAllowBlank(false);
		file.setFieldLabel(constants.file());
		file.setStyleAttribute("margin-top", "20px");
		file.setName("myFile");

		open = new Label("<html>" + "<p>" + constants.pleaseChoose() + type
				+ constants.fileToOpen() + "</p>" + "</html>");
		open.setStyleAttribute("font-size", "14");

		ButtonHandler buttonHandler = new ButtonHandler();

		submit = new Button(constants.openUpperCase());
		submit.addSelectionListener(buttonHandler);

		apply = new Button(constants.apply());
		apply.disable();
		apply.addSelectionListener(buttonHandler);

		close = new Button(constants.close());
		close.addSelectionListener(buttonHandler);

		panel.add(open);
		panel.add(file);
		panel.addButton(submit);
		panel.addButton(apply);
		panel.addButton(close);
		this.add(panel, new FitData(4));

		this.addWindowListener(new WindowListener() {
			// the save file on the server will deleted before Window hide.
			@Override
			public void windowHide(WindowEvent we) {
				deleteFile(filePath);
			}
		});
		if (type.compareTo(constants.demandPlaning()) == 0) {
			fileExtension = ".dep";
		}
		if (type.compareTo(constants.shiftPlaning()) == 0) {
			fileExtension = ".shp";
		}
		deleteFile("");
	}

	/*
	 * (non-Javadoc) the save file on the server will deleted if the user close
	 * the browser or navigate to another site
	 */
	@Override
	protected void onUnload() {
		deleteFile(filePath);
	}

	/**
	 * Load demand data call the loadDemandData method on the server side. If
	 * the method of the server side is successful it set the values of the
	 * BedarfsplanView.
	 */
	public void loadDemandData() {
		PersPlanServiceAsync persPlanService = (PersPlanServiceAsync) GWT
				.create(PersPlanService.class);
		AsyncCallback<List<Bedarf>> callback = new AsyncCallback<List<Bedarf>>() {
			@Override
			public void onSuccess(List<Bedarf> result) {
				BedarfsplanView.setBedarfList(result);
				hide();
			}

			@Override
			public void onFailure(Throwable caught) {
				com.google.gwt.user.client.Window.alert(constants
						.errorOpeningFile());
				hide();
			}
		};
		persPlanService.loadDemandData(callback);
	}

	/**
	 * Load shift data call the loadShiftData method on the server side. If the
	 * method of the server side is successful it set the values of the
	 * ShiftListView.
	 */
	public void loadShiftData() {
		PersPlanServiceAsync persPlanService = (PersPlanServiceAsync) GWT
				.create(PersPlanService.class);
		AsyncCallback<List<ShiftBaseModel>> callback = new AsyncCallback<List<ShiftBaseModel>>() {
			@Override
			public void onSuccess(List<ShiftBaseModel> result) {
				slv.setShiftList(result);
				hide();
			}

			@Override
			public void onFailure(Throwable caught) {
				com.google.gwt.user.client.Window.alert(constants
						.errorOpeningFile());
				hide();
			}
		};
		persPlanService.loadShiftData(callback);
	}

	/**
	 * Delete file call the deleteFile method on the server side.
	 * 
	 * @param message
	 *            is not used.
	 */
	public void deleteFile(String message) {
		PersPlanServiceAsync persPlanService = (PersPlanServiceAsync) GWT
				.create(PersPlanService.class);
		AsyncCallback<String> callback = new AsyncCallback<String>() {
			@Override
			public void onSuccess(String result) {
				filePath = result;
			}

			@Override
			public void onFailure(Throwable caught) {
				com.google.gwt.user.client.Window.alert(caught.getMessage());
			}
		};
		persPlanService.deleteFile(message, callback);
	}

	/**
	 * Checks if the FileUploadField file value has the correct extension.
	 * 
	 * @return true, if is valid
	 */
	private boolean isValid() {
		String fileName = file.getValue();
		if (fileName.contains(fileExtension)) {
			return true;
		}
		return false;
	}

	/**
	 * The Class ButtonHandler is the SelectionListener for the buttons open,
	 * apply and close.
	 */
	private class ButtonHandler extends SelectionListener<ButtonEvent> {

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * com.extjs.gxt.ui.client.event.SelectionListener#componentSelected
		 * (com.extjs.gxt.ui.client.event.ComponentEvent)
		 */
		@Override
		public void componentSelected(ButtonEvent ce) {
			Button button = ce.getButton();
			if (button.getText().compareTo(constants.openUpperCase()) == 0) {
				// checks if the FileUploadField is empty
				if (!panel.isValid()) {
					deleteFile(filePath);
					return;
				} else {
					// checks the correct extension
					if (isValid()) {
						// the FileUploadServlet is called with the panel. the
						// filepath of the
						// load file is set as request parameter
						panel.setAction(GWT.getModuleBaseURL()
								+ "upload?filePath=" + filePath);
						panel.submit();
						apply.enable();
					} else {
						com.google.gwt.user.client.Window.alert(constants
								.errorWrongType() + " " + fileExtension);
						file.clear();
					}
				}
			}
			if (button.getText().compareTo(constants.apply()) == 0) {
				if (type.compareTo(constants.demandPlaning()) == 0) {
					loadDemandData();
				}
				if (type.compareTo(constants.shiftPlaning()) == 0) {
					loadShiftData();
				}
			}
			if (button.getText().compareTo(constants.close()) == 0) {
				hide();
			}
		}
	}
}