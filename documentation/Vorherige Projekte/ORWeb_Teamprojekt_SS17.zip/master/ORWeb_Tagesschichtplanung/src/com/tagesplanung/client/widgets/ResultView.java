package com.tagesplanung.client.widgets;

import java.util.ArrayList;
import java.util.List;

import com.extjs.gxt.charts.client.Chart;
import com.extjs.gxt.charts.client.model.ChartModel;
import com.extjs.gxt.charts.client.model.axis.Label;
import com.extjs.gxt.charts.client.model.axis.XAxis;
import com.extjs.gxt.charts.client.model.axis.YAxis;
import com.extjs.gxt.charts.client.model.charts.LineChart;
import com.extjs.gxt.charts.client.model.charts.StackedBarChart;
import com.extjs.gxt.ui.client.Style.ButtonScale;
import com.extjs.gxt.ui.client.Style.HorizontalAlignment;
import com.extjs.gxt.ui.client.Style.LayoutRegion;
import com.extjs.gxt.ui.client.event.ButtonEvent;
import com.extjs.gxt.ui.client.event.SelectionListener;
import com.extjs.gxt.ui.client.store.ListStore;
import com.extjs.gxt.ui.client.util.Margins;
import com.extjs.gxt.ui.client.widget.ContentPanel;
import com.extjs.gxt.ui.client.widget.LayoutContainer;
import com.extjs.gxt.ui.client.widget.button.Button;
import com.extjs.gxt.ui.client.widget.form.CheckBox;
import com.extjs.gxt.ui.client.widget.form.CheckBoxGroup;
import com.extjs.gxt.ui.client.widget.form.ComboBox.TriggerAction;
import com.extjs.gxt.ui.client.widget.form.FormPanel;
import com.extjs.gxt.ui.client.widget.form.SimpleComboBox;
import com.extjs.gxt.ui.client.widget.grid.ColumnConfig;
import com.extjs.gxt.ui.client.widget.grid.ColumnModel;
import com.extjs.gxt.ui.client.widget.grid.Grid;
import com.extjs.gxt.ui.client.widget.grid.HeaderGroupConfig;
import com.extjs.gxt.ui.client.widget.layout.BorderLayout;
import com.extjs.gxt.ui.client.widget.layout.BorderLayoutData;
import com.extjs.gxt.ui.client.widget.layout.FitLayout;
import com.extjs.gxt.ui.client.widget.layout.FormData;
import com.extjs.gxt.ui.client.widget.layout.RowData;
import com.extjs.gxt.ui.client.widget.layout.RowLayout;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.HTML;
import com.tagesplanung.client.PersPlanService;
import com.tagesplanung.client.PersPlanServiceAsync;
import com.tagesplanung.shared.Bedarf;
import com.tagesplanung.shared.Result;
import com.tagesplanung.shared.ResultBaseModel;
import com.tagesplanung.shared.ShiftBaseModel;
import com.tagesplanung.shared.TimeIntervall;
import com.tagesplanung.shared.resources.Resources;

// TODO: Auto-generated Javadoc
/**
 * The Class ResultView.
 */
public class ResultView {

	/** The rsc. */
	private ResultChart rsc = new ResultChart();

	/** The check1. */
	private CheckBox check1;

	/** The check2. */
	private CheckBox check2;

	/** The store. */
	final ListStore<ResultBaseModel> store = new ListStore<ResultBaseModel>();

	/** The shift colors. */
	// Begin of change jaglaubi and fafilipp
	private final String[] shiftColors = { "000080", "800080", "808000", "008000", "800000", "000000", "808080", "008080", "ff00ff",
			"0000ff", "00ff00", "ff00ff", "d3ab40", "9fc8f2", "f29ff1", "f5b2c9", "b20240", "9028d2", "99737f", "0000cd" };
	// End of Change

	// internationalization with .properties file
	/** The constants. */
	private PersPlanConstants constants = (PersPlanConstants) GWT.create(PersPlanConstants.class);

	// private List<HorizontalStackedBarChart.StackValue> data = null;
	// HorizontalStackedBarChart.StackValue[] dataArray = null;

	/**
	 * HTML Object for the Visualization of the Legend in top of the Chart.
	 */
	private HTML html;

	/**
	 * Gets the view.
	 * 
	 * @return the view
	 */
	public LayoutContainer getView() {
		LayoutContainer outerContainer = new LayoutContainer(new RowLayout());
		outerContainer.setSize(1000, 700);
		outerContainer.setStyleAttribute("background-color", "#FFFFFF");
		LayoutContainer innerContainer = new LayoutContainer(new BorderLayout());
		innerContainer.setStyleAttribute("background-color", "#FFFFFF");
		LayoutContainer innerContainerWest = new LayoutContainer(new RowLayout());
		LayoutContainer innerContainerEast = new LayoutContainer(new RowLayout());

		BorderLayoutData centerLayoutData = new BorderLayoutData(LayoutRegion.CENTER);
		centerLayoutData.setMargins(new Margins(0, 0, 0, 0));
		BorderLayoutData eastLayoutData = new BorderLayoutData(LayoutRegion.EAST);
		eastLayoutData.setMargins(new Margins(0, 0, 0, 0));

		outerContainer.add(innerContainer, new RowData(1, 1, new Margins(0, 0, 0, 0)));
		innerContainer.add(innerContainerWest, centerLayoutData);
		innerContainer.add(innerContainerEast, eastLayoutData);

		List<ColumnConfig> columns = new ArrayList<ColumnConfig>();

		columns.add(new ColumnConfig("shiftNumber", constants.shiftNumber(), 110));
		columns.add(new ColumnConfig("shiftStart", constants.from(), 110));
		columns.add(new ColumnConfig("shiftEnd", constants.to(), 110));
		columns.add(new ColumnConfig("numberOfPeople", constants.persons(), 125));

		columns.add(new ColumnConfig("breakIntervall", constants.interval(), 110));
		columns.add(new ColumnConfig("numberOfPeopleInBreak", constants.numberOfPersons(), 125));

		for (int i = 0; i < columns.size(); i++) {
			columns.get(i).setSortable(false);
			columns.get(i).setMenuDisabled(true);
		}

		ColumnModel cm = new ColumnModel(columns);

		cm.addHeaderGroup(0, 0, new HeaderGroupConfig(constants.shifts(), 1, 4));
		cm.addHeaderGroup(0, 4, new HeaderGroupConfig(constants.breaks(), 1, 2));

		Grid<ResultBaseModel> grid = new Grid<ResultBaseModel>(store, cm);

		ContentPanel cp = new ContentPanel(new FitLayout());
		cp.setHeading(constants.result());
		cp.setIcon(Resources.ICONS.table());
		cp.setFrame(true);
		cp.add(grid);

		RowData data;
		data = new RowData(1, 300, new Margins(10));

		innerContainerWest.add(cp, data);

		// Create FormPanel
		// FormPanel formPanel = new FormPanel();
		FormPanel formPanel = new FormPanel();
		formPanel.setHeading(constants.solve());
		formPanel.setIcon(Resources.ICONS.settings());
		formPanel.setCollapsible(true);
		formPanel.setAutoHeight(true);
		formPanel.setAutoWidth(true);
		formPanel.setFrame(true);
		formPanel.setButtonAlign(HorizontalAlignment.CENTER);

		final SimpleComboBox<String> combo = new SimpleComboBox<String>();
		combo.setFieldLabel(constants.solver());
		combo.add(constants.xa());
		combo.setSimpleValue(constants.xa());
		combo.setTriggerAction(TriggerAction.ALL);
		combo.setEditable(false);

		Button solve = new Button();
		solve.setText(constants.solve());
		solve.setScale(ButtonScale.SMALL);
		solve.setIcon(Resources.ICONS.solve());
		final Button lp = new Button();
		lp.setText(constants.lpModel());
		lp.setEnabled(false);
		lp.setScale(ButtonScale.SMALL);
		lp.setIcon(Resources.ICONS.table());

		// Begin of Change fafilipp and toehrlin
		final SimpleComboBox<String> lpCombo = new SimpleComboBox<String>();
		lpCombo.setFieldLabel(constants.exportAs());
		lpCombo.add("Excel");
		lpCombo.add("CSV");
		lpCombo.add("TXT");
		lpCombo.setSimpleValue("Excel");
		lpCombo.setTriggerAction(TriggerAction.ALL);
		lpCombo.setEditable(false);
		// End Of Change

		solve.addSelectionListener(new SelectionListener<ButtonEvent>() {
			@Override
			public void componentSelected(ButtonEvent ce) {
				if (BedarfsplanView.returnBedarf() == null) {
					Window.alert("Bedarfsplan ist null");
				} else if (ShiftlistView.returnShifts() == null) {
					Window.alert("Schichtplan ist null");
				} else {
					solve();
					lp.setEnabled(true);
				}
			}
		});
		lp.addSelectionListener(new SelectionListener<ButtonEvent>() {
			@Override
			public void componentSelected(ButtonEvent ce) {
				PersPlanServiceAsync persPlanService = (PersPlanServiceAsync) GWT.create(PersPlanService.class);
				AsyncCallback<String> callback = new AsyncCallback<String>() {
					@Override
					public void onSuccess(String result) {
						// Begin of Change by toehrlin
						if (lpCombo.getSelectedIndex() == -1) {
							Window.alert(constants.errorNoExportFormat());
						} else {
							if (result != null) {
								if (lpCombo.getSelectedIndex() == 0) {
									new FileDownloadView("xls", result).show();
								}
								if (lpCombo.getSelectedIndex() == 1) {
									new FileDownloadView("csv", result).show();
								}
								// Begin of Change by fafilipp
								if (lpCombo.getSelectedIndex() == 2) {
									new FileDownloadView("txt", result).show();
								}
								// End of Change
							} else {
								Window.alert(constants.errorNoExportFile());
							}
						}
						// lpCombo.reset();
					}
					//End of Change by toehrlin

					@Override
					public void onFailure(Throwable caught) {
						Window.alert(caught.getMessage());
					}
				};
				persPlanService.getLPURL(callback);
			}
		});
		formPanel.add(combo, new FormData("-20"));
		formPanel.add(lpCombo, new FormData("-20"));
		formPanel.addButton(solve);
		formPanel.addButton(lp);

		check1 = new CheckBox();

		check1.setBoxLabel(constants.showOverStaffing());
		check2 = new CheckBox();
		check2.setBoxLabel(constants.showBreaks());
		check2.setValue(true);

		CheckBoxGroup checkGroup = new CheckBoxGroup();
		checkGroup.setFieldLabel("Music");
		checkGroup.add(check1);
		checkGroup.add(check2);
		checkGroup.setData("text", constants.chooseGraphics());

		ContentPanel chartPane = rsc.getResultChart();
		data = new RowData(1, 400, new Margins(10));
		outerContainer.add(chartPane, data);
		eastLayoutData.setMargins(new Margins(5, 5, 5, 5));
		eastLayoutData.setSize(0.25f);
		innerContainerEast.add(formPanel, new RowData(1, 1, new Margins(5, 5, 10, 0)));

		return outerContainer;
	}

	/**
	 * Solve.
	 */
	public void solve() {

		final PersPlanServiceAsync persPlanService = (PersPlanServiceAsync) GWT.create(PersPlanService.class);
		GWT.create(PersPlanService.class);
		AsyncCallback<List<Result>> callback = new AsyncCallback<List<Result>>() {
			@Override
			public void onSuccess(List<Result> result) {
				boolean isRounded = result.size() > 0 ? result.get(0).isRounded() : false;
				if (isRounded) {
					Window.alert(constants.wasRoundedWarning());
				}
				AsyncCallback<List<ResultBaseModel>> callback2 = new AsyncCallback<List<ResultBaseModel>>() {
					@Override
					public void onSuccess(List<ResultBaseModel> resultBase) {
						store.removeAll();
						store.add(resultBase);
					}

					@Override
					public void onFailure(Throwable caught) {
						Window.alert(caught.getMessage());
					}
				};
				AsyncCallback<int[][]> callback3 = new AsyncCallback<int[][]>() {
					@Override
					public void onSuccess(int[][] graphic) {
						rsc.updateChart(graphic);
					}

					@Override
					public void onFailure(Throwable caught) {
						Window.alert(caught.getMessage());
					}
				};
				persPlanService.getResultBaseModel(result, callback2);
				persPlanService.getGraficVisualOfResult(result, BedarfsplanView.returnBedarf(), callback3);
			}

			@Override
			public void onFailure(Throwable caught) {
				Window.alert(caught.getMessage());
			}
		};
		/** Begin of Change FaLauber **/
		List<ShiftBaseModel> shifts = ShiftlistView.returnShifts();
		List<Bedarf> bedarfList = BedarfsplanView.returnBedarf();
		
		if(validate(shifts, bedarfList)) {
			persPlanService.solve(BedarfsplanView.returnBedarf(), shifts, callback);
		}
		/** End of Change FaLauber **/
	}
	
	/**
	 * Validates the input data. Only valid data will start the solving progress.
	 * Otherwise a message dialog informs the user.
	 * @param shifts List of shifts for the solving progress
	 * @param bedarfList List of demand for the solving progress
	 * @return true if input data is valid
	 * @autor FaLauber
	 */
	private boolean validate(List<ShiftBaseModel> shifts, List<Bedarf> bedarfList) {
		for (Bedarf bedarf : bedarfList) {
			if (bedarf.getBedarf() != 0) {
				Window.alert(constants.keinBedarfEingegben());
				return false;
			}
		}
		if (shifts.size() <= 1) {
			Window.alert(constants.keineSchichtmuster());
			return false;
		} else {
			for (ShiftBaseModel shift : shifts) {
				if (shift.getStart().equals(shift.getEnd()) && shift.getStart().equals("00:00")) {
					Window.alert(constants.fehlerhaftesSchichtmuster());
					return false;
				}
			}
		}
		
		return true;
	}

	/**
	 * The Class ResultChart.
	 */
	protected class ResultChart {

		/** The chart pane. */
		ContentPanel chartPane = null;

		/** The chart. */
		Chart chart = null;

		/** The bar chart. */
		StackedBarChart barChart = null;

		/** The line. */
		LineChart line = null;

		/** The x axis. */
		XAxis xAxis = null;

		/** The y axis. */
		YAxis yAxis = null;

		/** The model. */
		ChartModel model = null;

		/**
		 * Gets the result chart.
		 * 
		 * @return the result chart
		 */
		public ContentPanel getResultChart() {
			chartPane = new ContentPanel(new FitLayout());
			chartPane = new ContentPanel();
			chartPane.setIcon(Resources.ICONS.chart());
			chartPane.setCollapsible(true);
			chartPane.setHeading(constants.visualizationOfShifts());
			chartPane.setStyleAttribute("margin", "10");
			String url = "resources/chart/open-flash-chart.swf";
			chart = new Chart(url);

			barChart = new StackedBarChart();
			xAxis = new XAxis();
			xAxis.setMax(47);
			yAxis = new YAxis();
			yAxis.setSteps(1);
			yAxis.setMin(0);
			yAxis.setMax(10);

			int z = 0;
			for (TimeIntervall t : TimeIntervall.getHalfIntervalls()) {
				Label l = new Label(t.getStartIntervall());
				if ((z % 2) == 0) {
					xAxis.addLabels(l);
				} else {
					xAxis.addLabels("");
				}
				z++;
			}
			model = new ChartModel(constants.graphicRepresentationOfShifts(),
					"font-weight: bold; font-size: 14px; font-family: Verdana; text-align: center;");
			model.setXAxis(xAxis);
			model.setYAxis(yAxis);

			line = new LineChart();

			model.setBackgroundColour("#fefefe");
			model.addChartConfig(barChart);
			model.addChartConfig(line);

			chart.setChartModel(model);
			chart.setToolTip("");
			html = new HTML("<img src=" + constants.bildLegede() + ">");
			html.setPixelSize(990, 11);
			chartPane.add(html);
			chart.setHeight(340);
			chartPane.add(chart);
			chartPane.setToolTip("");

			return chartPane;
		}

		/**
		 * Update chart.
		 * 
		 * @param visual
		 *            the visual
		 */
		private void updateChart(int[][] visual) {
			/**
			 * Begin of change (jaglaubi and fafilipp)
			 */
			// line (Bedarf) resetten, damit nicht einfach nur
			// hinten angehängt wird
			line = null;

			// line (Bedarf) neu erzeugen und Farbe setzen
			line = new LineChart();
			line.setColour("#FF0000");
			/**
			 * End of change
			 */

			barChart = new StackedBarChart();
			int shifts = (visual.length - 2) / 6;
			int highestValue = 0;
			if (shifts > 0) {
				for (int i = 0; i < 48; i++) {
					int shiftCounter = 0;
					int values = 0;
					List<StackedBarChart.StackValue> stackValues = new ArrayList<StackedBarChart.StackValue>();
					for (int y = 1; y < visual.length - 3; y += 3) {
						shiftCounter++;
						/**
						 * Begin of change (jaglaubi, fafilipp)
						 */
						if (visual[y][i] != 0) {
							values += visual[y][i];
							if (visual[y + 2][i] != 0) {
								int demandShift = visual[y][i];
								int over = visual[y + 2][i];
								int under = visual[y + 1][i];
								if (under != 0) {
									String farbe = shiftColors[shiftCounter - 1];
									drawPeopleInShift(under, stackValues, farbe);
								}
								for (int b = 0; b < over - under; b++) {
									// hier werden die Pausen gezeichnet
									stackValues.add(new StackedBarChart.StackValue(1, "FF7F24"));
									// stackValues.add(new
									// StackedBarChart.StackValue(0.25,
									// "FF7F24"));
									// stackValues.add(new
									// StackedBarChart.StackValue(0.25,
									// shiftColors[shiftCounter - 1]));
									// stackValues.add(new
									// StackedBarChart.StackValue(0.25,
									// "FF7F24"));
									// stackValues.add(new
									// StackedBarChart.StackValue(0.25,
									// shiftColors[shiftCounter - 1]));
								}
								if (over < demandShift) {
									int add = demandShift - over;
									String farbe = shiftColors[shiftCounter - 1];
									drawPeopleInShift(add, stackValues, farbe);
								}
							} else {
								int add = visual[y][i];
								String farbe = shiftColors[shiftCounter - 1];
								drawPeopleInShift(add, stackValues, farbe);
							}
						}
						/**
						 * End of change
						 */
					}
					if (stackValues.size() == 0) {
						barChart.addNullValue();
					} else {
						barChart.addStack(stackValues);
					}

					if (values > highestValue) {
						highestValue = values;
					}

				}
			}

			// Bedarf zeichnen
			for (int i = 0; i < visual[0].length; i++) {
				/**
				 * Begin of change (jaglaubi)
				 */
				// line.addValues(visual[visual.length - 1][i]);
				line.addValues(visual[0][i]);
				/**
				 * End of change
				 */
			}

			// data = new ArrayList<HorizontalStackedBarChart.StackValue>();
			// data.add(new HorizontalStackedBarChart.StackValue(-1, -1,
			// "#FF0000", "Bedarf"));
			// data.add(new HorizontalStackedBarChart.StackValue(-1, -1,
			// "#FF7F24", "Pause"));
			//
			// // data.add()
			// dataArray = data.toArray(new
			// HorizontalStackedBarChart.StackValue[0]);
			//
			// HorizontalStackedBarChart barChart2 = new
			// HorizontalStackedBarChart();
			// barChart2.addStack(dataArray);
			// barChart2.setBarwidth(0);

			barChart.setTooltip("");
			yAxis.setMax(highestValue + 2);
			model = new ChartModel();
			model.setXAxis(xAxis);
			model.setYAxis(yAxis);
			model.addChartConfig(barChart);
			model.addChartConfig(line);
			chart.setChartModel(model);
			chart.setToolTip("");
			chart.removeToolTip();
			model.addChartConfig(line);

		}

		/**
		 * 
		 * @param sumBreakLength
		 *            Länge der Pause
		 * @param stackValues
		 *            Objekt in das die Werte hinzugefügt werden sollen
		 * @param farbe
		 *            Farbe, in der gezeichnet werden soll
		 */
		private void drawPeopleInShift(int sumBreakLength, List<StackedBarChart.StackValue> stackValues, String farbe) {
			for (int l = 0; l < sumBreakLength; l++) {
				stackValues.add(new StackedBarChart.StackValue(1, farbe));

			}
		}
	}
}