package com.tagesplanung.server;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import de.htwg.teamprojekt.lpgenerator.LPGenerator;

/**
 * Servlet implementation class ExcelDownloadServlet
 */
public class ExcelDownloadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ExcelDownloadServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			String format = request.getParameter("format");
			String filename = request.getParameter("file");
			String outname = request.getParameter("fileName");

			InputStream in = null;

			if (format.equals("xls")) {
				in = LPGenerator.excelGenerationFromXA(new FileInputStream(filename));
				response.addHeader("Content-Type", "application/octet-stream");
				response.addHeader("Pragma", "public");
				response.addHeader("Cache-Control", "max-age=0");
				response.setHeader("Content-Disposition", "attachment; filename=" + outname + ".xls");
			}
			if (format.equals("csv")) {
				in = LPGenerator.csvGenerationFromXA(new FileInputStream(filename));
				response.addHeader("Content-Type", "application/octet-stream");
				response.addHeader("Pragma", "public");
				response.addHeader("Cache-Control", "max-age=0");
				response.setHeader("Content-Disposition", "attachment; filename=" + outname + ".csv");
			}
			if (format.equals("txt")) {
				in = LPGenerator.txtGenerationFromXA(new FileInputStream(filename));
				response.addHeader("Content-Type", "application/octet-stream");
				response.addHeader("Pragma", "public");
				response.addHeader("Cache-Control", "max-age=0");
				response.setHeader("Content-Disposition", "attachment; filename=" + outname + ".txt");
			}

			ServletOutputStream outs = response.getOutputStream();
			byte[] excelFile = new byte[1024];
			int read = 0;
			while ((read = in.read(excelFile, 0, 1024)) != -1) {
				outs.write(excelFile, 0, read);
			}

			in.close();
			outs.flush();
			outs.close();
		} catch (FileNotFoundException e) {
			PrintWriter pw = response.getWriter();
			pw.write("Es ist ein Fehler beim Bearbeiten aufgetreten. Bitte erneut l�sen!");
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
