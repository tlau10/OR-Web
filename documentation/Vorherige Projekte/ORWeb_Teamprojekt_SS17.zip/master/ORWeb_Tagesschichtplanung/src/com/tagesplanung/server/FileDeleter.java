package com.tagesplanung.server;

import java.io.File;
import java.util.regex.Pattern;

// TODO: Auto-generated Javadoc
/**
 * The Class FileDeleter.
 */
public class FileDeleter {

	/** The path. */
	private String path;

	/**
	 * Instantiates a new file deleter.
	 *
	 * @param path the path
	 */
	public FileDeleter(String path) {
		this.path = path;
	}
	
	/**
	 * Delete files.
	 *
	 * @param sessionID the session id
	 */
	public void deleteFiles(String sessionID) {
		String id = sessionID.substring(0, 5);
		String[] entries = new File(path + "solver").list();
		Pattern p = Pattern.compile("(.*\\.LP$)|(.*\\.OUT$)|(.*\\.SAV$)", Pattern.CASE_INSENSITIVE);
		for (int i = 0; i < entries.length; i++) {
			File f = new File(entries[i]);
			if (p.matcher(f.getName()).matches()) {
				if (f.getName().contains(id)) {
					f.delete();
				}
			}
		}
	}
}