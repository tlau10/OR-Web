package com.tagesplanung.server.data;

/**
 * The Class Break represents an interval of half an hour where the people assigned to this break don't work.
 * The day is split into 48 half an hour intervals (from 1 to 48).
 */
public class Break { 
	
	/** The number of the interval (half an hour - from 1 to 48) of the break. */
	private int number;
	
	/** The people assigned to take a break. */
	private int people;
		
	/**
	 * Instantiates a new break.
	 *
	 * @param number the number of the break interval
	 * @param people the people assigned to take a break
	 */
	public Break(int number, int people) {
		this.number = number;
		this.people = people;
	}	
	
	/**
	 * Gets the number of the break interval.
	 *
	 * @return the number of the break interval
	 */
	public int getNumber() {
		return number;
	}
	
	/**
	 * Sets the number of the break interval.
	 *
	 * @param number the new number of the break interval
	 */
	public void setNumber(int number) {
		this.number = number;
	}
	
	/**
	 * Gets the people assigned to take a break.
	 *
	 * @return the people assigned to take a break
	 */
	public int getPeople() {
		return people;
	}
	
	/**
	 * Sets the people assigned to take a break.
	 *
	 * @param people the new people assigned to take a break
	 */
	public void setPeople(int people) {
		this.people = people;
	}
}