package com.tagesplanung.server.data;

/**
 * The Class BreakArea represents a time period of arbitrary length 
 * in which the people who are working in the shift to which the break area 
 * belongs could potentially take a break.
 * The solver sets the break for every worker to a specific half an hour within this period.
 */
public class BreakArea {
	
	/** The start interval of the break area. */
	private int from;
	
	/** The end interval of the break area. */
	private int to;	 
	
	/** The priority of the break area (not used at the moment). */
	private int priority;
	
	/**
	 * Instantiates a new break area.
	 *
	 * @param from the start of the break area
	 * @param to the end of the break area
	 * @param priority the priority of the break area
	 */
	public BreakArea(int from, int to, int priority) {
		this.from = from;
		this.to = to;
		this.priority = priority;
	}
	
	/**
	 * Gets the start of the break area.
	 *
	 * @return the start of the break area
	 */
	public int getFrom() {
		return from;
	}
	
	/**
	 * Sets the start of the break area.
	 *
	 * @param from the new start of the break area
	 */
	public void setFrom(int from) {
		this.from = from;
	}
	
	/**
	 * Gets the end of the break area.
	 *
	 * @return the end of the break area
	 */
	public int getTo() {
		return to;
	}
	
	/**
	 * Sets the end of the break area.
	 *
	 * @param to the new end of the break area
	 */
	public void setTo(int to) {
		this.to = to;
	}
	
	/**
	 * Gets the priority of the break area.
	 *
	 * @return the priority
	 */
	public int getPriority() {
		return priority;
	}
	
	/**
	 * Sets the priority of the break area.
	 *
	 * @param priority the new priority
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}
}