package com.tagesplanung.server.data;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;


/**
 * The Class MarshallData marshall SaveLoadDemand and SaveLoadShift objects with JAXB
 * in xml Documents.
 */
public class MarshallData {
	
	/**
	 * The marshallDemand method marshall a SaveLoadDemand object in a xml document.
	 *
	 * @param path is the future path of the xml document
	 * @param sld is the target object to marshall
	 */
	public void marshallDemand(String path, SaveLoadDemand sld){
		JAXBContext context;
		try {
			context = JAXBContext.newInstance(SaveLoadDemand.class);
			Marshaller m = context.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			Writer w = null;
			w = new FileWriter(path);
			m.marshal(sld, w);	
		} catch (JAXBException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * The marshallShift method marshall a SaveLoadShift object in a xml document.
	 *
	 * @param path is the future path of the xml document
	 * @param sls is the target object to marshall
	 */
	public void marshallShift(String path, SaveLoadShift sls){	
		JAXBContext context;
		try {
			context = JAXBContext.newInstance(SaveLoadShift.class);
			Marshaller m = context.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			Writer w = null;
			w = new FileWriter(path);
			m.marshal(sls, w);	
		} catch (JAXBException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}