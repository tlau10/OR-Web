
package com.tagesplanung.server.data;

import java.io.FileNotFoundException;
import java.io.FileReader;

import javax.xml.bind.JAXB;


/**
 * The Class UnMarshallData unmarshall the LoadFile.xml document with JAXB in 
 * SaveLoadDemand or SaveLoadShift objects.
 */
public class UnMarshallData {
	
	/**
	 * The unMarhallDemand method unmarshall the LoadFile.xml document in a SaveLoadDemand object.
	 *
	 * @param path is the filepath of the LoadFile.xml document
	 * @return the save load demand
	 */
	public SaveLoadDemand unMarhallDemand(String path) {
		SaveLoadDemand slDemand = null;
		try {
			FileReader fileReader = new FileReader(path);
			slDemand = JAXB.unmarshal(fileReader, SaveLoadDemand.class);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return slDemand;
	}
	
	/**
	 * The unMarshallShift method unmarshall the LoadFile.xml document in a SaveLoadShift object.
	 *
	 * @param path is the filepath of the LoadFile.xml document
	 * @return the save load shift
	 */
	public SaveLoadShift unMarshallShift(String path) {
		SaveLoadShift slShift = null;
		try {
			FileReader fileReader = new FileReader(path);
			slShift = JAXB.unmarshal(fileReader, SaveLoadShift.class);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return slShift;
	}
}