package com.tagesplanung.server.solver;

import com.tagesplanung.server.data.SolverInputData;
import com.tagesplanung.server.data.SolverOutputData;

/**
 * Interface to integrate a new solver.
 *
 */
public interface ISolver {

	/**
	 * In the solve method the files needed for the solver are created.
	 * After running the solver, the solver output file is parsed and 
	 * the result are wrapped in a SolverOutputData object.
	 *
	 * @param data the solver input data
	 * @param sessionID the session id
	 * @return the solver output data (contains optimal solution)
	 */	
	public abstract SolverOutputData solve(SolverInputData data, String sessionID);

}