package com.tagesplanung.server.solver.xa;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.tagesplanung.server.data.Break;
import com.tagesplanung.server.data.SolverOutputData;

/**
 * The Class XAOutputCreator. A SolverOutputData object is initialized with the
 * data from the solver output file.
 * 
 */
public class XAOutputCreator {

	/** The solver out put data to store result. */
	public SolverOutputData sod;

	/**
	 * Creates the solution.
	 * 
	 * @param pathToOut
	 *            the path to the solver output file
	 * @return the solver output data
	 * @throws FileNotFoundException
	 *             Signals that the file was not found
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public SolverOutputData createSolution(String pathToOut) throws FileNotFoundException, IOException {
		boolean isRounded = false;

		ArrayList<Integer> shiftList = new ArrayList<Integer>();
		ArrayList<Break> breakList = new ArrayList<Break>();
		BufferedReader reader = new BufferedReader(new FileReader(pathToOut));
		/**
		 * Begin of change (jaglaubi)
		 */
		Pattern shiftPattern = Pattern.compile("s\\d+\\s+\\d+\\.\\d+\\s+\\-?\\d+");
		Pattern breakPattern = Pattern.compile("p\\d+\\s+\\d+\\.\\d+\\s+\\-?\\d+");
		int shiftIndex = 0;
		int breakIndex = 0;
		while (reader.ready()) {
			String currentLine = reader.readLine();
			Matcher shiftMatcher = shiftPattern.matcher(currentLine);
			Matcher breakMatcher = breakPattern.matcher(currentLine);

			// people per shift
			if (shiftMatcher.find()) {
				String schichtString = "\\d+.\\d+";
				Pattern shPat = Pattern.compile(schichtString);
				Matcher shMatch = shPat.matcher(currentLine);
				shMatch.find();
				// shMatch.find();
				double tempPeople = Double.parseDouble(currentLine.substring(shMatch.start(), shMatch.end()));
				if (tempPeople % 1.0 != 0.0) {
					isRounded = true;
				}
				int hulk = (int) Math.round(tempPeople);
				// int hulk =
				// Integer.parseInt(currentLine.substring(shMatch.start(),
				// shMatch.end()));
				shiftList.add(hulk);
				shiftIndex++;
			}

			// read id of interval for shift and breaks
			if (breakMatcher.find()) {

				// RegExp zum Auslesen der Pausennummer
				String breakNumberString = "\\d+";
				Pattern breakNumberPattern = Pattern.compile(breakNumberString);
				Matcher breakNumberMatcher = breakNumberPattern.matcher(currentLine);

				// RegExp zum Auslesen der Anzahl der Personen in der Pause
				String breakString = "\\d+\\.\\d+";
				Pattern brPat = Pattern.compile(breakString);
				Matcher brMat = brPat.matcher(currentLine);

				// Pausennummer im String finden
				breakNumberMatcher.find();

				// Auslesen der Pausennummer als double...
				double tempNumber = Double.parseDouble(currentLine.substring(breakNumberMatcher.start(), breakNumberMatcher.end()));

				// ...und Umwandeln zu int
				int number = new Double(tempNumber).intValue();

				// Anzahl der Personen in der Pause finden
				brMat.find();

				// Anzahl der Personen in der Pause als double auslesen
				double tempPeople = Double.parseDouble(currentLine.substring(brMat.start(), brMat.end()));
				if (tempPeople % 1.0 != 0.0) {
					isRounded = true;
				}
				int people = (int) Math.round(tempPeople);

				// sollte es weniger als eine aber mehr als 0 Personen in der
				// Pause sein auf 1 aufrunden
				// if ((tempPeople > 0) && (tempPeople < 1)) {
				// people = 1;
				// } else {
				// // ansonsten den Integertwert ("immer abrunden") nehmen
				// people = new Double(tempPeople).intValue();
				// }

				if (people != 0) {
					Break breakObject = new Break(number, people);
					breakList.add(breakObject);
					breakIndex++;
				}
			}
		}
		/**
		 * End of change
		 */
		reader.close();
		sod = new SolverOutputData(shiftList, breakList);
		sod.setRounded(isRounded);
		return sod;
	}
}