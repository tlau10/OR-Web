package com.tagesplanung.server.solver.xa.resources;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * This class is the XA Solver Resources Class. It has one static Method, which
 * copies the XA.exe (executable) to the working dir for the user.
 * 
 * @author Fabio Filippelli
 */
public class XAResourceUtil {

	/**
	 * Copies the XA.exe to the Working Dir if the file doesn't exists.
	 * 
	 * @param currentDir
	 *            the current working dir
	 */
	public static void copyXAExeTo(String currentDir) {
		try {
			// build the path for xa.exe
			InputStream is = XAResourceUtil.class.getResourceAsStream("XA.EXE");
			StringBuilder filePath = new StringBuilder(currentDir);
			filePath.append("XA.EXE");
			File xaExe = new File(filePath.toString());

			// if xa is not in working dir, then copy it
			if (!xaExe.exists()) {
				FileOutputStream fos = new FileOutputStream(filePath.toString());
				byte[] buffer = new byte[1024];
				int read = 0;
				while ((read = is.read(buffer)) != -1) {
					fos.write(buffer, 0, read);
					fos.flush();
				}
				is.close();
				fos.close();
			}
		} catch (IOException e) {
			// no exception handling needed
		}
	}

}
