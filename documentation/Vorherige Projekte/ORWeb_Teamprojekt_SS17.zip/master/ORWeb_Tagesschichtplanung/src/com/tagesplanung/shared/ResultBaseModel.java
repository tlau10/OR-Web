package com.tagesplanung.shared;

import java.util.ArrayList;
import java.util.List;

import com.extjs.gxt.ui.client.data.BaseModel;
import com.google.gwt.user.client.rpc.IsSerializable;

// TODO: Auto-generated Javadoc
/**
 * The Class ResultBaseModel.
 */
public class ResultBaseModel extends BaseModel implements IsSerializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new result base model.
	 */
	public ResultBaseModel() {
		super();
	}

	/**
	 * Instantiates a new result base model.
	 * 
	 * @param shiftNumber
	 *            the shift number
	 * @param shiftStart
	 *            the shift start
	 * @param shiftEnd
	 *            the shift end
	 * @param numberOfPeople
	 *            the number of people
	 * @param breakIntervall
	 *            the break intervall
	 * @param numberOfPeopleInBreak
	 *            the number of people in break
	 */
	public ResultBaseModel(String shiftNumber, String shiftStart,
			String shiftEnd, String numberOfPeople, String breakIntervall,
			String numberOfPeopleInBreak) {
		set("shiftNumber", shiftNumber);
		set("shiftStart", shiftStart);
		set("shiftEnd", shiftEnd);
		set("numberOfPeople", numberOfPeople);
		set("breakIntervall", breakIntervall);
		set("numberOfPeopleInBreak", numberOfPeopleInBreak);
	}

	/**
	 * Gets the shift number.
	 * 
	 * @return the shift number
	 */
	public String getShiftNumber() {
		return (String) get("shiftNumber");
	}

	/**
	 * Sets the shift number.
	 * 
	 * @param shiftNumber
	 *            the new shift number
	 */
	public void setShiftNumber(String shiftNumber) {
		set("shiftNumber", shiftNumber);
	}

	/**
	 * Gets the shift start.
	 * 
	 * @return the shift start
	 */
	public String getShiftStart() {
		return (String) get("shiftStart");
	}

	/**
	 * Sets the shift start.
	 * 
	 * @param shiftStart
	 *            the new shift start
	 */
	public void setShiftStart(String shiftStart) {
		set("shiftStart", shiftStart);
	}

	/**
	 * Gets the shift end.
	 * 
	 * @return the shift end
	 */
	public int getShiftEnd() {
		return (Integer) get("shiftEnd");
	}

	/**
	 * Sets the shift end.
	 * 
	 * @param shiftEnd
	 *            the new shift end
	 */
	public void setShiftEnd(String shiftEnd) {
		set("shiftEnd", shiftEnd);
	}

	/**
	 * Gets the number of people.
	 * 
	 * @return the number of people
	 */
	public String getNumberOfPeople() {
		return (String) get("numberOfPeople");
	}

	/**
	 * Sets the number of people.
	 * 
	 * @param numberOfPeople
	 *            the new number of people
	 */
	public void setNumberOfPeople(String numberOfPeople) {
		set("numberOfPeople", numberOfPeople);
	}

	/**
	 * Gets the break intervall.
	 * 
	 * @return the break intervall
	 */
	public String getBreakIntervall() {
		return (String) get("breakIntervall");
	}

	/**
	 * Sets the break intervall.
	 * 
	 * @param breakIntervall
	 *            the new break intervall
	 */
	public void setBreakIntervall(String breakIntervall) {
		set("breakIntervall", breakIntervall);
	}

	/**
	 * Gets the number of people in break.
	 * 
	 * @return the number of people in break
	 */
	public String getNumberOfPeopleInBreak() {
		return (String) get("numberOfPeopleInBreak");
	}

	/**
	 * Sets the number of people in break.
	 * 
	 * @param numberOfPeopleInBreak
	 *            the new number of people in break
	 */
	public void setNumberOfPeopleInBreak(String numberOfPeopleInBreak) {
		set("numberOfPeopleInBreak", numberOfPeopleInBreak);
	}

	/**
	 * Transform result object to base model.
	 * 
	 * @param r
	 *            the r
	 * @return the list
	 */
	public static List<ResultBaseModel> transformResultObjectToBaseModel(
			List<Result> r) {
		List<ResultBaseModel> list = new ArrayList<ResultBaseModel>();
		for (Result temp : r) {
			ResultBaseModel rBModel = new ResultBaseModel();
			if (temp.getShiftNumber() == 0) {
				rBModel.setShiftNumber(null);
			} else {
				rBModel.setShiftNumber(Integer.toString(temp.getShiftNumber()));
			}
			rBModel.setShiftStart(temp.getShiftStart());
			rBModel.setShiftEnd(temp.getShiftEnd());
			if (temp.getNumberOfPeople() == 0) {
				rBModel.setNumberOfPeople(null);
			} else {
				rBModel.setNumberOfPeople(Integer.toString(temp
						.getNumberOfPeople()));
			}
			rBModel.setBreakIntervall(temp.getBreakIntervall());
			if (temp.getNumberOfPeopleInBreak() == 0) {
				rBModel.setNumberOfPeopleInBreak(null);
			} else {
				rBModel.setNumberOfPeopleInBreak(Integer.toString(temp
						.getNumberOfPeopleInBreak()));
			}
			list.add(rBModel);
		}
		return list;
	}
}