package com.tagesplanung.shared.resources;

import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.google.gwt.user.client.ui.ImageBundle;

// TODO: Auto-generated Javadoc
/**
 * The Interface MyIcons.
 */
@SuppressWarnings("deprecation")
public interface MyIcons extends ImageBundle {

	/**
	 * Addrow.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/addrow.png")
	AbstractImagePrototype addrow();

	/**
	 * Reset.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/reset.png")
	AbstractImagePrototype reset();

	/**
	 * Delete.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/delete.png")
	AbstractImagePrototype delete();

	/**
	 * Solve.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/solve.png")
	AbstractImagePrototype solve();
	
	/**
	 * Apply.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/apply.png")
	AbstractImagePrototype apply();
	
	/**
	 * Back.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/back.png")
	AbstractImagePrototype back();
	
	/**
	 * Forward.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/forward.png")
	AbstractImagePrototype forward();
	
	/**
	 * Table.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/table.gif")
	AbstractImagePrototype table();
	
	/**
	 * Chart.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/chart.png")
	AbstractImagePrototype chart();
	
	/**
	 * Demand assistant.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/demandAssistant.png")
	AbstractImagePrototype demandAssistant();
	
	/**
	 * Clock.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/clock.png")
	AbstractImagePrototype clock();
	
	/**
	 * Info.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/info.png")
	AbstractImagePrototype info();
	
	/**
	 * New file.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/newFile.png")
	AbstractImagePrototype newFile();
	
	/**
	 * Open.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/open.png")
	AbstractImagePrototype open();
	
	/**
	 * Open_demand.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/open_demand.png")
	AbstractImagePrototype open_demand();
	
	/**
	 * Open_shifts.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/open_shifts.png")
	AbstractImagePrototype open_shifts();
	
	/**
	 * Save.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/save.png")
	AbstractImagePrototype save();
	
	/**
	 * Save_demand.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/save_demand.png")
	AbstractImagePrototype save_demand();
	
	/**
	 * Save_shifts.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/save_shift.png")
	AbstractImagePrototype save_shifts();
	
	/**
	 * Help.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/help.png")
	AbstractImagePrototype help();
	
	/**
	 * Result.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/result.png")
	AbstractImagePrototype result();
	
	/**
	 * Shift.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/shift.png")
	AbstractImagePrototype shift();
	
	/**
	 * Settings.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/settings.png")
	AbstractImagePrototype settings();
	
	/**
	 * Gb.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/gb.png")
	AbstractImagePrototype gb();
	
	/**
	 * Ger.
	 *
	 * @return the abstract image prototype
	 */
	@Resource("com/tagesplanung/shared/resources/images/ger.png")
	AbstractImagePrototype ger();
}
