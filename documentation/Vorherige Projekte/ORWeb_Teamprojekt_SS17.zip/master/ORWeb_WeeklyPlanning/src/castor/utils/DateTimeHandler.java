package castor.utils;

import java.util.Date;
import java.util.GregorianCalendar;

import org.exolab.castor.mapping.GeneralizedFieldHandler;

public class DateTimeHandler extends GeneralizedFieldHandler {

	@Override
	public Object convertUponGet(Object obj) {
		if (obj == null) {
			return null;
		} else {
			return ((GregorianCalendar) obj).getTime();
		}
	}

	@Override
	public Object convertUponSet(Object obj) {
		if (obj == null) {
			return null;
		} else {
			GregorianCalendar gregorianCalendar = new GregorianCalendar();
			gregorianCalendar.setTime((Date) obj);
			return gregorianCalendar;
		}
	}

	@Override
	public Class getFieldType() {
		// TODO Auto-generated method stub
		return GregorianCalendar.class;
	}

}
