package de.htwg.konstanz.schichtplanung.page;

import java.util.ArrayList;
import java.util.List;

import net.sf.click.control.Form;
import net.sf.click.control.Submit;
import net.sf.click.control.Table;
import net.sf.click.control.TextField;
import net.sf.click.extras.control.FieldColumn;
import net.sf.click.extras.control.FormTable;
import schichtmuster.Schicht;
import schichtmuster.Schichtfolge;
import de.htwg.konstanz.schichtplanung.utils.SchichtSelect;
import de.htwg.konstanz.schichtplanung.utils.SchichtfolgeAdapter;
import de.htwg.konstanz.schichtplanung.utils.SchichtmusterAdapter;
import de.htwg.konstanz.schichtplanung.utils.SessionAttributes;

public class EinSchichtmuster extends BorderPage {

	private static final int NUM_ROWS = 1;
	public String title = "Schichtmuster eingeben";

	public Form form = new Form();
	public FormTable table = new FormTable();
	public TextField textField1;
	public SchichtmusterAdapter schichtmusterAdapter;

	private ArrayList<Schicht> schichtmuster;

	public EinSchichtmuster() {
		schichtmusterAdapter = new SchichtmusterAdapter(1);
		// FieldSet fieldSet = new FieldSet("rotationsDetails");
		// form.add(fieldSet);

		textField1 = new TextField("smb", "Länge Schichtmuster (Wochen): ",
				true);
		textField1.setSize(2);
		textField1.setRequired(false);
		textField1.setMaxLength(2);
		// fieldSet.add(textField1);
		form.add(textField1);
		form.add(new Submit("ok", "  Wochen anzeigen  ", this,
				"onTextFieldClick"));

		table.setClass(Table.CLASS_SIMPLE);

		FieldColumn column;
		String[][] array = new String[7][2];
		array[0][0] = "mo";
		array[0][1] = "Montag";
		array[1][0] = "di";
		array[1][1] = "Dienstag";
		array[2][0] = "mi";
		array[2][1] = "Mittwoch";
		array[3][0] = "do";
		array[3][1] = "Donnerstag";
		array[4][0] = "fr";
		array[4][1] = "Freitag";
		array[5][0] = "sa";
		array[5][1] = "Samstag";
		array[6][0] = "so";
		array[6][1] = "Sonntag";

		int konstante1 = 0;
		int konstante2 = 1;
		int zaehler = 0;
		for (int i = 0; i < schichtmusterAdapter.getTextFieldValue(); i++) {
			// System.out.println("wert: " +
			// schichtmusterAdapter.getTextFieldValue());
			for (int j = 0; j < 7; j++) {

				column = new FieldColumn(array[j][konstante1],
						array[j][konstante2], new SchichtSelect());

				table.addColumn(column);
				zaehler++;
				// column = new FieldColumn("mo", "Montag", new
				// SchichtSelect());
				// table.addColumn(column);
				//
				// column = new FieldColumn("di", "Dienstag", new
				// SchichtSelect());
				// table.addColumn(column);
				//
				// column = new FieldColumn("mi", "Mittwoch", new
				// SchichtSelect());
				// table.addColumn(column);
				//
				// column = new FieldColumn("do", "Donnerstag", new
				// SchichtSelect());
				// table.addColumn(column);
				//
				// column = new FieldColumn("fr", "Freitag", new
				// SchichtSelect());
				// table.addColumn(column);
				//
				// column = new FieldColumn("sa", "Samstag", new
				// SchichtSelect());
				// table.addColumn(column);
				//
				// column = new FieldColumn("so", "Sonntag", new
				// SchichtSelect());
				// table.addColumn(column);
			}
		}

		table.getForm().add(
				new Submit("ok", "  Speichern  ", this, "onOkClick"));
		// System.out.println("zaehler: " + zaehler);
	}

	// --Daten in FormTable Tabelle initialisieren
	@Override
	public void onInit() {
		super.onInit();

		schichtmuster = (ArrayList<Schicht>) getContext().getSessionAttribute(
				SessionAttributes.SCHICHTMUSTER);
		// System.out.println("Schichtmuster " + schichtmuster);

		table.setRowList(getList(schichtmuster));
	}

	// --�bergibt leere Arraylist and die setRowList()
	public List getList(ArrayList<Schicht> schichtmuster) {

		ArrayList<Schicht> schichten = new ArrayList<Schicht>();
		// int anzahlFelder =
		// (Integer.valueOf(schichtfolgeAdapter.getTextField1()).intValue()) *
		// 7;
		if (schichtmuster == null) {
			// System.out.println("Test: " + anzahlFelder);
			for (int j = 0; j < (schichtmusterAdapter.getTextFieldValue() * 7); j++) {
				schichten.add(Schicht.FREISCHICHT);
			}
			getContext().getSession().setAttribute(
					SessionAttributes.SCHICHTMUSTER, schichten);

			Schichtfolge schichtfolge = new Schichtfolge(schichten);
			List<SchichtfolgeAdapter> adapterList = new ArrayList<SchichtfolgeAdapter>();
			SchichtfolgeAdapter adapter = new SchichtfolgeAdapter(schichtfolge);
			adapterList.add(adapter);

			return adapterList;
		} else {
			schichten.addAll(schichtmuster);

			getContext().getSession().setAttribute(
					SessionAttributes.SCHICHTMUSTER, schichten);

			Schichtfolge schichtfolge = new Schichtfolge(schichten);
			List<SchichtfolgeAdapter> adapterList = new ArrayList<SchichtfolgeAdapter>();
			SchichtfolgeAdapter adapter = new SchichtfolgeAdapter(schichtfolge);
			adapterList.add(adapter);

			return adapterList;
		}

	}

	// --Methode wird nach Klick auf OK/Speichern ausgef�hrt
	public boolean onOkClick() {

		for (Schicht schicht : ((SchichtfolgeAdapter) table.getRowList().get(0))
				.getSchichtfolge().getSchichten()) {
			// System.out.println(schicht);
		}
		ArrayList<Schicht> arrayList = new ArrayList<Schicht>();
		arrayList = ((SchichtfolgeAdapter) table.getRowList().get(0))
				.getSchichtfolge().getSchichten();
		getContext().getSession().setAttribute(SessionAttributes.SCHICHTMUSTER,
				arrayList);

		return true;
	}

	public boolean onTextFieldClick() {
		schichtmusterAdapter.setTextFieldValue(Integer.valueOf(
				textField1.getValue()).intValue());
		// System.out.println("Get: " +
		// schichtmusterAdapter.getTextFieldValue());
		return true;

	}

}