package de.htwg.konstanz.schichtplanung.page;

public class LoginPage extends BorderPage {

    public String title = "Login";

}
