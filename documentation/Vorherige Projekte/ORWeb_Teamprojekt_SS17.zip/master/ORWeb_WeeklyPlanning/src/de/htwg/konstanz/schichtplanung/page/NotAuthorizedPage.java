package de.htwg.konstanz.schichtplanung.page;

import de.htwg.konstanz.schichtplanung.page.BorderPage;

public class NotAuthorizedPage extends BorderPage {

    public String title = "Not Authorized";

}
