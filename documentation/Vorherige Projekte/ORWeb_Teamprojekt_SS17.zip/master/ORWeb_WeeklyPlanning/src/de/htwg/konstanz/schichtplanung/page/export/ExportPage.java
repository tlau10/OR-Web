package de.htwg.konstanz.schichtplanung.page.export;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import net.sf.click.control.Form;
import net.sf.click.control.Submit;
import resources.UtilityProperties;
import de.htwg.konstanz.schichtplanung.page.BorderPage;
import de.htwg.teamprojekt.lpgenerator.LPGenerator;

// Class created by fafilipp and toehrlin

/**
 * Diese Click-Page ist für den Export des Ansatzes der Linearen Programmierung
 * zuständig. Hier werden drei Formulare erstellt (excel, txt und csv) und beim
 * Absenden eines Formulares wird die gewählte Variante mittels Java-Ströme dem
 * Benutzer zur Verfügung gestellt.
 */
public class ExportPage extends BorderPage {

	/**
	 * Titel der Seite
	 */
	public String title = "Export";

	/**
	 * Fehlermeldungen, die beim Export auftreten werden hier gespeichert.
	 */
	public String message = "";

	/**
	 * Das Formular für den Excel Export
	 */
	public Form excelExport = new Form("excelExport");

	/**
	 * Das Formular für den CSV-Datei Export
	 */
	public Form csvExport = new Form("csvExport");

	/**
	 * Das Formular für den TXT-Datei Export
	 */
	public Form txtExport = new Form("txtExport");

	/**
	 * In der onInit Methoden werden die drei Formulare erstellt und die Methode
	 * ausgewählt, welche zu ausführen ist.
	 */
	@Override
	public void onInit() {
		super.onInit();
		excelExport.add(new Submit("Excel Export", this, "excelExportOnClick"));
		csvExport.add(new Submit("CSV Export", this, "csvExportOnClick"));
		txtExport.add(new Submit("TXT Export", this, "txtExportOnClick"));
	}

	/**
	 * Export on Click kümmert sich um das Anbieten der Datei als Download.
	 * Hierzu wird das Response OutputStream verwendet. Die Bibliothek
	 * LPGenerator.jar erstellt mittels der MPS-Datei die gewünschte
	 * Ausgabedatei.
	 * 
	 * @param type
	 *            Als Typ wird die Endkürzung angegeben (txt, csv, xls)
	 * @return immer true
	 */
	public boolean exportOnClick(String type) {
		try {
			// Den Response Object über den Context der Click-Page
			HttpServletResponse response = getContext().getResponse();

			// Mittels der UtilityProperties und der Session wird der Pfad zur
			// MPS-Eingabedatei erstellt.
			UtilityProperties utilprops = UtilityProperties.getInstance();
			String pfad = utilprops.getWorkingDir() + "\\" + utilprops.getProjectName() + "\\"
					+ getContext().getSession().getId().substring(0, 7) + "\\";

			// Erstellt den InputStream für den jeweiligen Format.
			InputStream in;
			if (type.equals("txt")) {
				in = LPGenerator.txtGenerationFromMops(new FileInputStream(pfad + "MopsDatei.mps"));
			} else if (type.equals("csv")) {
				in = LPGenerator.csvGenerationFromMops(new FileInputStream(pfad + "MopsDatei.mps"));
			} else {
				in = LPGenerator.excelGenerationFromMops(new FileInputStream(pfad + "MopsDatei.mps"));
			}

			// Header Erstellung (Header für Downloadfenster)
			response.addHeader("Content-Type", "application/octet-stream");
			response.addHeader("Pragma", "public");
			response.addHeader("Cache-Control", "max-age=0");
			response.setHeader("Content-Disposition", "attachment; filename=LP." + type);

			// Senden des Eingabestromes der Generierten Datei an den Response
			// Ausgabestrom
			ServletOutputStream outs = response.getOutputStream();
			byte[] excelFile = new byte[1024];
			int read = 0;
			while ((read = in.read(excelFile, 0, 1024)) != -1) {
				outs.write(excelFile, 0, read);
			}
			in.close();
			outs.flush();
			outs.close();
		} catch (FileNotFoundException e) {
			// Falls die Eingabedatei nicht gefunden werden kann.
			message = message + " Bitte zuerst Solven oder später erneut probieren!";
			e.printStackTrace(); // Für Debug-Messages
		} catch (Exception e) {
			// Falls weitere Fehler auftreten.
			message = message + " Probleme beim Export aufgetaucht: " + e.getMessage();
			e.printStackTrace(); // Für Debug-Messages
		}
		return true;
	}

	/**
	 * Beim Klicken auf CSV-Export wird diese Methode ausgeführt. Und die
	 * exportOnClick mit dem Parameter "csv" ausgeführt.
	 * 
	 * @return immer true
	 */
	public boolean csvExportOnClick() {
		return exportOnClick("csv");
	}

	/**
	 * Beim Klicken auf TXT-Export wird diese Methode ausgeführt. Und die
	 * exportOnClick mit dem Parameter "txt" ausgeführt.
	 * 
	 * @return immer true
	 */
	public boolean txtExportOnClick() {
		return exportOnClick("txt");
	}

	/**
	 * Beim Klicken auf XLS-Export wird diese Methode ausgeführt. Und die
	 * exportOnClick mit dem Parameter "xls" ausgeführt.
	 * 
	 * @return immer true
	 */
	public boolean excelExportOnClick() {
		return exportOnClick("xls");
	}

}
