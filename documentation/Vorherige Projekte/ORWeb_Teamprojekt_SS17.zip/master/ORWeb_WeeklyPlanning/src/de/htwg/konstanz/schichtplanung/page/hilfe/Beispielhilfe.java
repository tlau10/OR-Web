package de.htwg.konstanz.schichtplanung.page.hilfe;

import de.htwg.konstanz.schichtplanung.page.BorderPage;

public class Beispielhilfe extends BorderPage{
	public String title = "Hilfe Beispiel";

}
