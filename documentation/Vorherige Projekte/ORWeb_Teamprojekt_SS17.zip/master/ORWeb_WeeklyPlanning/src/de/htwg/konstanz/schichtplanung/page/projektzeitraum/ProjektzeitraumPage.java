package de.htwg.konstanz.schichtplanung.page.projektzeitraum;

import de.htwg.konstanz.schichtplanung.page.BorderPage;

// Diese Klasse wurde von toehrlin erstellt
/**
 * Erstellt von toehrlin
 * 
 * Zeigt mithilfe der "projektzeitraum.htm" die Fehlermeldung des Projektstartes an, falls dieser nach dem Ende liegen sollte
 */

public class ProjektzeitraumPage extends BorderPage{
	
	public String title = "ProjektZeitraum";

}
