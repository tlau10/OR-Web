package de.htwg.konstanz.schichtplanung.page.schichtmuster;

import net.sf.click.control.ActionButton;
import net.sf.click.control.Form;
import net.sf.click.control.Submit;
import net.sf.click.extras.control.IntegerField;
import de.htwg.konstanz.schichtplanung.page.BorderPage;

public class SchichtfolgenlaengePage extends BorderPage {
	public Form form = new Form();
	public String title = "Eingabe der Schichtfolge";

	public ActionButton zuSchichtmuster = new ActionButton("zuSchichtmuster", "cancel", this, "zuSchichtmuster");

	private static final String SCHICHTLAENGE = "SCHICHTLAENGE";

	public SchichtfolgenlaengePage() {
	}

	@Override
	public void onInit() {
		super.onInit();
		form.add(new IntegerField(SCHICHTLAENGE, "Schichtlänge in Tagen", true));
		form.add(new Submit("ok", "Neue Schichtfolge anlegen", this, "onOkClick"));
	}

	public boolean onOkClick() {
		if (form.isValid()) {
			getContext().setSessionAttribute(SCHICHTLAENGE, form.getFieldValue(SCHICHTLAENGE));
			SchichtfolgePage schichtMusterPage = (SchichtfolgePage) getContext().createPage(SchichtfolgePage.class);
			setForward(schichtMusterPage);
		}
		return true;
	}

	public boolean zuSchichtmuster() {
		setForward(getContext().createPage(SchichtmusterPage.class));
		return true;
	}

}
