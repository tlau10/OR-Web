package de.htwg.konstanz.schichtplanung.page.schichtmuster;

import java.util.ArrayList;
import java.util.List;

import net.sf.click.control.ActionButton;
import net.sf.click.control.ActionLink;
import net.sf.click.control.Panel;
import schichtmuster.Schichtfolge;
import schichtmuster.SchichtfolgenFactory;
import schichtmuster.Schichtmuster;
import schichtmuster.SchichtmusterFactory;
import de.htwg.konstanz.schichtplanung.page.BorderPage;
import de.htwg.konstanz.schichtplanung.utils.SessionAttributes;

public class SchichtmusterPage extends BorderPage {
	public String title = "Übersicht Schichtfolge";

	public String message = "";
	public Panel panel = new Panel("panel", "schichtmuster/panel.htm");

	public Panel panel2 = new Panel("panel2", "schichtmuster/panel2.htm");

	public Panel panel3 = new Panel("panel3", "schichtmuster/panel3.htm");

	private static final String[] WOCHENTAGE = new String[] { "Montag",
			"Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag",
			"Sonntag" };

	public ActionButton weitereSchichtfolgeButton = new ActionButton(
			"weitereSchichtfolgeButton", "weitere Schichtfolge hinzufügen",
			this, "weitereSchichtfolge");

	public ActionLink deleteLink = new ActionLink("delete", "löschen", this,
			"delete");

	public SchichtmusterPage() {

	}

	@Override
	public void onInit() {
		// TODO Auto-generated method stub
		super.onInit();
		Schichtmuster schichtmuster = (Schichtmuster) getContext().getSession()
				.getAttribute(SessionAttributes.SCHICHTMUSTER);
		if (schichtmuster == null) {
			schichtmuster = new Schichtmuster();

			// TODO sp�ter einf�gen
			getContext().getSession().setAttribute(
					SessionAttributes.SCHICHTMUSTER, schichtmuster);
		}

		initSchichtfolgenTable(schichtmuster);
	}

	private void initSchichtfolgenTable(Schichtmuster schichtmuster) {
		// schichtfolgenTable.setClass(Table.CLASS_SIMPLE);
		// schichtfolgenTable.addColumn(new
		// PanelColumn("schichtfolge","schichtfolge",panel));
		// schichtfolgenTable.addColumn(new
		// Column("schichtfolge","schichtfolge"));
		List rowList = new ArrayList();
		int sffNr = 0;
		for (SchichtfolgenFactory factory : schichtmuster
				.getSchichtfolgenfactory()) {

			List<String> panelList = new ArrayList<String>();
			for (Schichtfolge folge : SchichtmusterFactory
					.getSchichtfolgenfuerBedarf(factory)) {
				panel3.getModel().remove("sf3");
				panel3.addModel("sf3", folge);
				panelList.add(panel3.toString());
			}
			List<String> beschriftungWochentage = new ArrayList<String>();
			for (int i = 0; i < factory.getMusterFolge().getSchichten().size(); i++) {
				beschriftungWochentage.add(WOCHENTAGE[i % 7]);
			}
			panel2.getModel().remove("sf");
			panel2.addModel("sf", panelList);
			panel2.getModel().remove("days");
			panel2.addModel("days", beschriftungWochentage);
			deleteLink.setValue("" + (sffNr++));
			// Beginn of Change (magerhar)
			// The following Line makes no sense
			// deleteLink.bindRequestValue();
			// End of Change
			panel2.getModel().remove("deleteLink");
			panel2.addModel("deleteLink", deleteLink.toString());

			rowList.add(panel2.toString());
		}
		panel.getModel().remove("sff");
		panel.addModel("sff", rowList);
	}

	public boolean weitereSchichtfolge() {
		setForward(getContext().createPage(SchichtfolgenlaengePage.class));
		return true;
	}

	public boolean delete() {
		// System.out.println("deleteLink geklickt "+deleteLink.getValueInteger());
		Schichtmuster schichtmuster = (Schichtmuster) getContext().getSession()
				.getAttribute(SessionAttributes.SCHICHTMUSTER);
		ArrayList<SchichtfolgenFactory> list = schichtmuster
				.getSchichtfolgenfactory();
		
		int delval = (int) deleteLink.getValueInteger();
		System.out.println(delval);
		
		try{
			list.remove((int) deleteLink.getValueInteger());	
		}catch (Exception e){
			message = "Schichtfolge nicht vorhanenden";
		}
		
		schichtmuster.setSchichtfolgenfactory(list);
		if (list.size() > 0) {
			getContext().getSession().setAttribute(
					SessionAttributes.SCHICHTMUSTER, schichtmuster);
		} else {
			getContext().getSession().setAttribute(
					SessionAttributes.SCHICHTMUSTER, null);
		}
		setForward(getContext().createPage(SchichtmusterPage.class));
		return true;

	}

}
