package de.htwg.konstanz.schichtplanung.page.solver;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

import net.sf.click.control.FieldSet;
import net.sf.click.control.Form;
import net.sf.click.control.Submit;
import net.sf.click.extras.control.NumberField;
import resources.MopsResources;
import schichtmuster.Schichtmuster;
import bedarf.Bedarf;
import de.htwg.konstanz.schichtplanung.page.BorderPage;
import de.htwg.konstanz.schichtplanung.utils.SessionAttributes;

public class SolverauswahlPage extends BorderPage {
	public String title = "Solver Auswahl";

	public Form mopsForm = new Form("mopsForm");

	// public ActionButton mopsStandardButton;
	// public ActionButton mopsGoalButton;

	public NumberField goalUebergewichtungField;
	public NumberField goalUntergewichtungField;

	public String message = "";

	// MopsGoal

	public Form mopsGoalForm = new Form("mopsGoalForm");
	public FieldSet mopsGoalFieldSet;

	public boolean mopsStandardOnClick() {

		setForward(getContext().createPage(SolvePage.class));
		return true;
	}

	private boolean pruefeSchichtmusterBedarf(Bedarf bedarf,
			Schichtmuster schichtmuster) {
		boolean bedarfUndSchichtmusterGesetzt = true;

		if (bedarf == null) {
			message = message + "Bedarf muss eingegeben werden<br>";
			bedarfUndSchichtmusterGesetzt = false;
		}
		if (schichtmuster == null) {
			message = message + "Schichtmuster muss angegeben werden";
			bedarfUndSchichtmusterGesetzt = false;
		}
		return bedarfUndSchichtmusterGesetzt;
	}

	public boolean mopsGoalOnClick() {
		int unterschreitung = 1;
		int ueberschreitung = 1;
		if (mopsGoalForm.isValid()) {
			// Bedarf bedarf = (Bedarf) getContext().getSession().getAttribute(
			// SessionAttributes.BEDARF);
			//
			// Schichtmuster schichtmuster = (Schichtmuster)
			// getContext().getSession()
			// .getAttribute(SessionAttributes.SCHICHTMUSTER);
			//
			// copyMopsToTemp();
			//
			//
			//
			// if (pruefeSchichtmusterBedarf(bedarf, schichtmuster)) {

			unterschreitung = goalUntergewichtungField.getNumber().intValue();
			ueberschreitung = goalUebergewichtungField.getNumber().intValue();

			// TODO Starte mopsGoal mit �bergabeparameter

			getContext().getSession().setAttribute(
					SessionAttributes.GOAL_UEBER_SCHREITUNG, ueberschreitung);
			getContext().getSession().setAttribute(
					SessionAttributes.GOAL_UNTER_SCHREITUNG, unterschreitung);
			setForward(getContext().createPage(SolveGoalPage.class));

			// }
		}

		return true;
	}

	private void copyMopsToTemp() {
		FileInputStream in;
		try {

			File file = new File(MopsResources.class.getResource("mops.exe")
					.getFile());
			// System.out.println("File ist null " + file != null);

			in = new FileInputStream(new File(MopsResources.class.getResource(
					"mops.exe").getFile()));

			FileOutputStream out = new FileOutputStream(new File("C:/TEMP/"
					+ "mops.exe"));

			FileChannel inc = in.getChannel();
			FileChannel outc = out.getChannel();

			inc.transferTo(0, inc.size(), outc);

			inc.close();
			outc.close();

			in.close();
			out.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void onInit() {
		super.onInit();

		mopsForm.add(new Submit("Mops", this, "mopsStandardOnClick"));

		mopsGoalFieldSet = new FieldSet("Mops-Goal-Prog");

		goalUebergewichtungField = new NumberField("Übergewichtung", true);
		goalUebergewichtungField.setValueObject(new Integer(1));

		goalUntergewichtungField = new NumberField("Untergewichtung", true);
		goalUntergewichtungField.setValueObject(new Integer(1));

		// auswahlMopsFieldSet.add();
		// auswahlMopsFieldSet.add(goalUebergewichtungField);
		// auswahlMopsFieldSet.add(goalUntergewichtungField);

		// mopsStandardButton = new ActionButton("mopsStandard", this,
		// "mopsStandardOnClick");

		mopsGoalFieldSet.add(goalUebergewichtungField);
		mopsGoalFieldSet.add(goalUntergewichtungField);
		mopsGoalForm.add(mopsGoalFieldSet);
		mopsGoalForm.add(new Submit("Mops-Goal", this, "mopsGoalOnClick"));

	}

}
