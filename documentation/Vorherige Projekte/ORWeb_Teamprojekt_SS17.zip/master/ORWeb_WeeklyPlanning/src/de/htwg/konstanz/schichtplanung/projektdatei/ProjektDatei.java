package de.htwg.konstanz.schichtplanung.projektdatei;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.GregorianCalendar;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import schichtmuster.Schichtmuster;
import schichtmuster.SchichtmusterFactory;
import ausgabe.Schichtplan;
import ausgabe.SchichtplanFactory;
import bedarf.Bedarf;
import bedarf.BedarfFactory;
import de.htwg.konstanz.schichtplanung.utils.SessionAttributes;

/**
 * Servlet generiert ein Zipfile mit Bedarf, Schichtmuster und Schichtplan und
 * schickt dieses über den responsestream an den aufrufenden Client zurück. Der
 * Bedarf, das Schichtmuster und der Schichtmuster müssen im SessionContext
 * abgelegt sein, ansonsten wird null gespeichert.
 * 
 * @author drossman
 * 
 */
public class ProjektDatei extends HttpServlet {
	public static final String FILENAME_BEDARF = "bedarf.xml";
	public static final String FILENAME_SCHICHTMUSTER = "schichtmuster.xml";
	public static final String FILENAME_SCHICHTPLAN = "schichtplan.xml";

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ZipOutputStream out = new ZipOutputStream(resp.getOutputStream());

		ByteArrayOutputStream outstream = new ByteArrayOutputStream();

		out.putNextEntry(new ZipEntry(FILENAME_BEDARF));
		if (req.getSession().getAttribute(SessionAttributes.BEDARF) == null) {
			BedarfFactory.saveBedarf(BedarfFactory.getKonstanterBedarf(new GregorianCalendar(), new GregorianCalendar(), 0, 0, 0),
					outstream);
		} else {
			BedarfFactory.saveBedarf((Bedarf) req.getSession().getAttribute(SessionAttributes.BEDARF), outstream);
		}
		out.write(outstream.toByteArray());

		outstream = new ByteArrayOutputStream();
		out.putNextEntry(new ZipEntry(FILENAME_SCHICHTPLAN));
		if (req.getSession().getAttribute(SessionAttributes.SCHICHTPLAN) == null) {
			SchichtplanFactory.saveSchichtplan(new Schichtplan(), outstream);
		} else {
			SchichtplanFactory.saveSchichtplan((Schichtplan) req.getSession().getAttribute(SessionAttributes.SCHICHTPLAN), outstream);
		}
		out.write(outstream.toByteArray());

		outstream = new ByteArrayOutputStream();
		out.putNextEntry(new ZipEntry(FILENAME_SCHICHTMUSTER));
		if (req.getSession().getAttribute(SessionAttributes.SCHICHTMUSTER) == null) {
			SchichtmusterFactory.saveSchichtmuster(new Schichtmuster(), outstream);
		} else {
			SchichtmusterFactory.saveSchichtmuster((Schichtmuster) req.getSession().getAttribute(SessionAttributes.SCHICHTMUSTER),
					outstream);
		}
		out.write(outstream.toByteArray());

		out.closeEntry();
		out.flush();
		out.close();

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
