package de.htwg.konstanz.schichtplanung.utils;

import java.util.List;

import net.sf.click.control.Option;
import net.sf.click.control.Select;
import net.sf.click.util.HtmlStringBuffer;

public class ColoredOption extends Option {
	private String color ;
public ColoredOption(String value) {
this(value, value);
}
	public ColoredOption(Object value, String label) {
		super(value, label);
		// TODO Auto-generated constructor stub
	}
	
	public ColoredOption(Object value,String label, String color){
		this(value,label);
		this.color = color;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
    public String renderHTML(Select select) {

        HtmlStringBuffer buffer = new HtmlStringBuffer(48);

        buffer.elementStart("option");

        if (select.isMultiple()) {

            if (!select.getSelectedValues().isEmpty()) {

                // Search through selection list for matching value
                List values = select.getSelectedValues();
                for (int i = 0, size = values.size(); i < size; i++) {
                    String value = values.get(i).toString();
                    if (getValue().equals(value)) {
                        buffer.appendAttribute("selected", "selected");
                        break;
                    }
                }

            }

        } else {
            if (getValue().equals(select.getValue())) {
                buffer.appendAttribute("selected", "selected");
            }
        }

        buffer.appendAttribute("value", getValue());
        buffer.appendAttribute("style", "background:"+getColor());
        buffer.closeTag();

        buffer.appendEscaped(getLabel());

        buffer.elementEnd("option");

        return buffer.toString();
    }
	private String getColor() {
		// TODO Auto-generated method stub
		return color;
	}

}
