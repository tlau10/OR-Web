package de.htwg.konstanz.schichtplanung.utils;

import java.util.ArrayList;
import java.util.List;

import schichtmuster.Schicht;
import net.sf.click.control.Option;
import net.sf.click.control.Select;

public class SchichtSelect extends Select{
	
	static final List SCHICHTEN_OPTIONS = new ArrayList();
	
	static{
		for(Schicht schicht : Schicht.values()){
			String label="";
			String color="";
			switch (schicht) {
			case FREISCHICHT:
				label="Frei";
				color="white";
				break;
case FRUEHSCHICHT:
				label="Früh";
				color="yellow";
				break;
case SPAETSCHICHT:
				label="Spät";
				color="lightgray";
	break;
case NACHTSCHICHT:
			label="Nacht";
			color="lightgreen";
	break;
			
			}
			SCHICHTEN_OPTIONS.add(new ColoredOption(schicht.toString(),label,color));
		}
	}
	
	public SchichtSelect() {
		super();
		setOptionList(SCHICHTEN_OPTIONS);
		setAttribute("onChange", "javascript:this.className=this.value;");
		setAttribute("onload", "javascript:this.className=this.value;");
		setAttribute("onfocus", "javascript:this.className=this.value;");
		setAttribute("onmousemove", "javascript:this.className=this.value;");
	}
	public SchichtSelect(String name){
		super(name);
		setOptionList(SCHICHTEN_OPTIONS);
		setAttribute("onChange", "javascript:this.className=this.value;");
		setAttribute("onload", "javascript:this.className=this.value;");
		setAttribute("onfocus", "javascript:this.className=this.value;");
		setAttribute("onmousemove", "javascript:this.className=this.value;");
	}
	
	
	
	
	
	
	

}
