package resources;

import java.io.IOException;
import java.util.Properties;

/**
 * Diese Klasse ist eine Utility Klasse für die Properties der Datei
 * "wochenschichtplanung.properties".
 * 
 * @author Fabio Filippelli
 * 
 */
public class UtilityProperties {

	/**
	 * Objektspeicherung für Singleton Instanzierung
	 */
	private static UtilityProperties utilityProperties;

	/**
	 * Das Properties Objekt (wird im Konstruktor geladen)
	 */
	private final Properties properties;

	/**
	 * Der Dateiname zum Properties File
	 */
	private final String FILE_NAME = "wochenschichtplanung.properties";

	/**
	 * Der Schlüssel um den Arbeitsverzeichnis zu holen
	 */
	private final String WORKINGDIR_KEY = "working.dir";

	/**
	 * Der Standardarbeitsverzeichnis, falls kein anderer im Property File
	 * angegeben.
	 */
	private final String WORKINGDIR_DEFAULT = System.getProperty("java.io.tmpdir");

	/**
	 * Der Schlüssel um den Projektname zu holen
	 */
	private final String PROJECTNAME_KEY = "project.name";

	/**
	 * Der Standardprojektname, falls kein anderer im Property File angegeben.
	 */
	private final String PROJECTNAME_DEFAULT = "Wochenschichtplanung";

	/**
	 * Die Instanzierung der UtilityProperties instanziert den Properties Objekt
	 * und ladet die Werte aus der Propertydatei.
	 * 
	 * @throws IOException
	 */
	private UtilityProperties() throws IOException {
		properties = new Properties();
		properties.load(this.getClass().getResourceAsStream(FILE_NAME));
	}

	/**
	 * Erstellt oder Holt eine Instanz der UtilityProperties Klasse (Singleton).
	 * 
	 * @return Den UtilityProperty Object
	 * @throws IOException
	 *             Falls Probleme beim lesen der Propertydatei entstehen.
	 */
	public static UtilityProperties getInstance() throws IOException {
		if (utilityProperties == null) {
			utilityProperties = new UtilityProperties();
		}
		return utilityProperties;
	}

	/**
	 * Holt den Arbeitsverzeichnis
	 * 
	 * @return Arbeitsverzeichnis
	 */
	public String getWorkingDir() {
		return properties.getProperty(WORKINGDIR_KEY, WORKINGDIR_DEFAULT);
	}

	/**
	 * Holt den Projektname
	 * 
	 * @return Projektname
	 */
	public String getProjectName() {
		return properties.getProperty(PROJECTNAME_KEY, PROJECTNAME_DEFAULT);
	}
}
