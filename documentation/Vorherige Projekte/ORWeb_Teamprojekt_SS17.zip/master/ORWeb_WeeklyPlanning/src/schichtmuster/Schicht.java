/**
 * 
 */
package schichtmuster;

/**
 * <!-- begin-user-doc --> <!-- end-user-doc -->
 * 
 * @author drossman
 * 
 * @generated 
 *            "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public enum Schicht {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated 
	 *            "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	FREISCHICHT,
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated 
	 *            "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	SPAETSCHICHT,
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated 
	 *            "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	NACHTSCHICHT,
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated 
	 *            "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	FRUEHSCHICHT;
	// liefert int-Wert für enum
	public static int toInt(Schicht en) {
		switch (en) {
		case FRUEHSCHICHT: {
			return 1;
		}
		case SPAETSCHICHT: {
			return 2;
		}
		case NACHTSCHICHT: {
			return 3;
		}
		case FREISCHICHT: {
			return 4;
		}
		default: {
			return -1;
		}
		}
	}
}