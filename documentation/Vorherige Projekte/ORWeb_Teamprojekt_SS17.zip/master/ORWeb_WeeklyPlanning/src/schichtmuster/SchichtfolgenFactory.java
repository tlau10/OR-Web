/**
 * 
 */
package schichtmuster;

import java.util.ArrayList;
import java.util.GregorianCalendar;

/** 
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @author drossman
 * 
 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class SchichtfolgenFactory {
	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private ArrayList<SchichtfolgenID> verboten;

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return verboten
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public ArrayList<SchichtfolgenID> getVerboten() {
		// begin-user-code
		return verboten;
		// end-user-code
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param dededsebtn Festzulegender verboten
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setVerboten(ArrayList<SchichtfolgenID> dededsebtn) {
		// begin-user-code
		verboten = dededsebtn;
		// end-user-code
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private ArrayList<SchichtfolgenID> erlaubt;

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return erlaubt
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public ArrayList<SchichtfolgenID> getErlaubt() {
		// begin-user-code
		return erlaubt;
		// end-user-code
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param dededsrab Festzulegender erlaubt
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setErlaubt(ArrayList<SchichtfolgenID> dededsrab) {
		// begin-user-code
		erlaubt = dededsrab;
		// end-user-code
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Rotation rotation;

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return rotation
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Rotation getRotation() {
		// begin-user-code
		// begin-user-code
		return rotation;
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param dededsoain Festzulegender rotation
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setRotation(Rotation dededsoain) {
		// begin-user-code
		rotation = dededsoain;
		// end-user-code
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Schichtfolge musterFolge;

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return musterFolge
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Schichtfolge getMusterFolge() {
		// begin-user-code
		return musterFolge;
		// end-user-code
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param dededsutrog Festzulegender musterFolge
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setMusterFolge(Schichtfolge dededsutrog) {
		// begin-user-code
		musterFolge = dededsutrog;
		// end-user-code
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer("Rotation "+rotation+"\n");
		sb.append("MusterFolge "+ musterFolge);
		return sb.toString();
	}
}