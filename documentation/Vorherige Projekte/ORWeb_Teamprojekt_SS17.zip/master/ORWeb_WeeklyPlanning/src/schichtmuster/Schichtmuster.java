/**
 * 
 */
package schichtmuster;

import java.util.ArrayList;
import java.util.GregorianCalendar;

/** 
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @author drossman
 * 
 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class Schichtmuster {
	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private ArrayList<SchichtfolgenFactory> schichtfolgenfactory;
	
	public Schichtmuster(){
		schichtfolgenfactory = new ArrayList<SchichtfolgenFactory>();
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return schichtfolgenfactory
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public ArrayList<SchichtfolgenFactory> getSchichtfolgenfactory() {
		// begin-user-code
		return schichtfolgenfactory;
		// end-user-code
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param dededscihflefcoy Festzulegender schichtfolgenfactory
	 * @generated "UML in Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setSchichtfolgenfactory(
			ArrayList<SchichtfolgenFactory> dededscihflefcoy) {
		// begin-user-code
		schichtfolgenfactory = (ArrayList<SchichtfolgenFactory>) dededscihflefcoy.clone();
		// end-user-code
	}
	public void setoneSchichtfolgenFactory(SchichtfolgenFactory sff){
		schichtfolgenfactory.add(sff);
	}
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		for(SchichtfolgenFactory factory : schichtfolgenfactory){
			buffer.append(factory);
		}
		return buffer.toString();
	}
}