/**
 * 
 */
package schichtmuster;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * @author Dominik
 * @generated "UML to Java V5.0
 *            (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class SchichtmusterFactory {
	/**
	 * @param alleSchichtfolgen
	 * @generated "UML to Java V5.0
	 *            (com.ibm.xtools.transform.uml2.java5.internal
	 *            .UML2JavaTransform)"
	 */
	public static List<Schichtfolge> getAlleSchichtfolgen(int anzahlRotationsWochen, Schichtmuster sm) {
		// begin-user-code
		// TODO Erstelle case Anweisung f�r unterschiedliche Rotationstypen

		// reicht Uses Beziehung aus? Ben�tige Zugriff auf Liste der
		// Schichtmuster

		// FIXME Objekt einbinden Euler Fragen wie umgesetzt werden soll.
		// �bergabe Parameter?
		Schichtmuster schichtmuster = sm;
		ArrayList<SchichtfolgenFactory> schichtfolgenFactoryList = schichtmuster.getSchichtfolgenfactory();

		List<Schichtfolge> newrot = new ArrayList<Schichtfolge>();

		for (SchichtfolgenFactory run : schichtfolgenFactoryList) {
			// �u�erste schleife: Iteriert �ber alle SchichtfolgenFactorys

			newrot.addAll(getSchichtfolgenfuerBedarf(run));

		}
		// TODO schreibe Methode Fertig: Anpassung des Schichtmusters an die
		// l�nge des Bedarfs
		// int laengeSollBedarf =anzahlRotationsWochen *7;
		// ArrayList<Schichtfolge> bedarfsangepassteSchichten= new
		// ArrayList<Schichtfolge>();
		//
		// // ArrayList<Schicht> bedarfsAngepassteSchi hten;
		// for (Schichtfolge run : newrot) {
		// // int laengeSchicht =run.getSchichten().size();
		//
		// ArrayList<Schicht> tempSchicht= run.getSchichten();
		// // bedarfsAngepassteSchichten = new ArrayList<Schicht>();
		//
		// int laengeSchicht =tempSchicht.size();
		// int multLaenge = (int)Math.ceil(laengeSollBedarf/laengeSchicht)+1;
		//
		// System.out.println("ganzzahl: "+multLaenge);
		// ArrayList<Schicht> create1 = new ArrayList<Schicht>();
		// Schichtfolge createSf;
		//
		//
		// for(int i =0; i<multLaenge;i++){
		//
		// create1.addAll(run.getSchichten());
		//
		// }
		// //Schneide restliche Schichten ab.
		// for(int i = multLaenge*laengeSchicht; i>anzahlRotationsWochen*7;i--){
		// create1.remove(i-1);
		//
		// }
		//
		//
		//
		// createSf=new Schichtfolge(create1);
		// bedarfsangepassteSchichten.add(createSf);
		//
		//
		//
		//
		//
		//
		//
		//
		//
		//
		//
		// }

		return newrot;
		// return newrot;
		// end-user-code

	}

	public static ArrayList<Schichtfolge> getAlleSchichtfolgenfuerBedarf(int bedarfInTagen, Schichtmuster sm) {
		// begin-user-code

		Schichtmuster schichtmuster = sm;
		ArrayList<SchichtfolgenFactory> schichtfolgenFactoryList = schichtmuster.getSchichtfolgenfactory();

		List<Schichtfolge> newrot = new ArrayList<Schichtfolge>();

		// �u�erste Schleife: Iteriert �ber alle SchichtfolgenFactorys
		// jeden enth�lt ein Schichtmusterfolge
		for (SchichtfolgenFactory run : schichtfolgenFactoryList) {
			newrot.addAll(getSchichtfolgenfuerBedarf(run));
		}

		// Generiere Freischichtmuster
		ArrayList<Schicht> leerMuster;
		Schichtfolge schichtfolgenTemp;
		ArrayList<Schichtfolge> returnSchichtfolgenArray = new ArrayList<Schichtfolge>();

		for (Schichtfolge run : newrot) {

			leerMuster = new ArrayList<Schicht>();
			int laengeSchichtfolge = run.getSchichten().size();

			// Setze freischichten
			for (int i = 0; i < laengeSchichtfolge; i++) {

				leerMuster.add(Schicht.FREISCHICHT);
			}

			int rotationsdurchlauf;
			if (bedarfInTagen % laengeSchichtfolge == 0) {
				rotationsdurchlauf = (bedarfInTagen / laengeSchichtfolge);
			} else {
				rotationsdurchlauf = (bedarfInTagen / laengeSchichtfolge) + 1;
			}
			int fuegeSchichtein = 0;

			for (int k = 0; k < rotationsdurchlauf; k++) {
				schichtfolgenTemp = new Schichtfolge();

				for (int j = 0; j < rotationsdurchlauf; j++) {
					// System.out.println("rotlauf: " + j);
					if (j == fuegeSchichtein) {
						// System.out.println("schichteing" + j + " "
						// + fuegeSchichtein);
						// rotiertesMuster einf�gen
						schichtfolgenTemp.addSchichten(run.getSchichten());

					} else {
						// System.out.println("leereing");
						// F�ge Leerfolge ein
						schichtfolgenTemp.addSchichten(leerMuster);
					}

				}

				fuegeSchichtein++;
				returnSchichtfolgenArray.add(schichtfolgenTemp);

			}

			// System.out.println("----");

		}
		for (Schichtfolge runvariable : returnSchichtfolgenArray) {
			// System.out.println("l " + runvariable.getSchichten().size());

			for (int i = runvariable.getSchichten().size(); i > bedarfInTagen; i--) {
				runvariable.getSchichten().remove(i - 1);
				//
			}
		}
		for (int i = 0; i < returnSchichtfolgenArray.size();) {
			boolean allesFrei = true;
			for (Schicht schicht : returnSchichtfolgenArray.get(i).getSchichten()) {
				if (schicht != Schicht.FREISCHICHT) {
					allesFrei = false;
					break;
				}
			}
			if (allesFrei) {
				returnSchichtfolgenArray.remove(i);
			} else {
				i++;
			}
		}

		return returnSchichtfolgenArray;

	}

	public static List<Schichtfolge> getSchichtfolgenfuerBedarf(SchichtfolgenFactory run) {

		List<Schichtfolge> newrot = new ArrayList<Schichtfolge>();
		ArrayList<Schicht> rotationSchicht = (ArrayList<Schicht>) run.getMusterFolge().getSchichten().clone();

		newrot.add(new Schichtfolge(rotationSchicht));

		if (run.getRotation() == Rotation.TAEGLICHE_ROTATION) {

			for (int i = 0; i < rotationSchicht.size() - 1; i++) {

				rotationSchicht.add(rotationSchicht.get(0));
				rotationSchicht.remove(0);
				newrot.add(new Schichtfolge(rotationSchicht));

			}
		}
		// TODO Kl�rung ob �berhaupt noch ben�tigt wird.
		if (run.getRotation() == Rotation.WOECHENTLICHE_ROTATION) {
			// TODO Exception werden wenn Modulo / != 0
			if (rotationSchicht.size() % 7 != 0) {
				// System.out.println("W�CHENTLICHE ROTATION NICHT M�GLICH");
			} else {
				int anzWochen = rotationSchicht.size() / 7;
				// System.out.println("anzWochen:" + anzWochen);

				//
				for (int j = 0; j < anzWochen - 1; j++) {
					for (int i = 0; i < 7; i++) {
						// System.out.println("..");
						rotationSchicht.add(rotationSchicht.get(0));
						rotationSchicht.remove(0);

					}
					newrot.add(new Schichtfolge(rotationSchicht));

				}

			}

		}
		return newrot;
	}

	/**
	 * @param schichtfolgenID
	 * @generated "UML to Java V5.0
	 *            (com.ibm.xtools.transform.uml2.java5.internal
	 *            .UML2JavaTransform)"
	 */
	public static void verbieten(Integer schichtfolgenID) {
		// begin-user-code
		// TODO Auto-generated method stub

		// end-user-code
	}

	/**
	 * @param schichtfolgenID
	 * @generated "UML to Java V5.0
	 *            (com.ibm.xtools.transform.uml2.java5.internal
	 *            .UML2JavaTransform)"
	 */
	public static void erlauben(Integer schichtfolgenID) {
		// begin-user-code
		// TODO Auto-generated method stub

		// end-user-code
	}

	/**
	 * @param schichtfolgenFactory
	 * @generated "UML to Java V5.0
	 *            (com.ibm.xtools.transform.uml2.java5.internal
	 *            .UML2JavaTransform)"
	 */
	public static void addSchichtfolgenFactory(Schichtmuster schichtmuster, SchichtfolgenFactory schichtfolgenFactory) {
		// begin-user-code
		schichtmuster.setoneSchichtfolgenFactory(schichtfolgenFactory);
		// end-user-code
	}

	/**
	 * @param Parameter1
	 * @param startZeitpunkt
	 * @param endZeitpunkt
	 * @generated "UML to Java V5.0
	 *            (com.ibm.xtools.transform.uml2.java5.internal
	 *            .UML2JavaTransform)"
	 */
	public static void getSchichtmusterToArray(Integer Parameter1, GregorianCalendar startZeitpunkt, GregorianCalendar endZeitpunkt) {
		// begin-user-code
		// TODO Auto-generated method stub

		// end-user-code
	}

	/**
	 * @param Parameter1
	 * @generated "UML to Java V5.0
	 *            (com.ibm.xtools.transform.uml2.java5.internal
	 *            .UML2JavaTransform)"
	 */
	public static void saveSchichtmusterToFile(Object Parameter1) {
		// begin-user-code
		// TODO Auto-generated method stub

		// end-user-code
	}

	/**
	 * @param Parameter1
	 * @param filename
	 * @generated "UML to Java V5.0
	 *            (com.ibm.xtools.transform.uml2.java5.internal
	 *            .UML2JavaTransform)"
	 */
	public static void loadSchichtmusterFromFile(Schichtmuster Parameter1, String filename) {
		// begin-user-code
		// TODO Auto-generated method stub

		// end-user-code
	}

	public static Schichtmuster loadSchichtmuster(InputStream input) {
		java.beans.XMLDecoder decoder = new XMLDecoder(input);
		Schichtmuster schichtmuster = (Schichtmuster) decoder.readObject();
		decoder.close();
		return schichtmuster;
	}

	public static void saveSchichtmuster(Schichtmuster schichtmuster, OutputStream out) {
		XMLEncoder encoder = new XMLEncoder(out);
		encoder.writeObject(schichtmuster);
		encoder.close();
	}
}