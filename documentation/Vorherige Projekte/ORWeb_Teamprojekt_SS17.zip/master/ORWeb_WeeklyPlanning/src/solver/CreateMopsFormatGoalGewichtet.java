package solver;

public class CreateMopsFormatGoalGewichtet extends CreateMopsFormatGoal {

	private int ueber;
	private int unter;

	public CreateMopsFormatGoalGewichtet(int ueber, int unter) {
		super();
		this.ueber = ueber;
		this.unter = unter;
	}

	/**
	 * Die Methode Leifert die Ueberschreitungsvariable
	 */
	@Override
	public String getZFUeberschreitungsvariable() {
		// TODO Auto-generated method stub
		return "" + ueber;
	}

	/**
	 * Die Methode Leifert die Unterschreitungsvariable
	 */
	@Override
	public String getZFUnterschreitungsvariable() {
		// TODO Auto-generated method stub
		return "" + unter;
	}
}
