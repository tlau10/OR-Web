package solver;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ausgabe.Ausgabe;
import ausgabe.Schichtplan;
import schichtmuster.Schichtfolge;

/**
 * Die Klasse Einlesen bekommt als Input die von MOPS generierte Mopsdatei.lps
 * Datei und �bergibt das Ergebnis in Form eines Ausgabeobjekts.
 * 
 * @author Teamprojekt - Solvergruppe
 * @version 1.0
 */
public class Einlesen {
	private static final Properties properties = new Properties();
	static {
		try {
			properties.load(Einlesen.class.getResourceAsStream("Solver.properties"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Methode dateiEinlesen erhaelt als Uebergabeparameter eine Arraylist von
	 * Schichtfolgen, um sie im weiteren Verlauf gemeinsam mit den aus der
	 * MopsDatei.lps ausgelesenen korrespondierenden Zielfuntionswerten als
	 * Ausgabeobjekt in Form einer Arraylist zurückzugeben.
	 * 
	 * @param schichtfolge
	 * @return tempSchichtplan
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	// Begin of Change fafilipp
	public Schichtplan dateiEinlesen(String currentDir, ArrayList<Schichtfolge> schichtfolge) throws FileNotFoundException, IOException {
		// End of Change

		ArrayList<Ausgabe> mopsloesung = new ArrayList<Ausgabe>();
		// Begin of Change fafilipp
		BufferedReader test = new BufferedReader(
				new FileReader(currentDir + "\\" + properties.getProperty("LP_Einlesen_MopsDateiEinlesen")));
		// End of Change
		Pattern bSP = Pattern.compile("X\\d");
		int index = 0;

		while (test.ready() != false) {
			String currentLine = test.readLine();
			Matcher bSMatcher = bSP.matcher(currentLine);
			if (bSMatcher.find()) {
				Pattern xPattern = Pattern.compile("X\\d+");
				Matcher matcherX = xPattern.matcher(currentLine);
				matcherX.find();
				Pattern zPattern = Pattern.compile("[-]?\\d+");
				Matcher matcherZ = zPattern.matcher(currentLine);
				matcherZ.find();
				matcherZ.find();
				matcherZ.find();
				int hulk = Integer.parseInt(currentLine.substring(matcherZ.start(), matcherZ.end()));
				if (index < schichtfolge.size()) {
					mopsloesung.add(new Ausgabe(hulk, schichtfolge.get(index)));
				}
				index++;
			}
		}
		test.close();
		Schichtplan tempSchichtplan = new Schichtplan();
		tempSchichtplan.setAusgabe(mopsloesung);
		return tempSchichtplan;
	}
	

}
