package solver;

public class InfeasibleException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1615535228997147823L;

	public InfeasibleException(String s) {
		super(s);

	}

	public InfeasibleException() {
		super("Infeasible Exception, unlösbar");
	}

}
