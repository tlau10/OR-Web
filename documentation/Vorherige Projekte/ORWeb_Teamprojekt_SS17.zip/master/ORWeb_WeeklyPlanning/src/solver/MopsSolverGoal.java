package solver;

public class MopsSolverGoal extends MopsSolver {
	private Integer ueber = null;
	private Integer unter = null;

	public MopsSolverGoal(Integer ueber, Integer unter) {
		this.ueber = ueber;
		this.unter = unter;
	}

	@Override
	public CreateMopsFormat getMopsFormatImpl() {
		return new CreateMopsFormatGoalGewichtet(unter, ueber);
	}
}
