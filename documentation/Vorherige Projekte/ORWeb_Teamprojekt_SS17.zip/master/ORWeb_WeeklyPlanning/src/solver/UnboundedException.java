package solver;

public class UnboundedException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public UnboundedException(){
		super("Unbounded Solution, keine Optimallösung");
		
	}
	public UnboundedException(String s){
		super(s);
	}

}
