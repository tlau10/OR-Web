#!/bin/bash

# Configuration
SERVER_IP=141.37.122.49
APPNAME='orweb'
APPUSER='orweb'
PROPERTIES_FILE_PATH='/opt/orweb/config/orweb_lps_linux.properties'
ORWEB_JAR_PATH='/opt/orweb/ORWeb-3.0.jar'
DEPLOY_SCRIPT_PATH='/opt/orweb/deploy.sh'
LOCAL_JAR_PATH='ORWeb_Frontend/target/ORWeb-3.0.jar'

# copy file to the server
echo -e "## ...starting to upload the software..."
scp $LOCAL_JAR_PATH  orweb@$SERVER_IP:/opt/orweb 

echo -e "## ...restarting the orweb service ##"
ssh root@$SERVER_IP 'service orweb restart'
#ssh root@$SERVER_IP '$DEPLOY_SCRIPT_PATH $ORWEB_JAR_PATH $APPNAME $APPUSER $PROPERTIES_FILE_PATH'
echo -e "## ...finished restarting the orweb service ##"
