Anleitung zum Importieren der Daten
1. Eisenstadt 1.4_neu.jar ausführen
2. Datei  / Öffnen
3. xml-Ordner öffnen
4. gewünschte xml-Datei öffnen