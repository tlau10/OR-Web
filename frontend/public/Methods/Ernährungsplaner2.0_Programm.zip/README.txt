Solver 		          = Ordner, in dem sich die Solver LP_Solve und Cplex befinden
Ernährungsplaner 2.0.jar  = Ausführbare Datei
Lebensmittel.xml	  = Datei, die in Ernährungsplaner 2.0.jar importiert werden kann

Anleitung für Solverpfade konfigurieren
1. Alternative: Solverpfade im Programm konfigurieren
	a) Öffnen Sie die "Ernährungsplaner 2.0.jar"-Datei.
	b) Klicken Sie auf "Einstellungen" / "Solverpfad" ändern
	c) Passen Sie die Pfade an die absoluten Dateipfaden der Solver an
	d) Klicken Sie auf "Übernehmen" und danach auf "Schliessen"


2. Alternative: Solverpfade im paths.ini konfigurieren
	a) Öffnen Sie die "paths.ini"-Datei mittels Texteditor
	b) Passen Sie die Pfade an die absoluten Dateipfaden der Solver an
	c) Speichern Sie die Änderungen
	d) Schließen Sie die Datei