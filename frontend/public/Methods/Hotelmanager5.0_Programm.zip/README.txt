Solver 		          = Ordner, in dem sich die Solver LP_Solve und Cplex befinden
Hotelmanager 5.0.jar  	  = Ausführbare Datei
solverpfad.ini		  = Datei, die Dateipfad des Solvers speichert 

Anleitung für Solverpfade konfigurieren
1. Alternative: Solverpfade im Programm konfigurieren
	a) Öffnen Sie die "Hotelmanager 5.0.jar"-Datei.
	b) Klicken Sie auf "Einstellungen" 
	c) Passen Sie den "Pfad zu lp_Solve.exe" an den absoluten Dateipfaden der Solver an
	d) Klicken Sie auf "Übernehmen"


2. Alternative: Solverpfad im solverpfad.ini konfigurieren
	a) Öffnen Sie die "solverpfad.ini"-Datei mittels Texteditor
	b) Passen Sie den Pfad an den absoluten Dateipfad des Solvers an
	c) Speichern Sie die Änderungen
	d) Schließen Sie die Datei