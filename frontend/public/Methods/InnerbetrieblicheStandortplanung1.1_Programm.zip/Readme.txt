
INNERBETRIEBLICHE STANDORTPLANUNG 1.1
-------------------------------------

Kurzbeschreibung: 
	siehe OR-Alpha


Autor:   Marc Jungh�nel
           
Entwicklungssystem:
         Delphi 4.0



Erweiterungen:

Juli 2015
 Durch:
Sarah Amann & Jenny Schwarz

�nderungen:
	Hilfe-Datei
	Wiederherstellung der Lauff�higkeit

Entwicklungsumgebung:
	Lazarus
