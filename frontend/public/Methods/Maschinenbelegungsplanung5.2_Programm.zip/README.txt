Anleitung für Solverpfade konfigurieren
1) Öffnen Sie die "Maschinenbelegungsplanung.exe"-Datei im exec-Ordner.
2) Klicken Sie auf "Einstellungen" 
3) Passen Sie die Pfade an den absoluten Dateipfaden der Solver an
4) Klicken Sie auf "OK"


