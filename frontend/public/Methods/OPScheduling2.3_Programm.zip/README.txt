Solver 		          = Ordner, in dem sich der Solver LP_Solve befindet
OP Scheduling 2.3.jar = Ausführbare Datei
daten				  = Ordner, in dem sich die Daten befinden, die im OP Scheduling 2.3.jar mittels Datei/Öffnen hineingeladen werden können
ini.txt				  = Datei, die Dateipfad des Solvers speichert 

Anleitung für Solverpfade konfigurieren
1. Alternative: Solverpfade im Programm konfigurieren
	a) Öffnen Sie die "OP Scheduling 2.3.jar"-Datei.
	b) Klicken Sie auf "Einstellungen" 
	c) Passen Sie den Pfad an den absoluten Dateipfad des Solvers an, den Sie verwenden möchten
	d) Klicken Sie auf "OK"


2. Alternative: Solverpfade im ini.txt konfigurieren
	a) Öffnen Sie die "ini.txt"-Datei mittels Texteditor
	b) Passen Sie den Pfad an den absoluten Dateipfad des Solvers an, den Sie verwenden möchten
		* Falls Sie LP_Solve verwenden wollen, passen Sie den "LP_Solve Path=" sowie "checkedPath=" an
	c) Speichern Sie die Änderungen
	d) Schließen Sie die Datei