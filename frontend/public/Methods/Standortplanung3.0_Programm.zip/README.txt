Solver 		          = Ordner, in dem sich die Solver LP_Solve und Mops befinden
Standortplanung_v3.0.jar  = Ausführbare Datei
solverpath.txt		  = Datei, die Dateipfade der Solver speichert 
Daten			  = Ordner, in dem sich die Daten befinden, die im OP Scheduling 2.3.jar mittels Datei/Öffnen hineingeladen werden können

Anleitung für Solverpfade konfigurieren
1. Alternative: Solverpfade im Programm konfigurieren
	a) Öffnen Sie die "Standortplanung_v3.0.jar"-Datei.
	b) Klicken Sie auf "Einstellungen" / "Solverpfade/Arbeitsumgebung anpassen"
	c) Passen Sie die Pfade an den absoluten Dateipfaden der Solver an
	d) Klicken Sie auf "Speichern"


2. Alternative: Solverpfade im solverpath.txt konfigurieren
	a) Öffnen Sie die "solverpath.txt"-Datei mittels Texteditor
	b) Passen Sie die Pfade an die absoluten Dateipfaden der Solver an
	c) Speichern Sie die Änderungen
	d) Schließen Sie die Datei