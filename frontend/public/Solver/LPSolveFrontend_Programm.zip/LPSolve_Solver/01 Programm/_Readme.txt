In das Exec-Verz. bitte stets die ausf�hrbaren
Dateien der akt. LP-Solve-Version einstellen.

Akt. Version: 4.0.1
