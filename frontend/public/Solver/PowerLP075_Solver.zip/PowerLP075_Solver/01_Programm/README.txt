PowerLP Version 0.7.4


PowerLP kann in jedem Verzeichnis des Computers abgelegt werden. 




Wichtig !!!!! 



**************************************************************
**************************************************************


Der Pfad zu PowerLP darf KEINE Leerzeichen enthalten!!!!!!!!


Der Pfad zu PowerLP darf KEINE Umlaute enthalten!!!!!!



Falls der Weidenauer Optimizer Fehlermeldungen ausgibt, verschieben Sie den Ordner PowerLP so, dass der Verzeichnispfad m�glichst kurz ist
.


*******************************************************************************************************************************************

Es wird empfohlen den PowerLP nicht tiefer als einen Unterordner unter dem Hauptverzeichnis abzulegen und kurze Ordnernamen zu w�hlen. 

Ansonsten ist eine fehlerfreie Ausf�hrung oft nicht m�glich. 
Alle anderen Solver funktionieren dennoch trotzdem. 



Im Gegensatz zu Vorversionen muss in Version 0.7.4 keine Pfadanpassungen �ber die Einstellungen des PowerLP vorgenommen werden.

Zum Ausfuehren die Datei "powerlp.exe" mit Doppelklick starten. Nach dem Programmstart kann die Datei
"StandardBeispiel.lpi" eingebunden werden. Diese Datei dient als Standardbeispiel der Vorlesung Operations Research der HTWG Konstanz.


WICHTIG!!

Die Ordnerstruktur darf innerhalb des Ordners "PowerLP0.7.4" nicht ver�ndert werden! 


