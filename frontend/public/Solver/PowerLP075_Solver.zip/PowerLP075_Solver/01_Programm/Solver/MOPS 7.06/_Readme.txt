---------------------------------------------------
             Win32-Version von Mops
---------------------------------------------------


Alle Einstellungen f�r Mops werden in der Profile-Datei XMOPS.PRO
gespeichert, welche im selben Verzeichnis wie die Mops.exe liegen
muss.

Da die Profile-Datei auf dem Server Merkur keine Schreibzugriffe 
erlaubt, kann sie zusammen mit der Exe auf "c:\temp" eines lokalen 
Rechners kopiert und dort zur Ausf�hrung gebracht werden.

Umgehen des oben ansprochenen Umkopierens der Mops.exe:
- Dos-Pfad (temp.) um das Mops-Verzeichnis erweitern
- Ggf. das Verzeichnis im welchem XMOPS.PRO (Profiledatei)
  liegt zum aktuellen Verz. machen.


Die Profile-Datei kann mit einem Editor ge�ndert werden.
�ber die Bedeutung der einzelnen Variablen informiert die Forum-
Datei im Exec-Verzeichnis.

Sept. 2004, W.O.

